# SMC² diagnosis

Controlled diagnosis on the saved varied-magnitudes training dataset, one fixed cuboid, four accepted pushes, three inference seeds. No production estimator settings were changed. These experiments explain this failure case, not general SMC² performance.

## Findings

1. The initial comparison measured selected point predictions, not the main benefit of an ensemble: uncertainty-aware prediction and decisions. CMA-ES searches a population and retains top-K candidates; its retained softmax weights are not a Bayesian posterior. SMC² does not guarantee better point error.

2. First-update baseline ESS was 1.00–1.07 out of 64; the largest weight was 96.8–99.9999%. Resampling therefore removes nearly all initial diversity. The two fixed-scale PMMH moves per particle are insufficient to recover it consistently.

3. At the true physics, on a fixed first push, 32 repeated likelihood estimates had log-likelihood standard deviations of 5.04 with 8 inner particles and 1.15 with 64. Effective inner weights averaged 1.36/8 and 3.06/64. Reducing all start standard deviations by 10× gave 0.73 log-likelihood SD; exact starts eliminated this Monte Carlo noise. The target exposes simulator state without injected measurement noise, so its 1 cm assumed start-position uncertainty is a modeling assumption, not observed sensor noise.

4. Resampling can produce identical particles with equal weights. In an exact-start run, all 64 particles became identical and a subsequent update reported ESS=64. ESS is a weight diagnostic, not a diversity diagnostic. Because moves currently depend on low ESS, this population can stop exploring even when its hypothesis is wrong.

5. The likelihood itself is biased toward contact reconstruction transients on this data. At true mass/friction, the reproducible 25-point COM profile including warm-up prefers h_c=0.055 m over the true 0.100 m by 70.28 log units. Excluding only retained warm-up samples gives a maximum at 0.095 m, just 0.065 log units above truth. This is a conditional profile, not a marginal posterior, and excluding warm-up was only a diagnostic ablation.

6. Channel scoring exposes the mechanism. For an explicitly evaluated h_c=0.045 m vs truth, warm-up pitch-rate standardized squared errors were 121.2 vs 254.4; force-applied pitch-rate errors were only 0.113 vs 0.096. Thus contact transients dominate the apparent COM evidence. Tiny COM perturbations can change the profile irregularly; an earlier explicitly represented 0.045 m scored differently from the nearby floating-point grid point. Neither optimum should be interpreted as a precise physical estimate.

## Ablations

All rows use the same saved training data and three seeds. Default start uncertainty is retained in the first two rows; exact-start rows change the statistical model. Compute budgets differ, so this is a diagnosis, not a ranked fair-budget comparison.

| Variant | Mean mass error (%) | Friction error | COM error (mm) | Final unique particles (mean) | Final cumulative PMMH acceptance (%) |
|---|---:|---:|---:|---:|---:|
| baseline | 19.47 | 0.1567 | 28.21 | 8.3 | 6.84 |
| more_inner | 3.87 | 0.0264 | 29.07 | 6.7 | 5.53 |
| exact_start | 9.19 | 0.0412 | 26.77 | 3.3 | 5.14 |
| exact_start_more_outer | 37.72 | 0.0918 | 38.18 | 7.0 | 3.16 |
| exact_start_more_moves | 2.75 | 0.0243 | 41.78 | 7.0 | 3.04 |

Increasing inner particles improves mass/friction recovery but does not restore COM calibration. More outer particles alone did not reliably improve inference. Twenty moves with exact starts improved mass/friction estimates but still failed to identify COM correctly.

## Ensemble evaluation

A separate post-hoc evaluation of the saved baseline varied-force posterior used the full weighted predictive mean on the two upright held-out pushes. Position RMSEs for point vs predictive mean were: seed 1, 0.482 vs 0.349 mm; seed 2, 0.965 vs 0.918 mm; seed 3, 4.201 vs 4.630 mm. Ensemble averaging helps some seeds but does not remove the observed failure. These held-out measurements were not used to choose ablation settings.

## Recommended next changes

1. Decide the observation model explicitly: use known starts for the current noise-free simulator baseline; introduce measured state uncertainty only in an experiment that actually adds measurement noise.
2. Model warm-up/contact reconstruction mismatch separately, or exclude unreliable warm-up observations from scoring while still simulating warm-up. Validate the choice on separate development pushes; do not simply enlarge all noise scales until truth fits.
3. Improve outer exploration with intermediate likelihood tempering and suitable MCMC proposals. Intermediate targets must preserve the intended posterior; tempering noisy estimates requires care rather than raising an unbiased likelihood estimate to an arbitrary power.
4. Track unique hypotheses alongside ESS and provide rejuvenation opportunities even when equal weights mask genealogical collapse. More moves alone can be expensive with low acceptance.
5. Compare posterior-predictive scores and toppling probabilities on fresh objects/actions, under explicit replay budgets. The original three held-out pushes are now diagnostic data, so reserve a new final test set.

## Sources and reproduction

- [SMC² original paper](https://arxiv.org/abs/1101.1528): parameter SMC with inner likelihood estimation and PMCMC rejuvenation; posterior representation does not imply finite-budget optimization superiority.
- [Doucet et al., efficient pseudo-marginal implementation](https://arxiv.org/abs/1210.1871): likelihood-estimation variance affects efficiency. Numerical tuning rules in that paper rely on assumptions; they are not universal thresholds for this simulator.
- Run `python -m src.agents.system_identification.studies.diagnose_smc2` with this repository’s `.venv` and a new output directory. It writes repeated-likelihood probes, channel residuals, COM profiles, and per-update ablations.
- Additional analysis artifacts: summary.json, ensemble_evaluation.json, observation_scales.json, channel_scores.json, com_profiles.png. The plot shows likelihood profiles at fixed true m/mu, not marginalized posterior probabilities.

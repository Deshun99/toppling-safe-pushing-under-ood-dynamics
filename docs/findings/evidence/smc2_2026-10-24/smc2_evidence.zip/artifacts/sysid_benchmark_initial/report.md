# Initial SMC² benchmark

Single fixed cuboid: mass 1 kg, friction 0.3, COM height 0.1 m; geometry 0.08 × 0.08 × 0.20 m.

Three excitation regimes and inference seeds 1, 2, 3. SMC² uses 64 outer / 8 inner particles; CMA-ES uses 10 iterations and no restarts per update. Data are shared across methods and seeds. Budgets are not compute-matched.

| Regime | Method | Held-out upright position RMSE (mm) | Mean mass error (kg) | Mean friction error | Mean COM error (mm) |
|---|---|---:|---:|---:|---:|
| tilt boundary | cma_es | 0.967 | 0.172 | 0.061 | 22.83 |
| tilt boundary | smc2 | 1.513 | 0.245 | 0.121 | 48.51 |
| varied heights | cma_es | 1.145 | 0.259 | 0.089 | 29.71 |
| varied heights | smc2 | 1.847 | 0.280 | 0.168 | 39.34 |
| varied magnitudes | cma_es | 1.083 | 0.141 | 0.072 | 30.99 |
| varied magnitudes | smc2 | 1.882 | 0.195 | 0.157 | 28.21 |

True-physics replay upright position RMSE: 0.0437 mm. This is a reconstruction reference, not a guaranteed lower bound for every fitted predictor.

SMC² used 81,256 fitting replays versus 5,460 for CMA-ES. Final unique-particle counts were 1–21 out of 64. Conditional 95% interval coverage across the three inference seeds was 0–1/3 for each parameter/regime combination.

Interpretation: SMC² under these settings has poor interval coverage and higher upright position error than CMA-ES in every regime. Particle depletion and likelihood/noise assumptions need investigation. These are exploratory results on one object and three held-out pushes, not evidence of general superiority of either method.

Next: inspect true-physics residuals per channel, test particle-budget and noise assumptions on development data, then repeat on fresh objects and held-out actions. Keep a new test set for the final comparison.

Detailed per-update metrics: metrics.jsonl and metrics.csv. Final aggregates: summary.json. Raw data, oracle checks, configuration, particle arrays, and plots are saved alongside this report.

# CMA-ES versus SMC² with matched cumulative replay limits

CMA-ES fits the saved datasets with the same seeds and scoring stride. Warmup is replayed but excluded from fitting. Each CMA-ES update refits the full history with three independent starts; the iteration limit is replaced by a replay cap. All earlier CMA-ES fits count toward the cumulative SMC² allowance. A final partial population is evaluated but not passed to the optimizer's tell step. Incomplete history evaluations are never performed.

Position errors use selected point hypotheses on upright development evaluation pushes, averaged over inference seeds. They are not posterior predictive mixture errors. Parameter columns are mean absolute errors. Costs below sum all fitting updates across seeds; evaluation replays are excluded.

| Sequence | Method | Position RMSE (mm) | Mass error (kg) | Friction error | COM error (mm) | Topple accuracy | Fitting replays |
|---|---|---:|---:|---:|---:|---:|---:|
| passive mixed | smc2 | 0.304 | 0.0089 | 0.0037 | 29.14 | 0.778 | 30,310 |
| passive mixed | cma_es_small | 0.777 | 0.0414 | 0.0246 | 48.61 | 0.667 | 4,410 |
| passive mixed | cma_es_matched | 1.648 | 0.0550 | 0.0121 | 41.02 | 0.667 | 30,310 |
| varied durations | smc2 | 0.176 | 0.0370 | 0.0162 | 21.06 | 0.778 | 19,929 |
| varied durations | cma_es_small | 0.334 | 0.0280 | 0.0132 | 23.26 | 0.778 | 1,260 |
| varied durations | cma_es_matched | 0.059 | 0.0073 | 0.0029 | 16.34 | 0.889 | 19,926 |

## Findings

With a comparable replay budget, CMA-ES improves the varied-duration point predictions from 0.334 to 0.059 mm, below SMC²'s 0.176 mm. It beats the SMC² point prediction on all three varied-duration seeds. On passive mixed, the matched refit policy produces 1.648 mm versus SMC²'s 0.304 mm and the small baseline's 0.777 mm. These are mixed results, not evidence of general superiority for either method.

The passive result exposes the interaction between strict per-prefix limits and refitting from scratch. The last update adds only 256 SMC² calls per seed; with carried-forward unused calls, CMA-ES receives 258. Six records per candidate means 43 candidate evaluations across three fresh starts. The existing CMA-ES implementation neither retains optimizer state nor carries its previous point forward as an incumbent. It can discard an excellent earlier fit and replace it with a poorer short-budget fit. A persistent or incumbent-preserving CMA-ES comparison remains necessary before generalizing this result. Matching only the final budget would instead measure an offline fit.

Restart seeds are `seed`, `seed+1` and `seed+2`, as in the existing implementation, so the restart sets overlap between inference seeds 1, 2 and 3. The trials are not three fully independent collections of starts.

## Per-seed final errors

| Sequence | Seed | SMC² position RMSE (mm) | Matched CMA-ES position RMSE (mm) | SMC² / CMA-ES COM error (mm) |
|---|---:|---:|---:|---|
| passive mixed | 1 | 0.320 | 0.442 | 26.29 / 37.46 |
| passive mixed | 2 | 0.265 | 0.442 | 2.83 / 37.46 |
| passive mixed | 3 | 0.326 | 4.058 | 58.30 / 48.15 |
| varied durations | 1 | 0.216 | 0.031 | 24.66 / 8.43 |
| varied durations | 2 | 0.227 | 0.127 | 14.21 / 10.94 |
| varied durations | 3 | 0.084 | 0.019 | 24.32 / 29.65 |

## Limits

This is one object and two deterministic datasets with three inference seeds. SMC² is the saved 256-particle gradual-update known-start run. The small CMA-ES baseline used ten iterations and no restarts per update. The matched comparison measures these implementations and this restart policy, not universal algorithm superiority. Replay counts match simulation calls, not physics timesteps or optimizer CPU work. Previous history fits are charged to CMA-ES; SMC² updates sequentially. Search initialization differs between methods as in the existing implementation. No posterior-calibration claims are made for CMA-ES's retained candidates.

`metrics.jsonl` records each update's allowance, actual cumulative cost, selected parameters, and development prediction errors. `config.json` hashes all reused inputs and the inference/scoring implementation for provenance.

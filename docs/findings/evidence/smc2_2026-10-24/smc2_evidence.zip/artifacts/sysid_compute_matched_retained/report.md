# CMA-ES versus SMC² with matched cumulative replay limits

The previous selected physics is rescored on the full current history and retained unless the new search has lower loss. Its replays are deducted before allocating the search budget. No previous loss or optimizer state is reused. This guarantees no worse current training loss than the incumbent, not better held-out predictions.

CMA-ES fits the saved datasets with the same seeds and scoring stride. Warmup is replayed but excluded from fitting. Each CMA-ES update refits the full history with up to 3 independent starts; the iteration limit is replaced by a replay cap. All earlier CMA-ES fits count toward the cumulative SMC² allowance. A final partial population is evaluated but not passed to the optimizer's tell step. Incomplete history evaluations are never performed.

Position errors use selected point hypotheses on upright development evaluation pushes, averaged over inference seeds. They are not posterior predictive mixture errors. Parameter columns are mean absolute errors. Costs below sum all fitting updates across seeds; evaluation replays are excluded.

| Sequence | Method | Position RMSE (mm) | Mass error (kg) | Friction error | COM error (mm) | Topple accuracy | Fitting replays |
|---|---|---:|---:|---:|---:|---:|---:|
| passive mixed | smc2 | 0.304 | 0.0089 | 0.0037 | 29.14 | 0.778 | 30,310 |
| passive mixed | cma_es_small | 0.777 | 0.0414 | 0.0246 | 48.61 | 0.667 | 4,410 |
| passive mixed | cma_es_refit | 1.648 | 0.0550 | 0.0121 | 41.02 | 0.667 | 30,310 |
| passive mixed | cma_es_matched | 0.038 | 0.0012 | 0.0005 | 12.91 | 0.889 | 30,310 |
| varied durations | smc2 | 0.176 | 0.0370 | 0.0162 | 21.06 | 0.778 | 19,929 |
| varied durations | cma_es_small | 0.334 | 0.0280 | 0.0132 | 23.26 | 0.778 | 1,260 |
| varied durations | cma_es_refit | 0.059 | 0.0073 | 0.0029 | 16.34 | 0.889 | 19,926 |
| varied durations | cma_es_matched | 0.068 | 0.0048 | 0.0019 | 8.69 | 1.000 | 19,926 |

## Findings

Retaining the previous estimate reduces passive-mixed mean position RMSE from 1.648 to 0.038 mm under the same cumulative replay limits. It avoids replacing good earlier estimates with poor short-budget refits. On varied durations, mean position RMSE changes from 0.059 to 0.068 mm, while mean mass, friction and COM errors improve. Training-loss selection does not guarantee better evaluation predictions.

The retained CMA-ES point predicts position more accurately than the selected SMC² point on all six final sequence/seed pairs. Mean COM errors also improve, but not on every seed: passive seed 2 has 31.33 mm COM error versus SMC²'s 2.83 mm. This is a point-estimation result on one object, not a comparison of posterior calibration or a general algorithm ranking.

All 27 cumulative replay limits were verified. Thirteen of 21 updates with an incumbent retained it. `audit.json` records post-fit checks that current training loss never exceeds the rescored incumbent loss; these diagnostic replays did not select candidates. The full suite passed 119 tests and Ruff checks passed.

The saved fresh-refit comparison used the same source datasets, scoring stride, seeds and restart count. Restart sets overlap between seeds 1, 2 and 3. In the table, `cma_es_matched` denotes the new retained-estimate mode and `cma_es_refit` denotes the prior comparison.

## Per-seed final errors

| Sequence | Seed | SMC² position RMSE (mm) | Matched CMA-ES position RMSE (mm) | SMC² / CMA-ES COM error (mm) |
|---|---:|---:|---:|---|
| passive mixed | 1 | 0.320 | 0.021 | 26.29 / 3.73 |
| passive mixed | 2 | 0.265 | 0.072 | 2.83 / 31.33 |
| passive mixed | 3 | 0.326 | 0.021 | 58.30 / 3.68 |
| varied durations | 1 | 0.216 | 0.043 | 24.66 / 4.58 |
| varied durations | 2 | 0.227 | 0.127 | 14.21 / 10.94 |
| varied durations | 3 | 0.084 | 0.034 | 24.32 / 10.55 |

## Limits

This is one object and two deterministic datasets with three inference seeds. SMC² is the saved 256-particle gradual-update known-start run. The small CMA-ES baseline used ten iterations and no restarts per update. The matched comparison measures these implementations and this restart policy, not universal algorithm superiority. Replay counts match simulation calls, not physics timesteps or optimizer CPU work. Previous history fits are charged to CMA-ES; SMC² updates sequentially. Search initialization differs between methods as in the existing implementation. No posterior-calibration claims are made for CMA-ES's retained candidates.

`metrics.jsonl` records each update's allowance, actual cumulative cost, selected parameters, and development prediction errors. `config.json` hashes all reused inputs and the inference/scoring implementation for provenance.

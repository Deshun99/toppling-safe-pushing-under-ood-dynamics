# Covariance-shaped proposal experiment

Same saved data, three seeds, 256 random physics particles, exact starts, gradual updates, at most two proposal attempts per particle per stage, and proposal scale 0.08. No true-physics particle is injected. The new option uses weighted particle covariance in prior-scaled z coordinates, measured before resampling and frozen during each move stage. Its trace is normalized so both kernels have the same expected squared jump length. A small diagonal floor preserves mobility; a collapsed cloud falls back to the fixed shape. There is no acceptance-based scale adaptation.

Capped arms use the saved fixed-kernel cumulative replay ceilings at every prefix. New-push likelihoods are always fully assimilated (beta reaches one); only proposal moves can be stopped. The check reserves a complete candidate history before its first replay, and never redraws an out-of-bounds proposal. Actual costs can fall below the ceilings. The uncapped covariance arm uses the original two-moves-per-stage schedule to expose effects of the cap. Replay-based stopping is a practical adaptive compute policy, not a proof of exact finite-population sampling.

Point prediction errors are for upright development evaluation pushes. COM truth inclusion is conditional on this object/dataset, not population calibration. COM grid distances compare full distributions and exist only for varied durations; lower is closer.

| Sequence | Arm | Position RMSE (mm) | COM intervals include truth | Distinct final particles, seeds 1/2/3 | Move acceptance | Fitting replays | Mean COM distance to grid (mm) |
|---|---|---:|---:|---|---:|---:|---:|
| varied durations | fixed_capped | 0.176 | 3/3 | [30, 30, 42] | 24.5% | 19,929 | 11.05 |
| varied durations | covariance_capped | 0.082 | 3/3 | [212, 225, 214] | 56.8% | 18,071 | 2.50 |
| varied durations | covariance_uncapped | 0.111 | 3/3 | [212, 216, 232] | 57.3% | 18,557 | 1.71 |
| passive mixed | fixed_capped | 0.304 | 2/3 | [15, 16, 15] | 17.1% | 30,310 | — |
| passive mixed | covariance_capped | 0.126 | 3/3 | [224, 229, 224] | 53.9% | 24,924 | — |
| passive mixed | covariance_uncapped | 0.141 | 3/3 | [248, 229, 224] | 54.3% | 26,531 | — |

## Findings

The covariance-shaped proposal materially improves the particle approximation in this development study. Under the same cumulative replay ceilings, mean COM distribution distance to the grid falls from 11.05 to 2.50 mm. Mean mass and friction marginal distances also improve, from 0.03615 to 0.00617 kg and from 0.01512 to 0.00258 respectively. Over 200 distinct particles remain in every covariance run, versus 15–42 in the fixed controls. Increased acceptance is accompanied by better distribution agreement, rather than used as a standalone success measure.

The capped covariance arm improves mean selected-point position RMSE from 0.176 to 0.082 mm for varied durations and from 0.304 to 0.126 mm for passive mixed. It uses 42,995 fitting replays versus 50,239 for the fixed arm, about 14.4% fewer. Final COM intervals contain truth in six of six runs versus five of six. These are conditional development results, not general calibration estimates.

The uncapped covariance arm also improves both prediction and grid agreement. Its mean COM grid distance is 1.71 mm, slightly better than the capped arm. Thus cap truncation is not required for the improvement; the cap does affect individual trajectories. It blocks four covariance move stages across the capped trials. Retained CMA-ES remains better on mean selected-point predictions (0.068 and 0.038 mm in the earlier comparison); actual replay spending differs.

The default remains the fixed proposal. Next validate the covariance option on fresh objects and action datasets before selecting new defaults or adding further adaptation.

![Final COM distributions](com_distribution_comparison.png)

## Final COM intervals

| Sequence | Arm | Seed | 95% COM interval (mm) | Truth included | Budget-blocked stages |
|---|---|---:|---|---|---:|
| varied durations | fixed_capped | 1 | [55.0, 104.1] | True | 0 |
| varied durations | covariance_capped | 1 | [43.1, 120.1] | True | 0 |
| varied durations | covariance_uncapped | 1 | [43.1, 120.1] | True | 0 |
| varied durations | fixed_capped | 2 | [47.3, 105.4] | True | 0 |
| varied durations | covariance_capped | 2 | [42.2, 126.1] | True | 1 |
| varied durations | covariance_uncapped | 2 | [43.2, 118.6] | True | 0 |
| varied durations | fixed_capped | 3 | [61.3, 123.3] | True | 0 |
| varied durations | covariance_capped | 3 | [47.6, 117.1] | True | 2 |
| varied durations | covariance_uncapped | 3 | [42.8, 120.6] | True | 0 |
| passive mixed | fixed_capped | 1 | [54.3, 87.2] | False | 0 |
| passive mixed | covariance_capped | 1 | [42.6, 100.9] | True | 1 |
| passive mixed | covariance_uncapped | 1 | [42.0, 100.6] | True | 0 |
| passive mixed | fixed_capped | 2 | [61.2, 110.8] | True | 0 |
| passive mixed | covariance_capped | 2 | [41.2, 101.4] | True | 0 |
| passive mixed | covariance_uncapped | 2 | [41.2, 101.4] | True | 0 |
| passive mixed | fixed_capped | 3 | [40.5, 110.3] | True | 0 |
| passive mixed | covariance_capped | 3 | [40.3, 100.6] | True | 0 |
| passive mixed | covariance_uncapped | 3 | [40.3, 100.6] | True | 0 |

## Scope and sources

One noise-free object and two development sequences; no final-test generalization claim. Covariance adaptation is a standard SMC technique ([Zhou, Johansen & Aston, section 3.3.3](https://arxiv.org/html/1303.3123v2#S3.SS3.SSS3)), but the fixed-trace normalization here is a deliberate experimental choice to isolate shape. This is not a claim to reproduce the paper's complete proposal-adaptation scheme. Narrow or curved regions may still be represented badly by one global covariance. High acceptance alone is not evidence of adequate exploration.

Per-update costs, proposal counts, posterior intervals and marginal grid distances are in metrics.jsonl. Stage matrices and cap events are in separate move-trace JSON files; NPZ files retain particles and weights. Inputs, source and dependency versions are recorded in config.json. Output directories must be new.

## Validation

130 tests passed, including analytic Gaussian posterior checks for both proposals. All 27 fixed-control snapshots and replay costs match the saved production run exactly; all 54 capped update records respect their ceilings. All 92 saved covariance-stage matrices are positive definite and have the intended prior-scaled squared jump length. A 32-point × three-record grid likelihood check gives zero discrepancy. See `validation.json`. The covariance benchmark CLI smoke run completed. Acceptance fractions count all proposal attempts, including prior-bound rejections and attempts stopped by the cap.

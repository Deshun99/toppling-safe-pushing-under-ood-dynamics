# CMA-ES versus SMC² with matched cumulative replay limits

The previous selected physics is rescored on the full current history and retained unless the new search has lower loss. Its replays are deducted before allocating the search budget. No previous loss or optimizer state is reused. This guarantees no worse current training loss than the incumbent, not better held-out predictions.

CMA-ES fits the saved datasets with the same seeds and scoring stride. Warmup is replayed but excluded from fitting. Each CMA-ES update refits the full history with up to 3 independent starts; the iteration limit is replaced by a replay cap. All earlier CMA-ES fits count toward the cumulative SMC² allowance. A final partial population is evaluated but not passed to the optimizer's tell step. Incomplete history evaluations are never performed.

Position errors use selected point hypotheses on upright development evaluation pushes, averaged over inference seeds. They are not posterior predictive mixture errors. Parameter columns are mean absolute errors. Costs below sum all fitting updates across seeds; evaluation replays are excluded.

| Sequence | Method | Position RMSE (mm) | Mass error (kg) | Friction error | COM error (mm) | Topple accuracy | Fitting replays |
|---|---|---:|---:|---:|---:|---:|---:|
| passive mixed | smc2 | 0.141 | 0.0061 | 0.0034 | 33.49 | 0.778 | 26,531 |
| passive mixed | cma_es_small | 0.777 | 0.0414 | 0.0246 | 48.61 | 0.667 | 4,410 |
| passive mixed | cma_es_matched | 0.018 | 0.0008 | 0.0000 | 16.17 | 0.889 | 26,531 |
| varied durations | smc2 | 0.111 | 0.0099 | 0.0037 | 5.02 | 1.000 | 18,557 |
| varied durations | cma_es_small | 0.334 | 0.0280 | 0.0132 | 23.26 | 0.778 | 1,260 |
| varied durations | cma_es_matched | 0.070 | 0.0044 | 0.0017 | 8.74 | 1.000 | 18,554 |

## Findings and configuration

SMC² uses the new covariance proposal, 256 random physics hypotheses, exact starts, gradual evidence updates and two proposals per particle per resampling stage. This is the normal production move schedule, without the study-only SMC move cap. The same data, seeds and loss scales are used by both estimators. CMA-ES retains and rescores its previous best estimate within the shared cumulative replay limits, using three independent starts for its new search.

CMA-ES has lower mean upright position prediction error on both sequences: 0.070 versus 0.111 mm for varied durations, and 0.018 versus 0.141 mm for passive mixed. It wins on five of the six final sequence/seed pairs. It also has lower mean mass and friction errors in both sequences. These are selected-point comparisons, not posterior predictive mixture results.

SMC² recovers COM better on varied durations: mean error 5.02 versus 8.74 mm, with lower error in all three seeds. On passive mixed the ordering reverses: 33.49 versus 16.17 mm, though SMC² is better in seed 2. Accurate position prediction does not imply accurate COM identification. The benchmark's separate marginal summaries put truth inside SMC²'s COM interval in all six runs; this is not population calibration and CMA-ES candidates do not define a posterior for comparison.

Total fitting replays are 45,088 for SMC² and 45,085 for CMA-ES. The three unused CMA-ES calls cannot fund another complete-history evaluation; all 27 cumulative limits were checked. The benchmark's 27 particle/weight snapshots exactly match the prior uncapped covariance study. The new and old raw datasets are identical. A separate post-fit audit verifies incumbent selection (`validation.json`).

Earlier covariance errors of 0.082/0.126 mm describe the capped diagnostic arm, whose move schedule differs. The current production run reproduces the uncapped arm's 0.111/0.141 mm. These results do not establish general algorithm superiority: one object, two development sequences and three inference seeds are still limited evidence. Restart seeds overlap between trials as in the previous comparison.

Reproduce using new output directories:

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 \
  --development --regimes "varied durations" "passive mixed" --seeds 1 2 3 \
  --n-theta 256 --known-start --temper-updates --proposal covariance \
  --cma-iterations 10 --cma-restarts 0 --out artifacts/sysid_covariance_benchmark_rerun
.venv/bin/python -m src.agents.system_identification.studies.compare_compute \
  --baseline artifacts/sysid_covariance_benchmark_rerun --retain-best \
  --out artifacts/sysid_covariance_vs_cma_retained_rerun
```

## Per-seed final errors

| Sequence | Seed | SMC² position RMSE (mm) | Matched CMA-ES position RMSE (mm) | SMC² / CMA-ES COM error (mm) |
|---|---:|---:|---:|---|
| passive mixed | 1 | 0.106 | 0.020 | 35.65 / 3.71 |
| passive mixed | 2 | 0.013 | 0.012 | 5.15 / 41.11 |
| passive mixed | 3 | 0.303 | 0.021 | 59.66 / 3.68 |
| varied durations | 1 | 0.109 | 0.043 | 0.01 / 4.58 |
| varied durations | 2 | 0.074 | 0.127 | 6.67 / 10.94 |
| varied durations | 3 | 0.149 | 0.041 | 8.39 / 10.70 |

## Limits

This is one object and two deterministic datasets with three inference seeds. SMC² is the saved 256-particle gradual-update known-start run. The small CMA-ES baseline used ten iterations and no restarts per update. The matched comparison measures these implementations and this restart policy, not universal algorithm superiority. Replay counts match simulation calls, not physics timesteps or optimizer CPU work. Previous history fits are charged to CMA-ES; SMC² updates sequentially. Search initialization differs between methods as in the existing implementation. No posterior-calibration claims are made for CMA-ES's retained candidates.

`metrics.jsonl` records each update's allowance, actual cumulative cost, selected parameters, and development prediction errors. `config.json` hashes all reused inputs and the inference/scoring implementation for provenance.

# More physics hypotheses: 64 versus 256

This comparison uses the corrected force-only scoring, exact measured starts (zero start uncertainty, one inner particle), stride 12, the same fixed cuboid, and inference seeds 1, 2, 3. Raw training and development evaluation data were checked for equality across runs. The proposal scale, rejuvenation count, prior, and observation noise are unchanged. Runtime is not compared because the original runs had different concurrent workloads. Replay counts are reported instead.

| Sequence | Hypotheses | Position error (mm) | Mass error (%) | COM error (mm) | COM interval includes truth (runs) | Final distinct guesses | Fitting replays |
|---|---:|---:|---:|---:|---:|---|---:|
| varied durations | 64 | 0.469 | 11.64 | 31.38 | 1/3 | [4, 5, 7] | 2731 |
| passive mixed | 64 | 1.520 | 19.18 | 43.81 | 0/3 | [7, 7, 37] | 6268 |
| varied durations | 256 | 0.229 | 7.67 | 24.43 | 2/3 | [22, 30, 14] | 9516 |
| passive mixed | 256 | 0.250 | 3.19 | 15.99 | 0/3 | [7, 13, 4] | 19688 |

More guesses helped: average prediction and parameter errors improved in both sequences. But 256 guesses still collapsed to only 4–30 distinct possibilities at the final step. COM intervals contained the truth in 2/3 varied-duration runs (previously 1/3), and 0/3 passive-mixed runs (unchanged). These are conditional results from one object and three inference seeds, not population coverage estimates.

The larger population therefore improves this experiment but does not solve overconfidence. For example, one varied-duration run reported a 95% COM interval concentrated at approximately 0.08055 m, while the true value was 0.100 m. The separately integrated posterior still allowed a broad COM range.

A reference here means a separate numerical calculation used to check the algorithm, not physical ground truth. It integrates many physics combinations using the same likelihood and prior, retaining their probability contributions instead of discarding them by resampling. Its accuracy is checked by refining independent grids.

Reproduce the larger run with:

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 \
  --development --regimes "varied durations" "passive mixed" --seeds 1 2 3 \
  --n-theta 256 --known-start --cma-iterations 10 --cma-restarts 0 \
  --out artifacts/sysid_development_known_256
```

Use a new output directory for another run. Baseline: artifacts/sysid_development_known_after. Detailed per-update metrics and plots are saved alongside this report. No production code was changed for this experiment.

# Gradual evidence updates: first comparison

We kept 256 physics hypotheses, exact starting states, warm-up excluded, stride 12, the same prior/noise scales, the same fixed random-walk proposal, and two moves per resampling stage. Only gradual evidence updates were enabled. Seeds 1, 2, 3 and both raw training/evaluation datasets match the previous run. More stages mean more total moves and replays; this comparison is not compute-matched.

| Sequence | Update | Position error (mm) | COM ranges including truth | Final distinct hypotheses | Fitting replays |
|---|---|---:|---:|---|---:|
| varied durations | baseline | 0.229 | 2/3 | [22, 30, 14] | 9516 |
| passive mixed | baseline | 0.250 | 0/3 | [7, 13, 4] | 19688 |
| varied durations | gradual | 0.176 | 3/3 | [30, 30, 42] | 19929 |
| passive mixed | gradual | 0.304 | 2/3 | [15, 16, 15] | 30310 |

## Findings in plain language

The algorithm kept more plausible COM possibilities instead of concentrating so quickly on a few guesses. The true COM was inside the reported range in 5/6 runs, compared with 2/6 previously. The COM distribution moved closer to the separate grid calculation in two of three varied-duration runs; the third was slightly worse. That grid check exists for varied durations only, so passive-mixed uncertainty was not validated against a full grid here.

Position predictions improved for varied durations but worsened slightly for passive mixed. The best-weighted COM point estimate also worsened on average for passive mixed, even though interval inclusion improved. More honest uncertainty and a better single selected guess are different objectives.

Total fitting simulations increased from 29,204 to 50,239 (1.72×). Therefore this does not prove that gradual updates beat spending the same compute on more final-posterior moves. An equal-budget control is still needed before making that claim.

## What changed mathematically

For each new push, the algorithm targets prior × likelihood of previous pushes × likelihood of the new push raised to beta. Beta starts at zero and reaches exactly one. Conditional ESS chooses intermediate steps. Resampling/moves occur between those steps, using the unchanged proposal. Previous pushes are never weakened. The final target is the same posterior as before.

This implementation intentionally requires zero start uncertainty and one inner particle. It cannot be enabled for noisy inner likelihood estimates by simply raising those estimates to powers. The default inference path remains unchanged and was checked against saved baseline particles/weights.

## Validation and limitations

Analytic Gaussian tests cover the full final likelihood, posterior moments, reproducibility, conditional ESS, and the requirement that old evidence retains full strength during intermediate moves. A replay check at 32 cached grid points × 3 observations gave zero change in likelihood, allowing comparison with the stored grid result. This remains a one-object, three-seed development study. Interval inclusion across these runs is not a population coverage guarantee.

The scheduling method follows [Zhou, Johansen & Aston, adaptive SMC](https://arxiv.org/abs/1303.3123). Neither adaptive proposal covariance nor new sensor-noise assumptions were introduced.

## Reproduce

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 \
  --development --regimes "varied durations" "passive mixed" --seeds 1 2 3 \
  --n-theta 256 --known-start --temper-updates \
  --cma-iterations 10 --cma-restarts 0 --out artifacts/sysid_tempered_rerun
```

Use a new output directory. Configuration, metrics, particle snapshots, and per-push plots are saved. metrics.jsonl includes the intermediate evidence steps for each push. baseline is artifacts/sysid_development_known_256.

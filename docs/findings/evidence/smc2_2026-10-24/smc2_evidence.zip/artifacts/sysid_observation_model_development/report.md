# Observation-model development comparison

Implemented steps 1–2 only. No tempering, adaptive proposals, rejuvenation changes, or noise-scale recalibration.

## Changes

- Shared scoring indices mask warm-up after downsampling, retaining recording phase. With stride 12 and 8 warm-up steps: 12, 24, … . Empty windows raise ValueError before assimilation.
- SMC² and CMA-ES both simulate and preserve complete warm-up records. The benchmark passes the same stride and include/exclude choice to both methods.
- Explicit known-start benchmark mode uses zero start standard deviations and one inner particle. SMC² library start-noise defaults remain unchanged.
- Historical diagnostic runs explicitly include warm-up, preserving their original observation model.

## Design

One fixed cuboid; varied-duration and passive-mixed training regimes; inference seeds 1, 2, 3; 64 outer particles; 10 CMA-ES iterations without restarts per update. The uncertain-start arm uses 8 inner particles. Replay budgets differ across methods and arms.

Three arms isolate the changes: uncertain starts with warm-up; known starts with warm-up; known starts without warm-up. JSON equality checks confirmed identical training and evaluation data across all arms. Development evaluation uses new forces/heights/durations, distinct from the original three held-out pushes. This remains development data, not a final test set.

## Position predictions

Entries are final-step upright position RMSE averaged over three seeds, in millimetres. RMSE evaluation includes all recorded trajectory samples in every arm, so changing the fitting window does not discard errors from the evaluation metric.

| Training regime | Method | Uncertain starts, include warm-up | Known starts, include warm-up | Known starts, exclude warm-up |
|---|---|---:|---:|---:|
| varied durations | smc2 | 0.580 | 1.239 | 0.469 |
| varied durations | cma_es | 1.310 | 1.310 | 0.334 |
| passive mixed | smc2 | 0.922 | 3.697 | 1.520 |
| passive mixed | cma_es | 1.519 | 1.519 | 0.777 |

Excluding warm-up improves position prediction in both regimes relative to the known-start/include-warm-up arm, for both methods. The complete change is not uniformly better than the uncertain-start reference: SMC² passive-mixed position error is worse. Zero start uncertainty is a physically appropriate numerical reference for exact simulator state, not a guaranteed optimization improvement.

## Likelihood checks

The corrected known-start likelihood at fixed true physics was identical across five independently seeded evaluations (known_start_repeatability.json).

COM likelihood profiles fix mass/friction at truth; they are not marginalized posterior distributions. In varied durations, the preferred grid height moves from 0.065 m including warm-up to 0.095 m excluding it, near the true 0.100 m. For passive mixed it moves from 0.100 m to 0.090 m, so excluding warm-up is not a universal improvement in exact COM recovery. See com_profiles.json and com_profiles.png.

## Remaining failures

Posterior interval coverage is still poor, especially for COM; collapse and limited rejuvenation remain. This work corrects the observation window and establishes a deterministic baseline, but does not resolve SMC approximation quality. Keep the same development evidence for subsequent sampler work and reserve fresh objects/actions for final evaluation.

## Validation

96 tests passed, including new scoring-window, preserved-replay, passive-action, empty-window, and known-start repeatability regressions. Ruff lint/format checks passed.

## Reproduction

Use the benchmark module with common arguments:

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 \
  --development --regimes "varied durations" "passive mixed" --seeds 1 2 3 \
  --n-theta 64 --n-state 8 --cma-iterations 10 --cma-restarts 0 \
  --include-warmup --out artifacts/sysid_development_uncertain_before
```

For known_before add --known-start and choose a new output directory. For known_after also remove --include-warmup. Particle snapshots, plots, full configuration, raw data, metrics, and summaries are in each run directory. Existing output directories are never overwritten.

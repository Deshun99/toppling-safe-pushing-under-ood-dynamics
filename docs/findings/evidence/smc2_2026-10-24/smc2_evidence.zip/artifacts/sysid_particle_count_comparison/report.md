# Particle-count experiment

Compared 256, 512 and 1,024 outer hypotheses with gradual likelihood updates. All use exact starting states, one inner state particle, two MCMC moves per resampling stage, corrected warmup exclusion and stride 12. Configurations differ only in output path and particle count. Training and held-out data are identical; seeds 1, 2 and 3 vary inference randomness.

Position RMSE below is the point-estimate prediction error on upright held-out pushes, averaged over three seeds. COM inclusion counts how many final 95% intervals contain the true height (100 mm). It is not population calibration.

| Sequence | Particles | Position RMSE (mm) | COM truth inside interval | Distinct final particles, seeds 1/2/3 | Fitting replays, all seeds |
|---|---:|---:|---:|---|---:|
| varied durations | 256 | 0.176 | 3/3 | [30, 30, 42] | 19,929 |
| passive mixed | 256 | 0.304 | 2/3 | [15, 16, 15] | 30,310 |
| varied durations | 512 | 0.326 | 3/3 | [86, 77, 78] | 37,291 |
| passive mixed | 512 | 0.110 | 1/3 | [21, 33, 42] | 44,674 |
| varied durations | 1024 | 0.165 | 3/3 | [123, 122, 118] | 74,251 |
| passive mixed | 1024 | 0.143 | 2/3 | [56, 34, 83] | 117,790 |

## Findings

More particles increased absolute diversity, but did not consistently improve inference. With 1,024 particles, only 118–123 distinct hypotheses remained after the varied-duration sequence, and 34–83 after the passive-motion sequence. Increasing the population alone did not prevent substantial duplication.

For varied durations, 512 particles matched the separate grid COM distribution more closely on all three seeds than 256 did. Increasing again to 1,024 did not preserve that improvement. All three population sizes included the true COM in all three varied-duration intervals, so truth inclusion alone hides differences in the inferred distributions.

On passive motion, both larger populations improved mean point-prediction error over 256, but COM truth inclusion was 2/3, 1/3 and 2/3 respectively. Accurate motion predictions therefore do not guarantee reliable COM uncertainty. Some interval endpoints are close to the truth, making this binary statistic sensitive; see the complete intervals below.

Total fitting cost across both sequences was 50,239, 81,965 and 192,041 replays: 1.00×, 1.63× and 3.82×. These results do not justify choosing 1,024 particles as a default. A useful next diagnostic is to improve the proposal moves at a fixed replay budget and compare the full inferred distributions. This experiment alone cannot establish which proposal change would help.

Prediction errors use the selected highest-mass hypothesis, not an average prediction over the particle population. This choice can contribute to variability, particularly when multiple particles share the highest weight.

## Individual COM intervals

| Sequence | Particles | Seed | Mean (mm) | 95% interval (mm) | Truth included |
|---|---:|---:|---:|---|---|
| varied durations | 256 | 1 | 79.9 | [55.0, 104.1] | True |
| varied durations | 256 | 2 | 76.1 | [47.3, 105.4] | True |
| varied durations | 256 | 3 | 85.6 | [61.3, 123.3] | True |
| passive mixed | 256 | 1 | 72.5 | [54.3, 87.2] | False |
| passive mixed | 256 | 2 | 95.3 | [61.2, 110.8] | True |
| passive mixed | 256 | 3 | 45.8 | [40.5, 110.3] | True |
| varied durations | 512 | 1 | 85.5 | [45.6, 140.3] | True |
| varied durations | 512 | 2 | 82.2 | [55.2, 108.2] | True |
| varied durations | 512 | 3 | 81.5 | [47.3, 118.2] | True |
| passive mixed | 512 | 1 | 88.3 | [68.2, 90.8] | False |
| passive mixed | 512 | 2 | 80.7 | [44.1, 101.7] | True |
| passive mixed | 512 | 3 | 90.5 | [81.4, 95.1] | False |
| varied durations | 1024 | 1 | 102.0 | [69.0, 119.1] | True |
| varied durations | 1024 | 2 | 76.0 | [42.1, 126.7] | True |
| varied durations | 1024 | 3 | 84.4 | [44.9, 130.7] | True |
| passive mixed | 1024 | 1 | 78.6 | [50.9, 100.5] | True |
| passive mixed | 1024 | 2 | 80.8 | [44.4, 96.7] | False |
| passive mixed | 1024 | 3 | 56.0 | [41.5, 101.4] | True |

## Agreement with the separate grid calculation

For the varied-duration sequence only, the following distance compares the entire final COM distribution with the same saved grid calculation used previously. Lower is closer; distance is in mm of COM height. The grid is a numerical approximation, not the known physical truth.

| Particles | Seed 1 | Seed 2 | Seed 3 | Mean |
|---:|---:|---:|---:|---:|
| 256 | 11.33 | 11.66 | 10.17 | 11.05 |
| 512 | 6.38 | 7.85 | 6.45 | 6.89 |
| 1024 | 16.16 | 10.29 | 7.52 | 11.32 |

## Limits

This is one object and two deterministic datasets, with three inference seeds. Particle count changes the initial random population and subsequent random-number consumption; the larger runs are not nested subsets of the smaller runs. Compute budgets are unequal. Runs were concurrent, so compare replay counts rather than wall time. There is no measurement noise here, and starting-state uncertainty is disabled. No production defaults changed.

Raw results: `../sysid_development_tempered_256`, `../sysid_development_tempered_512`, `../sysid_development_tempered_1024`. Machine-readable details and dataset/configuration checks are in `comparison.json`.

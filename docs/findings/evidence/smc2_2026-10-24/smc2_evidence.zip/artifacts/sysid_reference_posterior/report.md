# Known-start posterior reference

The reference uses the same uniform-in-z prior, observation scales, scoring window, and recorded pushes as SMC². Cells cover the full prior; their volumes enter the quadrature weights. Local refinement changes resolution, not prior probability.

Convergence checks compare independently initialized grids using normalized marginal Wasserstein distance (<0.005 of the prior range) and log-evidence change (<0.2). These are empirical stability checks, not rigorous integration-error bounds. Broad cells are integrated within each marginal; intervals invert their piecewise-uniform CDF.

| Push | Cross-grid stable | Reference mass interval (kg) | Friction interval | COM interval (m) |
|---|---|---|---|---|
| 1 | True | [0.4216, 1.6796] | [0.1090, 1.0035] | [0.0424, 0.1551] |
| 2 | True | [0.8621, 1.2724] | [0.2115, 0.3663] | [0.0422, 0.1343] |
| 3 | True | [0.9149, 1.1243] | [0.2527, 0.3402] | [0.0434, 0.1210] |

All intervals are marginal 95% intervals, not joint regions.

| Push | SMC² seed | Unique particles | COM interval (m) | Covers true COM |
|---|---|---|---|---|
| 1 | 1 | 22 | [0.0610, 0.1420] | True |
| 1 | 2 | 22 | [0.0463, 0.0650] | False |
| 1 | 3 | 32 | [0.0570, 0.1328] | True |
| 2 | 1 | 25 | [0.0741, 0.0990] | False |
| 2 | 2 | 11 | [0.0458, 0.0634] | False |
| 2 | 3 | 9 | [0.0647, 0.1207] | True |
| 3 | 1 | 4 | [0.0820, 0.0848] | False |
| 3 | 2 | 5 | [0.0452, 0.0628] | False |
| 3 | 3 | 7 | [0.0647, 0.1207] | True |

See marginals.png for the distributions, comparison.json for means, correlations and predictive distributions, and refinements.json for convergence history. Raw grids and SMC² particle snapshots are saved as NPZ files.

Reference predictive distributions use four independent batches of 256 posterior draws, with locations sampled inside grid cells. Predictive Monte Carlo errors are recorded separately. SMC² predictions use its weighted particle mixture, retaining at least 99.9% of mass. Development predictions do not influence fitting or grid refinement.

Interpretation: where the reference is stable and broad but SMC² is narrow or misses plausible regions, the difference is a sampling-approximation failure. Where a stable reference also excludes truth, investigate the likelihood model. Unconverged steps cannot adjudicate that distinction.

This is a single-object development experiment, not population calibration. No production estimator settings were changed by this runner.

## Finding

The stable reference intervals contain all three true parameters after every push. At the final push, 2/3 SMC² seeds exclude the true COM height. This directly demonstrates loss of plausible posterior mass in the particle approximation for this dataset; the corrected likelihood does not itself require those narrow COM intervals.

The next justified experiment is improved particle exploration (tempering/rejuvenation) against this deterministic reference. This result does not establish that the observation model is correct on other objects or actions.

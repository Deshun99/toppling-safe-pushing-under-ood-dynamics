# Ground-truth-particle diagnostic

## Main findings

At first resampling, truth has the best target likelihood (rank 1, allowing ties) in 12/12 injected runs. This is evidence against poor likelihood scoring of truth in the corrected known-start setup; there is no noisy inner likelihood estimation here.

Full updates retain exact truth copies in 6/6 final populations. Final exact-truth weight ranges from 89.8% to 100.0%. Once explicitly supplied, truth is strongly rewarded rather than discarded.

Gradual updates retain exact truth in 1/6 final populations and any truth descendants in 3/6. The move traces distinguish accepted moves away from the exact point from later removal of descendants by resampling. Moves at weak intermediate likelihoods may legitimately leave a high-likelihood point; a surviving neighborhood matters more than preserving its exact coordinates.

Injecting truth does not establish correct uncertainty: an artificially inserted high-density point can dominate a poorly explored population, while the integrated posterior remains broad. Inspect the grid distances below rather than interpreting truth-copy survival as sampler correctness. The original control populations can omit highly competitive physics, and their fixed random-walk proposals may fail to discover it. These findings concern the tested dataset, not all observation models.

![Weight on exact copies and their descendants](truth_survival.png)

One initial random particle is replaced by the exact known physics, without increasing its weight. Paired controls use the original population and identical RNG seeds. Both use exact starts, one inner state, corrected scoring, and two proposal attempts per particle per resampling stage. Oracle initialization is diagnostic only, not a valid performance baseline.

Exact copies, descendants, and nearby hypotheses are different: a legitimate accepted move removes an exact copy but retains its ancestry. An extinct lineage does not prove a posterior region was lost. The local ball uses Euclidean distance <=0.05 in prior-scaled z coordinates; the COM band is truth ±5 mm and does not constrain mass/friction.

Ranks compare the separately evaluated true likelihood with the current population (ties share rank). Rank 1 is best. During tempering, target ranks use full old evidence plus beta times new evidence; full-likelihood ranks are reported separately. Weights before resampling include the population's inherited weights. A good likelihood rank alone does not guarantee dominant weight.

| Sequence | Mode | Seed | Injected | Final exact copies | Final truth descendants | Distinct particles | Truth full-likelihood rank | COM band weight | COM distance to grid (mm) |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|
| varied durations | full | 1 | False | 0 | 0 | 22 | 1 | 0.000 | 18.09 |
| varied durations | full | 1 | True | 243 | 255 | 9 | 1 | 0.996 | 19.04 |
| varied durations | full | 2 | False | 0 | 0 | 30 | 1 | 0.005 | 18.00 |
| varied durations | full | 2 | True | 171 | 176 | 19 | 1 | 0.898 | 17.17 |
| varied durations | full | 3 | False | 0 | 0 | 14 | 1 | 0.027 | 8.67 |
| varied durations | full | 3 | True | 241 | 246 | 12 | 1 | 0.997 | 19.02 |
| varied durations | gradual | 1 | False | 0 | 0 | 30 | 1 | 0.198 | 11.33 |
| varied durations | gradual | 1 | True | 0 | 0 | 35 | 1 | 0.001 | 12.63 |
| varied durations | gradual | 2 | False | 0 | 0 | 30 | 1 | 0.051 | 11.66 |
| varied durations | gradual | 2 | True | 202 | 210 | 15 | 1 | 0.870 | 17.90 |
| varied durations | gradual | 3 | False | 0 | 0 | 42 | 1 | 0.191 | 10.17 |
| varied durations | gradual | 3 | True | 0 | 12 | 38 | 1 | 0.336 | 9.06 |
| passive mixed | full | 1 | False | 0 | 0 | 7 | 1 | 0.013 | — |
| passive mixed | full | 1 | True | 211 | 228 | 22 | 1 | 1.000 | — |
| passive mixed | full | 2 | False | 0 | 0 | 13 | 1 | 0.000 | — |
| passive mixed | full | 2 | True | 250 | 255 | 6 | 1 | 0.999 | — |
| passive mixed | full | 3 | False | 0 | 0 | 4 | 1 | 0.008 | — |
| passive mixed | full | 3 | True | 251 | 255 | 5 | 1 | 1.000 | — |
| passive mixed | gradual | 1 | False | 0 | 0 | 15 | 1 | 0.000 | — |
| passive mixed | gradual | 1 | True | 0 | 0 | 12 | 1 | 0.019 | — |
| passive mixed | gradual | 2 | False | 0 | 0 | 16 | 1 | 0.842 | — |
| passive mixed | gradual | 2 | True | 0 | 0 | 13 | 1 | 0.000 | — |
| passive mixed | gradual | 3 | False | 0 | 0 | 15 | 1 | 0.000 | — |
| passive mixed | gradual | 3 | True | 0 | 4 | 26 | 1 | 0.000 | — |

## First resampling with injected truth

| Sequence | Mode | Seed | beta | Truth target rank | Truth weight before | Copies after resampling |
|---|---|---:|---:|---:|---:|---:|
| varied durations | full | 1 | 1.0000 | 1 | 0.28778 | 73 |
| varied durations | full | 2 | 1.0000 | 1 | 0.09794 | 25 |
| varied durations | full | 3 | 1.0000 | 1 | 0.09321 | 24 |
| varied durations | gradual | 1 | 0.0333 | 1 | 0.01379 | 3 |
| varied durations | gradual | 2 | 0.0320 | 1 | 0.01273 | 3 |
| varied durations | gradual | 3 | 0.0404 | 1 | 0.01358 | 3 |
| passive mixed | full | 1 | 1.0000 | 1 | 0.89073 | 228 |
| passive mixed | full | 2 | 1.0000 | 1 | 0.46385 | 118 |
| passive mixed | full | 3 | 1.0000 | 1 | 0.21579 | 55 |
| passive mixed | gradual | 1 | 0.0015 | 1 | 0.01379 | 3 |
| passive mixed | gradual | 2 | 0.0014 | 1 | 0.01263 | 3 |
| passive mixed | gradual | 3 | 0.0018 | 1 | 0.01351 | 3 |

## Trace files and interpretation

Each trial JSON records pre/post resampling summaries and ancestry indices, followed by proposal/acceptance counts and indices that moved. Snapshot NPZ files store particles, weights and root ancestry after each push. Accepted descendants are not pinned at truth or protected from resampling. Counterfactual likelihood probes do not enter inference weights or consume inference RNG draws.

This is one object, two saved datasets and three seeds. Full updates and gradual updates have unequal compute. Controls replace only the injected slot, but later resampling and proposal paths can diverge. Losing an exact atom is not evidence of incorrect inference for a continuous posterior. Grid comparison is available only for varied durations and is an empirical numerical check, not ground truth.

## Instrumentation checks

All 54 control snapshots exactly reproduce the saved production particles and weights (`control_parity.json`). Four synthetic-model regressions also verify identical RNG states and proposal counts under tracing. The inference-tracing milestone passed 123 tests. The saved grid likelihood check reports zero discrepancy at 32 checked midpoints across three pushes.

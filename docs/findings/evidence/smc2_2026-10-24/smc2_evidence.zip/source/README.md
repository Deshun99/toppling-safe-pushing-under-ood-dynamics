# Simulation-Assisted Toppling-Safe Pushing

University course project. Research question: can a physics simulator serve as an RL
agent's **imagination** when adapting to objects with unknown dynamics? An
upright cuboid must be pushed toward a target without toppling. Geometry is
observable; mass `m`, object-floor friction `μ`, and vertical COM height `h_c`
are hidden and must be inferred from motion.

**Required final-stage deliverable:** execute policy-selected pushes with a
simulated robot arm. Keep the action `(h, F, τ)` and contact on the rear face's
vertical centreline; arbitrary lateral contact positions are out of scope.
Early development and internal imagination use direct-force physics. Robot
execution is planned; `src/simulation/execution/robot.py` is currently a stub.

- Full formulation, method, experiments: [`docs/project_outline.md`](docs/project_outline.md)
- Short proposal: [`docs/project_proposal.md`](docs/project_proposal.md)

## Setup

Ask Claude Code or Codex: **“Use the setup-env skill to set up this project.”**

The [setup-env skill](.claude/skills/setup-env/SKILL.md) detects your platform,
asks about CPU/GPU support and environment reuse when relevant, installs
dependencies, and verifies the setup. All dependency setup instructions live in
that skill.

## Running the project

Run commands from the repository root. Python entry points use `python -m src.<package>.<module>`;
imports follow the same `src.*` package paths. For example, run a learning exercise with
`.venv/bin/python -m src.self_learning.lesson1`.

### Automated tests

After installing `requirements.txt` in the configured environment, run:

```bash
.venv/bin/python -m pytest
```

The suite covers cuboid geometry and dynamics, normalized actions, observations,
rewards, episode termination, reset and client isolation, force execution and
wall-clock pacing, SysID replay/loss/ensemble selection, and a small real CMA-ES
run. Physics tests use headless PyBullet; no display or GPU is needed. Coverage
includes branches and writes `coverage.xml`; no minimum coverage is enforced.
The robot executor is currently tested only for its explicit
`NotImplementedError` contract.

GitHub Actions runs the suite and the existing M1 tipping script on every PR
(including new commits and reopened PRs) and every push to `main` (including
merges). It uses Ubuntu and Python 3.11 with CPU PyTorch, checks dependency
consistency, and uploads coverage and JUnit reports. GUI rendering, tutorial
scripts, and the longer SysID research studies are outside automated coverage.

Physics runs at a fixed 240 Hz (`DT = 1/240` s in `src/simulation/modelling/constants.py`)
throughout the target environment, internal simulator, and tutorial scripts.
The timestep is not configurable; GUI playback speed only changes wall-clock pacing.

### 1. Physics validation (M1 deliverable)

```bash
.venv/bin/python -m src.simulation.tools.validation.tipping_tests
```

Expected: `[PASS] gentle push`, `[PASS] violent push`, and an "Analytic
agreement" grid at 100% (the sim matches the no-tip condition
`(F/mg)(h − h_c) ≤ w/2 − μ h_c`). Non-zero exit = physics regression.

### 2. Watch the environment (GUI demo)

```bash
.venv/bin/python -m src.simulation.tools.demos.env_demo
```

A PyBullet window opens and a random agent pushes the cuboid until it topples
or reaches the target. Each episode prints the object's hidden parameters, every
decision's `(h, F, τ)`, the reward, and the max tilt (radians — 1 rad ≈ 57°).

| Flag | Default | Meaning |
|---|---|---|
| `--seed N` | `0` | seed of the first episode |
| `--episodes K` | `1` | number of episodes (each resamples the object) |
| `--speed S` | `1.0` | physics replay speed: `1.0` = real time, `0` = as fast as possible |
| `--linger S` | `2.0` | seconds the final state stays on screen |
| `--cam-dist D` | unset | debug-visualizer camera distance in m (zoom); `~0.35` is a close-up of the cuboid. Unset leaves the camera alone |

The pacing is wall-clock only — trajectories and physics are identical at any
speed. Examples:

```bash
.venv/bin/python -m src.simulation.tools.demos.env_demo --episodes 5 --speed 0.5 --linger 5   # slow motion
.venv/bin/python -m src.simulation.tools.demos.env_demo --speed 0 --linger 0                  # headless-style, instant
```

### 3. Use the environment in code

```python
from src.simulation.environment import PushEnv

env = PushEnv(gui=False)  # gui=True opens the PyBullet visualizer
obs, info = env.reset(seed=0)  # info["true_theta"] = (m, mu, h_c) — eval only
done = False
while not done:
    obs, r, terminated, truncated, info = env.step(env.action_space.sample())
    done = terminated or truncated
env.close()
```

- Action: normalized `[-1,1]³` → `(h, F, τ)` with `h ∈ [0.1H, 0.9H]`,
  `F ∈ [0, F_max]`, `τ ∈ [0.05, 0.50]` s.
- Observation: 7-dim `(d, ψ, ẋ, ψ̇, w, L, H)` — the hidden θ is never included.
- `info` keys: `true_theta`, `executed`, `toppled`, `success`, `max_tilt`
  (rad), plus the gymnasium conventions `is_success` and
  `TimeLimit.truncated` (used by the M3 RL scripts).
- `env.last_trajectory` holds the dense within-action trajectory (M2 SysID).

Import `PushAction` from `src.simulation.modelling.actions`.
For scripted physics studies, use the same `PushEnv` with a `fixed_spec` and
call `env.push(PushAction(h=h, F=F, tau=tau), warmup_steps=8)` after `reset()`. This accepts physical
units and returns an `ActionRecord` from `src.simulation.modelling.records`, including the start
state, trajectory, and warm-up count used by internal replay. It advances physics
without rewards or episode bookkeeping; use `step()` throughout RL episodes.
The study scripts explicitly handle settling and use `env.replace_object(x=...)`
to replace a fallen object while retaining its physics parameters.

- GUI pacing in code: `PushEnv(gui=True, realtime_scale=1.0)`.

Sampling bounds use the frozen `TRAINING_RANGES` dataclass in `src/simulation/environment/env.py`.
Action bounds default to `ACTION_RANGES` (50 N maximum); pass an `ActionRanges`
instance through `PushEnv(action_ranges=...)` to configure an experiment.
M3 training and calibration explicitly use 15 N for compatibility with the
original M3 policies.

### 4. System-identification studies (M2)

```bash
.venv/bin/python -m src.agents.system_identification.studies.identifiability   # E4 identifiability study
.venv/bin/python -m src.agents.system_identification.studies.calibrate_scales  # replay noise-floor calibration
```

System-identification accuracy depends on the excitation regime and replay
fidelity. `h_c` is weakly identifiable without near-tipping pushes, motivating
the ensemble + pessimistic filter. Run the study to measure current results.

### 5. RL pretraining and B1 adaptation (M3)

```bash
.venv/bin/python -m src.simulation.tools.validation.calibrate_m3                      # F_max + reward diagnostics
.venv/bin/python -m src.agents.rl.training.train_sac --probe                 # timing projections
.venv/bin/python -m src.agents.rl.training.train_sac                         # native PyTorch SAC pretraining
.venv/bin/python -m src.agents.rl.evaluation.adapt_b1 \
    --model artifacts/sac_pretrain/sac_final.pt
```

`train_sac.py` pretrains SAC with dynamics randomization (every reset samples
geometry and hidden `(m, μ, h_c)` from `TRAINING_RANGES`; the estimated
parameters are never part of the observation) and writes
`artifacts/sac_pretrain/`: `sac_final.pt` (weights, optimizer states, entropy
coefficient, and observation statistics), `config.json`, and `best_model/`.
Each best policy is saved as `best_model/best_model.pt` with its own embedded
normalization statistics and adjacent `config.json`. Replay is deliberately
excluded, so every adaptation object starts with an empty target-only buffer.
Legacy zip/pickle checkpoints cannot be loaded; retrain to produce native `.pt`
checkpoints. Historical M3 learning results do not validate this implementation.

The implementation in `src/agents/rl/sac.py` uses a tanh Gaussian actor, twin Q critics,
Polyak target updates, automatic entropy tuning, and raw-observation replay.
Observation normalization is updated during pretraining and frozen during evaluation
and adaptation; rewards are unnormalized. Time-limit truncations bootstrap from
the final observation, while true terminations do not bootstrap. Gymnasium workers
run in parallel for `--n-envs > 1`. Collection rounds up to a full vector step;
default gradient steps equal `n-envs` for a 1:1 update-to-transition ratio.

Adaptation also requires `config.json` alongside the model to restore its
physical action bounds; original M3 configs with only `f_max` are supported.
New training runs save all action bounds and accept `--f-max` (default: 15 N). Training
progress goes to `artifacts/tb/sac_pretrain/` (view with
`tensorboard --logdir artifacts/tb`). CSV metrics are always saved in the run
directory, including when TensorBoard is unavailable.

`adapt_b1.py` runs the model-free adaptation baseline (outline §10, row B1):
for each of the 8 held-out in-dist test objects it evaluates the frozen
policy zero-shot, then continues training on that object's target replay only
(≤ 20 episodes, no imagination) and prints per-object topple counts, success
rates, and interactions-to-first-success, plus means. Results land in
`artifacts/b1_adapt/results.json`.

`F_max` and the reward coefficients are **frozen** after `calibrate_m3.py`
(outline §§5.3, 11.1); their values are recorded in `config.json`. All
training output is under the gitignored `artifacts/`.

### Bayesian system identification with SMC²

`src.agents.system_identification.smc2.SMC2SysID` is an alternative to the existing CMA-ES estimator.
It maintains weighted physics hypotheses `(m, mu, h_c)` using inner particles
for uncertain measured start states, ESS-triggered resampling, and full-history
particle-MCMC moves. This is a **conditional action-replay model**, not a
continuous state tracker between pushes. Noise defaults need calibration.

```python
from src.agents.system_identification.smc2 import SMC2SysID
from src.simulation.modelling.actions import PushAction

history = []  # retain across episodes for the same object
with SMC2SysID(geometry=(w, L, H), n_theta=64, n_state=8, seed=7) as estimator:
    record = target.push(
        PushAction(h=h, F=F, tau=tau), warmup_steps=8
    )  # physical action units
    history.append(record)  # use an upright-data collection protocol
    result = estimator.update(history)  # assimilates only new records
    particles, weights = estimator.particles, estimator.weights
```

`particles` contains `(log(m), mu, h_c/H)`; use the full weighted population
for uncertainty. `result` retains the `SysIDResult` top-K interface, but its
`loss` means negative estimated log likelihood, and `point` is the particle
with greatest aggregated mass. Neither is directly comparable to CMA-ES's
minimum-loss summary. Repeated history is not counted twice; edited or shortened
history is rejected. Create a new estimator for a different object.

```bash
.venv/bin/python -m src.agents.system_identification.studies.smc2_demo --n-theta 64 --n-state 8
.venv/bin/python -m pytest tests/test_smc2.py
mkdir -p artifacts/smc2-doc
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=artifacts/smc2-doc docs/smc2.tex
```

The [LaTeX mathematics and implementation note](docs/smc2.tex) explains the
nested filters, observation likelihood, PMMH acceptance rule, project-specific
assumptions, computational cost, and uncertainty limitations. The example
reports full-ensemble means/spreads and ESS/acceptance diagnostics without
passing hidden target parameters to the estimator. Both estimators exclude
warm-up observations from fitting.

Run the headless comparison benchmark before larger inference experiments:

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 --smoke --out artifacts/sysid_smoke
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 --out artifacts/sysid_benchmark
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 --known-start --development --out artifacts/sysid_known_start
```

The benchmark records each excitation dataset once, shares it across SMC² and
CMA-ES seeds, and evaluates point predictions on separate held-out pushes.
Training retains only upright records; rejected records remain in the dataset
audit. Held-out topples remain in evaluation. True-physics replay errors are
saved separately to measure reconstruction mismatch. Both estimators are
evaluated after each accepted push, with fitting time and replay counts;
their budgets are configurable but are not automatically compute-matched.

Outputs include raw action records, configuration and dependency versions,
`metrics.jsonl`, `metrics.csv`, `summary.json`, and per-update SMC² particle
snapshots (`.npz`) and plots (`.png`). Summaries report marginal 95% interval
coverage across inference seeds for the current fixed object and dataset;
this is not population calibration or a joint credible region. The smoke run
uses deliberately tiny budgets and checks the pipeline, not estimator quality.
Output directories must be new to prevent overwriting earlier experiments.

The known-start reference uses `start_std=(0, 0, 0, 0)` and `n_state=1`;
the SMC² library's uncertain-start defaults are unchanged. Both estimators
exclude warm-up observations from scoring while replaying the full warm-up.
The benchmark supplies the same `--sample-stride` (default 12) to both methods.
Indices retain the recording's original phase: with 8 warm-up steps, score
samples 12, 24, … . An empty scoring window raises an error rather than
silently using no evidence. Warm-up exclusion is unconditional.
Use `--development` for development evaluation actions distinct
from the original held-out set. Existing loss/noise scales have not been
recalibrated as part of this scoring-window change.

To diagnose numerical likelihood variance and outer-particle depletion using a
saved benchmark dataset (without selecting settings on held-out pushes):

```bash
.venv/bin/python -m src.agents.system_identification.studies.diagnostics.diagnose_smc2 \
    --dataset artifacts/sysid_benchmark_initial/dataset_varied_magnitudes.json \
    --config artifacts/sysid_benchmark_initial/config.json \
    --out artifacts/smc2_diagnosis
```

This repeats likelihood estimates at fixed true physics, profiles COM likelihood
with and without warm-up samples, and compares inner/outer particle counts,
known-start-state likelihoods, and rejuvenation budgets. Known truth is used
for diagnostics and error reporting; fitted variants receive only geometry and
recorded observations. Estimator probes and ablations now exclude warm-up;
rerunning them will not reproduce the historical include-warm-up results.

The known-start grid reference separates sampling failure from likelihood
mismatch without changing either estimator:

```bash
.venv/bin/python -m src.agents.system_identification.studies.diagnostics.reference_posterior
```

It loads the saved development dataset, integrates over the full uniform-in-z
prior using volume-weighted cells, and refines two independently initialized
grids. It compares marginal distributions, correlations, 95% intervals, and
development predictive distributions with SMC² after each push. Outputs include
`report.md`, `marginals.png`, `comparison.json`, convergence logs, and grid/particle
snapshots under `artifacts/sysid_reference_posterior/`. Stability is checked
empirically; unconverged steps are explicitly flagged. Reference predictive
integration uses independent Monte Carlo batches with reported errors.

Use `--resume` to reuse likelihood checkpoints and increase `--refinements`;
input data, likelihood source files, scoring settings, and dependency versions
must match the cache. Each refinement pass caps new cell evaluations with
`--max-new-cells` (default 20000); no prior region is discarded. Initial grids
are controlled by `--grids` (default 12 and 24 cells per dimension).

Gradual evidence updates are opt-in for the deterministic known-start case:

```bash
.venv/bin/python -m src.agents.system_identification.studies.benchmark_smc2 \
    --development --regimes "varied durations" "passive mixed" --seeds 1 2 3 \
    --n-theta 256 --known-start --temper-updates \
    --cma-iterations 10 --cma-restarts 0 --out artifacts/sysid_tempered_run
```

In the API, set `temper_updates=True`, `start_std=(0, 0, 0, 0)` and `n_state=1`.
Each new push is introduced through intermediate likelihood powers, ending at
the full likelihood. Previous pushes remain at full strength. Conditional ESS
controls step sizes using the existing `ess_fraction`; the existing proposal
and `mcmc_steps` are used at each intermediate resampling stage. This follows
the adaptive tempering approach of [Zhou, Johansen & Aston](https://arxiv.org/abs/1303.3123).
The mode rejects uncertain starts and `ess_fraction=1`, and does not change
the default inference path. Stage powers, weights' ESS, and distinct-particle
counts are recorded in `fit.tempering_history` and benchmark metrics. Extra
stages require extra replays, so compare measured costs as well as accuracy.

The default `proposal="covariance"` kernel shapes Gaussian moves using the
weighted particle covariance before each resampling. It is frozen within the
move stage, regularized, and normalized to keep the same expected squared step
length as the fixed kernel in prior-scaled coordinates. This changes the
proposal shape without acceptance-based step-size tuning. Select
`proposal="fixed"` or `--proposal fixed` to reproduce the previous kernel.
The benchmark and demo also default to covariance. Historical diagnostic
runners explicitly select the fixed kernel to preserve their comparisons.

For a comparison using the saved gradual-update development datasets:

```bash
.venv/bin/python -m src.agents.system_identification.studies.compare_proposals \
    --out artifacts/sysid_covariance_proposals
```

It checks the fixed control against saved particles and compares covariance
arms with and without cumulative replay ceilings. Budget limits can stop move
attempts but never stop evidence assimilation before the full likelihood.
Actual replay consumption, distinct particles, marginal intervals, prediction
errors, and distances to the separate grid calculation are reported. The
comparison uses random initial populations, without an injected truth particle.

To give CMA-ES the cumulative fitting replay allowances from a saved known-start
SMC² experiment, reusing its exact datasets and inference seeds:

```bash
.venv/bin/python -m src.agents.system_identification.studies.compare_compute \
    --baseline artifacts/sysid_development_tempered_256 \
    --out artifacts/sysid_compute_matched
```

CMA-ES uses three independent starts per update and refits the full history.
All earlier fits count against the cumulative allowance. Complete-history
evaluations can leave fewer than one history's worth of replays unused.
The API accepts `SysID.update(history, replay_budget=...)` to cap a single
update; this replaces the iteration limit and splits candidate evaluations
across the configured starts. Omitting the cap preserves the iteration budget.
The comparison includes the small-budget baseline, parameter errors, and point
prediction errors. It measures replay calls rather than physics timesteps;
refitting and sequential updating can spend those calls differently.

To distinguish poor truth likelihoods from particle loss in the corrected
known-start setup, run the oracle diagnostic:

```bash
.venv/bin/python -m src.agents.system_identification.studies.diagnostics.trace_truth_particle \
    --out artifacts/sysid_truth_particle_trace
```

It replaces one initial particle with exact known physics at equal weight and
traces likelihood ranks, pre/post resampling weights, ancestry and proposal
acceptances. Paired controls keep the original random particle; full and
gradual updates are tested separately. Exact copies, descendants and nearby
hypotheses are tracked separately. This privileged initialization is a
diagnostic, not a performance benchmark or a proposal to protect truth in
production. Outputs include JSON traces, particle snapshots, a report and a
survival plot. The default input is the saved 256-particle development dataset.

To retain the previous best CMA-ES physics as a candidate at each update:

```bash
.venv/bin/python -m src.agents.system_identification.studies.compare_compute \
    --retain-best --refit-comparison artifacts/sysid_compute_matched \
    --out artifacts/sysid_compute_matched_retained
```

The previous estimate is rescored on the complete current history, with its
replays charged to the same limit before allocating the new search budget.
The optional saved refit comparison is checked against the baseline inputs.
In the API, pass `incumbent=previous_result.point.theta` to `SysID.update`.
This preserves a candidate, not optimizer state or an old loss. It guarantees
no worse current training loss than that candidate, not improved prediction.

## Repo layout

```text
src/
├── simulation/
│   ├── modelling/                 # Cuboids, constants, action records
│   ├── execution/                 # Direct-force and robot executors
│   ├── environment/               # Target Gymnasium environment and rewards
│   └── tools/
│       ├── demos/                 # Interactive environment demo
│       └── validation/            # Tipping checks and M3 calibration
├── agents/
│   ├── rl/
│   │   ├── sac.py                 # Native PyTorch SAC and replay buffer
│   │   ├── training/              # Dynamics-randomized pretraining
│   │   └── evaluation/            # B1 target adaptation
│   ├── system_identification/
│   │   ├── sysid.py               # CMA-ES estimator
│   │   ├── smc2.py                # Bayesian SMC² estimator
│   │   ├── scoring.py             # Shared observation window
│   │   └── studies/               # Demo, calibration, experiments, shared helpers
│   │       └── diagnostics/       # Likelihood diagnosis and grid posterior checks
│   └── simulator/                 # Agent's internal physics replay
└── self_learning/                 # Personal PyBullet lessons and playlist
```

`docs/` contains the project specifications and reference materials; `scripts/`
contains only the macOS PyBullet build shell script.

See the [System Identification guide](src/agents/system_identification/README.md)
for the role of each study and which tools are needed for normal evaluation.

For conventions (action space, episode budget, friction convention) and project
status, see [`CLAUDE.md`](.claude/CLAUDE.md).

## AI coding assistants

Claude Code and Codex share the same project instructions and simulation skill:

- `AGENTS.md` → `.claude/CLAUDE.md`
- `.agents/skills/run-sim` → `.claude/skills/run-sim`
- `.agents/skills/setup-env` → `.claude/skills/setup-env`

These are relative symlinks. Edit the files under `.claude/` to keep both
assistants in sync. When adding a Claude skill, add a matching symlink under
`.agents/skills/` for Codex discovery.

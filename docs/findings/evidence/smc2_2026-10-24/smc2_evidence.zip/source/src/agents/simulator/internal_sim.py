"""Headless action replay under candidate object physics."""

import math

import pybullet as p
import pybullet_data

from src.simulation.modelling.constants import DT, GRAVITY
from src.simulation.modelling.object import Cuboid, CuboidSpec
from src.simulation.modelling.records import ActionRecord
from src.simulation.execution.force_push import DenseTrajectory, ForcePushExecutor


class InternalSim:
    """
    Headless internal PyBullet client — the agent's imagination engine
    (outline §5.1). Replays recorded actions under candidate physics.
    """

    def __init__(self) -> None:
        self.client = p.connect(p.DIRECT)
        p.setGravity(0, 0, GRAVITY, physicsClientId=self.client)
        p.setTimeStep(DT, physicsClientId=self.client)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        self.plane = p.loadURDF("plane.urdf", physicsClientId=self.client)
        p.changeDynamics(
            self.plane, -1, lateralFriction=1.0, physicsClientId=self.client
        )
        self.executor = ForcePushExecutor(self.client)

    def replay(self, spec: CuboidSpec, record: ActionRecord) -> DenseTrajectory:
        """Spawn a cuboid with the candidate spec at the recorded start state
        and re-execute the recorded action."""
        x0, psi0, vx0, wy0 = record.start
        cuboid = Cuboid(spec, self.client)

        # Body-frame origin is the geometric centre; place the lowest corner
        # exactly on the floor at the recorded tilt.
        z0 = (spec.H / 2.0) * math.cos(psi0) + (spec.w / 2.0) * abs(math.sin(psi0))
        orn = p.getQuaternionFromEuler([0.0, psi0, 0.0])
        cuboid.spawn(position=(x0, 0.0, z0), orientation=orn)

        p.resetBaseVelocity(
            cuboid.body, [vx0, 0.0, 0.0], [0.0, wy0, 0.0], physicsClientId=self.client
        )
        traj = self.executor.execute(
            cuboid,
            h=record.action.h,
            F=record.action.F,
            tau=record.action.tau,
            warmup_steps=record.warmup_steps,
        )
        cuboid.remove()
        return traj

    def close(self) -> None:
        p.disconnect(physicsClientId=self.client)

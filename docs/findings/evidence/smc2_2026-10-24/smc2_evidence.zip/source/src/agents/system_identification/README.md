# System identification

The package root contains estimator code. `studies/` contains runnable research
tools; none of them is required to call either estimator.

## Runtime code

| File | Purpose |
|---|---|
| `sysid.py` | CMA-ES estimator, physics parameter transforms, hypothesis/result dataclasses, and trajectory loss. |
| `smc2.py` | SMC² estimator with covariance-shaped proposals by default, optional gradual evidence updates, diagnostics, and posterior plotting. |
| `scoring.py` | Shared scoring indices; warmup is replayed but excluded from fitting. |

## Research entry points

Run modules from the repository root using `.venv/bin/python -m` followed by
the module name below. Output artifacts are separate from source code.

| Module suffix after `src.agents.system_identification.studies.` | Role | When to use |
|---|---|---|
| `smc2_demo` | Demonstration | Inspect the estimator API and posterior plots after each push. Also the VS Code debug entry point. |
| `identifiability` | Research experiment | Study how push forces, heights, durations, and passive motion reveal physical parameters. |
| `calibrate_scales` | Calibration | Measure replay discrepancy at known physics before explicitly revising loss scales. Prints results without rewriting estimator constants. |
| `benchmark_smc2` | Main comparison | Collect shared datasets and compare CMA-ES and SMC² errors, particle diversity, and replay costs. |
| `compare_compute` | Budget comparison | Give CMA-ES the saved SMC² cumulative replay limits; optionally retain its previous best estimate with `--retain-best`. |
| `compare_proposals` | Sampler comparison | Compare fixed and covariance-shaped proposals, grid agreement, and costs under shared replay ceilings, with an uncapped control. |
| `diagnostics.diagnose_smc2` | Failure investigation | Probe likelihood variance, collapse, residuals, COM likelihood profiles, and controlled ablations. |
| `diagnostics.reference_posterior` | Numerical posterior check | Integrate the same prior/likelihood on refined grids to distinguish sampling failure from model mismatch. Can be expensive. |
| `diagnostics.trace_truth_particle` | Oracle diagnostic | Insert exact physics at equal weight and track scores, resampling ancestry and accepted moves, alongside paired controls. Not a performance benchmark. |

The diagnostic tools were introduced while debugging SMC². They are retained to
reproduce the investigation and check future sampler changes. They are not
part of normal inference. The grid tool is particularly useful when a sampler
reports suspiciously narrow uncertainty. Their module paths moved under
`studies.diagnostics`; older saved commands may use the former paths.

`studies/common.py` is not a runnable experiment. It holds shared record loading,
replay accounting, and weighted quantiles, so comparisons do not import dataset
helpers from a diagnostic script. Other reusable benchmark metrics stay in
`benchmark_smc2.py`.

## Where to start

For a walkthrough, run `smc2_demo`. For measured comparisons, run
`benchmark_smc2 --smoke` first. Diagnostic tools are not prerequisites.

The [project README](../../../README.md) has commands and experiment options.
The [findings handoff](../../../docs/findings/smc2_development_handoff.md)
records the evidence, limitations, and next experiments. Saved historical
artifacts remain unchanged. Moving source or changing shared code can invalidate
grid cache identities; do not bypass cache checks to resume an old calculation.

"""Compare SMC² and CMA-ES on shared excitation data and held-out pushes.

Run with --smoke to check the pipeline before spending a larger replay budget.
Seeds vary inference randomness; target data are deterministic, noise-free
simulator measurements shared across seeds. Coverage is therefore conditional
on this object and dataset, not a population calibration guarantee.
"""

import argparse
from collections.abc import Sequence
from contextlib import ExitStack
from dataclasses import asdict, replace
import csv
from importlib.metadata import version
import json
from pathlib import Path
import time
import subprocess

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from src.agents.system_identification.studies.common import (
    CountingSim,
    compute_weighted_quantiles,
)
from src.agents.simulator.internal_sim import InternalSim
from src.agents.system_identification.smc2 import CHANNELS, SMC2SysID
from src.agents.system_identification.studies.identifiability import (
    SPEC,
    WARMUP,
    regimes,
    settle_or_reset,
)
from src.agents.system_identification.sysid import SysID
from src.simulation.environment.env import PushEnv
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord

UPRIGHT_TILT_LIMIT = 0.15  # Observable cutoff, independent of hidden COM.
PARAMETERS = ("m", "mu", "h_c")


def collect_records(
    actions: Sequence[PushAction],
    *,
    independent: bool,
) -> tuple[list[ActionRecord], list[dict]]:
    """Record one dataset; retain rejected pushes in the audit trail.

    Training follows the existing excitation sequences, including passive
    intervals after motion. High pushes start settled, using only geometry to
    choose when to settle. Held-out pushes each start in a fresh episode.
    """
    target = PushEnv(fixed_spec=SPEC)
    records = []
    audit = []
    try:
        target.reset(seed=0)
        for action in actions:
            if independent:
                target.reset(seed=0)
            elif action.h >= 0.5 * SPEC.H:
                settle_or_reset(target)
            record = target.push(action, warmup_steps=WARMUP)
            accepted = (
                max(abs(value) for value in record.traj.psi) <= UPRIGHT_TILT_LIMIT
            )
            audit.append({"accepted_for_fitting": accepted, "record": asdict(record)})
            if accepted or independent:
                records.append(record)
            else:
                target.reset(seed=0)
    finally:
        target.close()
    return records, audit


def evaluate_predictions(
    sim: InternalSim,
    spec: CuboidSpec,
    records: Sequence[ActionRecord],
) -> dict[str, float]:
    """Point-prediction errors; held-out topples remain in evaluation.

    Toppling uses each object's own critical angle. Full-topple trajectory
    errors can be chaotic, so also report upright-only trajectory errors.
    """
    errors = {channel: [] for channel in CHANNELS}
    upright_errors = {channel: [] for channel in CHANNELS}
    matches = []
    for record in records:
        predicted = sim.replay(spec, record)
        actual_topple = max(abs(value) for value in record.traj.psi) > SPEC.crit_tilt
        predicted_topple = max(abs(value) for value in predicted.psi) > spec.crit_tilt
        matches.append(actual_topple == predicted_topple)
        for channel in CHANNELS:
            actual = np.asarray(getattr(record.traj, channel))
            simulated = np.asarray(getattr(predicted, channel))
            if actual.shape != simulated.shape or predicted.t != record.traj.t:
                raise ValueError("Held-out replay must align with target samples")
            squared_errors = (actual - simulated) ** 2
            errors[channel].extend(squared_errors)
            if not actual_topple:
                upright_errors[channel].extend(squared_errors)
    result = {
        f"rmse_{channel}": float(np.sqrt(np.mean(values)))
        for channel, values in errors.items()
    }
    result.update(
        {
            f"upright_rmse_{channel}": float(np.sqrt(np.mean(values)))
            for channel, values in upright_errors.items()
            if values
        }
    )
    result["topple_accuracy"] = float(np.mean(matches))
    return result


def summarize_particles(fit: SMC2SysID, spec: CuboidSpec = SPEC) -> dict:
    """Summarize the full posterior, not only the retained top-K set."""
    theta = fit.particles
    theta[:, 0] = np.exp(theta[:, 0])
    theta[:, 2] *= spec.H
    weights = fit.weights
    result = {}
    for index, (name, truth) in enumerate(zip(PARAMETERS, spec.theta)):
        low, median, high = compute_weighted_quantiles(
            theta[:, index], weights, (0.025, 0.5, 0.975)
        )
        result[name] = {
            "mean": float(weights @ theta[:, index]),
            "median": float(median),
            "low_95": float(low),
            "high_95": float(high),
            "covers_truth": bool(low <= truth <= high),
        }
    return result


def run_trial(
    args: argparse.Namespace,
    regime: str,
    seed: int,
    training: list[ActionRecord],
    held_out: list[ActionRecord],
    output: Path,
) -> list[dict]:
    geometry = (SPEC.w, SPEC.L, SPEC.H)
    rows = []
    with ExitStack() as stack:
        smc_sim = CountingSim()
        stack.callback(smc_sim.close)
        cma = SysID(
            geometry,
            iterations=args.cma_iterations,
            restarts=args.cma_restarts,
            seed=seed,
            sample_stride=args.sample_stride,
        )
        stack.callback(cma.close)
        cma.sim.close()
        cma.sim = CountingSim()
        evaluation_sim = InternalSim()
        stack.callback(evaluation_sim.close)
        fit = SMC2SysID(
            geometry,
            n_theta=args.n_theta,
            n_state=args.n_state,
            seed=seed,
            sim=smc_sim,
            sample_stride=args.sample_stride,
            **({"start_std": (0, 0, 0, 0)} if args.known_start else {}),
            temper_updates=args.temper_updates,
            proposal=args.proposal,
        )
        for step in range(1, len(training) + 1):
            history = training[:step]
            for method, estimator, simulator in (
                ("smc2", fit, smc_sim),
                ("cma_es", cma, cma.sim),
            ):
                before = simulator.replay_count
                start = time.perf_counter()
                result = estimator.update(history)
                elapsed = time.perf_counter() - start
                estimate = np.asarray(result.point.theta)
                candidate = replace(
                    SPEC, m=estimate[0], mu=estimate[1], h_c=estimate[2]
                )
                row = {
                    "regime": regime,
                    "seed": seed,
                    "step": step,
                    "method": method,
                    "theta": estimate.tolist(),
                    "absolute_error": np.abs(estimate - SPEC.theta).tolist(),
                    "fit_seconds": elapsed,
                    "fit_replays": simulator.replay_count - before,
                    "cumulative_fit_replays": simulator.replay_count,
                    "held_out": evaluate_predictions(
                        evaluation_sim, candidate, held_out
                    ),
                }
                row["relative_mass_error"] = float(abs(estimate[0] - SPEC.m) / SPEC.m)
                row["com_error_fraction_height"] = float(
                    abs(estimate[2] - SPEC.h_c) / SPEC.H
                )
                if method == "smc2":
                    row.update(
                        {
                            "posterior": summarize_particles(fit),
                            "pre_resample_ess": fit.last_ess,
                            "unique_particles": len(np.unique(fit.particles, axis=0)),
                            "resampling_count": fit.resampling_count,
                            "pmmh_acceptances": fit.acceptances,
                            "pmmh_proposals": fit.proposals,
                            "tempering_stages": [
                                event
                                for event in fit.tempering_history
                                if event["step"] == step
                            ],
                        }
                    )
                    stem = output / f"{regime.replace(' ', '_')}_seed{seed}_step{step}"
                    np.savez_compressed(
                        stem.with_suffix(".npz"), z=fit.particles, weights=fit.weights
                    )
                    figure = fit.plot_particle_distribution(ground_truth=SPEC.theta)
                    figure.suptitle(f"{regime} · seed {seed} · {step} accepted pushes")
                    figure.savefig(stem.with_suffix(".png"), dpi=100)
                    plt.close(figure)
                rows.append(row)
                print(
                    f"{regime} seed={seed} step={step} {method}: "
                    f"theta={estimate.round(4)} replays={row['fit_replays']}",
                    flush=True,
                )
    return rows


def save_summary(rows: list[dict], output: Path) -> None:
    """Save tabular learning curves and final-step summaries across seeds."""
    table = []
    for row in rows:
        table.append(
            {
                key: row[key]
                for key in (
                    "regime",
                    "seed",
                    "step",
                    "method",
                    "fit_seconds",
                    "fit_replays",
                    "cumulative_fit_replays",
                    "relative_mass_error",
                    "com_error_fraction_height",
                )
            }
            | row["held_out"]
            | {
                f"absolute_error_{name}": error
                for name, error in zip(PARAMETERS, row["absolute_error"])
            }
        )
    if not table:
        return
    fields = sorted(set().union(*(row.keys() for row in table)))
    with (output / "metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(table)
    final = {}
    for row in rows:
        final[row["regime"], row["method"], row["seed"]] = row
    summary = []
    groups = sorted({(row["regime"], row["method"]) for row in rows})
    for regime, method in groups:
        trials = [row for (r, m, _), row in final.items() if (r, m) == (regime, method)]
        group = {
            "regime": regime,
            "method": method,
            "trials": len(trials),
            "mean_absolute_error": np.mean(
                [row["absolute_error"] for row in trials], axis=0
            ).tolist(),
            "mean_held_out": {
                key: float(np.mean([row["held_out"][key] for row in trials]))
                for key in trials[0]["held_out"]
            },
        }
        if method == "smc2":
            group["conditional_coverage_95"] = {
                name: float(
                    np.mean([row["posterior"][name]["covers_truth"] for row in trials])
                )
                for name in PARAMETERS
            }
        summary.append(group)
    (output / "summary.json").write_text(json.dumps(summary, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("artifacts/sysid_benchmark"))
    parser.add_argument(
        "--regimes",
        nargs="+",
        choices=list(regimes()),
        default=["varied magnitudes", "varied heights", "tilt boundary"],
    )
    parser.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3])
    parser.add_argument("--n-theta", type=int, default=128)
    parser.add_argument("--n-state", type=int, default=32)
    parser.add_argument(
        "--proposal", choices=("fixed", "covariance"), default="covariance"
    )
    parser.add_argument(
        "--known-start",
        action="store_true",
        help="Noise-free reference: zero start uncertainty and one inner particle",
    )
    parser.add_argument(
        "--sample-stride",
        type=int,
        default=12,
        help="Same observation indices for SMC² and CMA-ES",
    )
    parser.add_argument(
        "--development",
        action="store_true",
        help="Use separate development evaluation actions, not the original held-out set",
    )
    parser.add_argument("--cma-iterations", type=int, default=20)
    parser.add_argument("--cma-restarts", type=int, default=2)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument(
        "--temper-updates",
        action="store_true",
        help="Gradually introduce each push; requires --known-start",
    )
    args = parser.parse_args()
    if args.smoke:
        args.regimes = ["varied magnitudes", "varied heights"]
        args.seeds = [1, 2]
        args.n_theta, args.n_state = 8, 2
        args.cma_iterations, args.cma_restarts = 2, 0
    if args.known_start:
        args.n_state = 1
    if args.temper_updates and not args.known_start:
        parser.error("--temper-updates requires --known-start")
    if (
        min(args.n_theta, args.n_state, args.cma_iterations, args.sample_stride) < 1
        or args.cma_restarts < 0
    ):
        parser.error(
            "Particle counts and iterations must be positive; restarts nonnegative"
        )
    args.out.mkdir(parents=True, exist_ok=False)
    config = vars(args) | {
        "out": str(args.out),
        "object": asdict(SPEC),
        "upright_tilt_limit": UPRIGHT_TILT_LIMIT,
        "note": __doc__,
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True
        ).strip(),
        "git_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True)
        ),
        "versions": {
            name: version(name) for name in ("numpy", "scipy", "pybullet", "cma")
        },
    }
    (args.out / "config.json").write_text(json.dumps(config, indent=2))
    evaluation_actions = (
        [
            PushAction(h=0.25 * SPEC.H, F=4.25, tau=0.18),
            PushAction(h=0.55 * SPEC.H, F=4.75, tau=0.22),
            PushAction(h=0.70 * SPEC.H, F=4.25, tau=0.25),
        ]
        if args.development
        else [
            PushAction(h=0.2 * SPEC.H, F=4.5, tau=0.2),
            PushAction(h=0.4 * SPEC.H, F=6.0, tau=0.15),
            PushAction(h=0.75 * SPEC.H, F=12.0, tau=0.3),
        ]
    )
    held_out, audit = collect_records(evaluation_actions, independent=True)
    (args.out / "held_out.json").write_text(json.dumps(audit, indent=2))
    oracle_sim = InternalSim()
    try:
        oracle = evaluate_predictions(oracle_sim, SPEC, held_out)
    finally:
        oracle_sim.close()
    (args.out / "oracle.json").write_text(json.dumps(oracle, indent=2))
    all_rows = []
    with (args.out / "metrics.jsonl").open("w") as stream:
        for regime in args.regimes:
            actions = regimes()[regime]
            if args.smoke:
                actions = actions[:2]
            training, audit = collect_records(actions, independent=False)
            name = regime.replace(" ", "_")
            (args.out / f"dataset_{name}.json").write_text(json.dumps(audit, indent=2))
            oracle_sim = InternalSim()
            try:
                training_oracle = (
                    evaluate_predictions(oracle_sim, SPEC, training) if training else {}
                )
            finally:
                oracle_sim.close()
            (args.out / f"oracle_{name}.json").write_text(
                json.dumps(training_oracle, indent=2)
            )
            if not training:
                print(f"Skipping {regime}: no upright training records", flush=True)
                continue
            for seed in args.seeds:
                rows = run_trial(args, regime, seed, training, held_out, args.out)
                all_rows.extend(rows)
                for row in rows:
                    stream.write(json.dumps(row) + "\n")
                stream.flush()
    save_summary(all_rows, args.out)
    print(f"Saved benchmark to {args.out}")


if __name__ == "__main__":
    main()

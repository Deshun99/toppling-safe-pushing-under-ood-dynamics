"""Calibrate LOSS_SCALES — the replay-fidelity noise floor (outline §6).

Replays a recorded history in the internal simulator using the TRUE spec and
measures the per-sample mean squared error per trajectory quantity: the
irreducible mismatch between the target sim and the internal sim even when
the physics is exactly known. These values become the 1/sigma^2 scales in
src/agents/system_identification/sysid.py, so each quantity is weighted by its own reproducibility
rather than by its SI-unit amplitude (position errors are ~1e6 larger than
tilt errors in raw units and would otherwise drown the terms that identify
h_c).

Run from the repo root:  .venv/bin/python -m src.agents.system_identification.studies.calibrate_scales
Then paste the printed scales into LOSS_SCALES in src/agents/system_identification/sysid.py.
"""

import numpy as np

from src.simulation.environment.env import PushEnv
from src.simulation.modelling.records import ActionRecord
from src.agents.simulator.internal_sim import InternalSim
from src.agents.system_identification.studies.identifiability import (
    SPEC,
    WARMUP,
    regimes,
    settle_or_reset,
)


def main() -> None:
    target = PushEnv(fixed_spec=SPEC)
    sim = InternalSim()
    target.reset()
    history: list[ActionRecord] = []
    for action in regimes()["full mixed"]:
        if action.h > SPEC.h_c:  # same settle logic as the study script
            settle_or_reset(target)
        history.append(target.push(action, warmup_steps=WARMUP))

    sse = {k: 0.0 for k in ("x", "psi", "xdot", "psidot")}
    n = {k: 0 for k in sse}
    for rec in history:
        replay = sim.replay(SPEC, rec)
        for k in sse:
            a = np.asarray(getattr(rec.traj, k))
            b = np.asarray(getattr(replay, k))
            m = min(len(a), len(b))
            sse[k] += float(np.sum((a[:m] - b[:m]) ** 2))
            n[k] += m

    print(
        "Per-sample replay MSE at the true theta (noise floor) and recommended scales:"
    )
    print("    LOSS_SCALES = {")
    for k in sse:
        mse = sse[k] / n[k]
        print(f'        "{k}": {n[k] / sse[k]:.3e},   # mse {mse:.3e}')
    print("    }")

    target.close()
    sim.close()


if __name__ == "__main__":
    main()

"""Shared replay accounting, dataset loading, and statistics for studies.

This module defines no CLI and does not collect data or run inference on import.
"""

from collections.abc import Sequence
import json
from pathlib import Path

import numpy as np
from numpy.typing import NDArray

from src.agents.simulator.internal_sim import InternalSim
from src.simulation.execution.force_push import DenseTrajectory
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord


class CountingSim(InternalSim):
    """Count fitting replays separately from held-out evaluation replays."""

    def __init__(self) -> None:
        super().__init__()
        self.replay_count = 0

    def replay(self, spec: CuboidSpec, record: ActionRecord) -> DenseTrajectory:
        self.replay_count += 1
        return super().replay(spec, record)


def compute_weighted_quantiles(
    values: NDArray[np.float64],
    weights: NDArray[np.float64],
    probabilities: Sequence[float],
) -> NDArray[np.float64]:
    """Inverse empirical CDF, retaining discrete mass and repeated particles."""
    order = np.argsort(values)
    cumulative = np.cumsum(weights[order]) / np.sum(weights)
    indices = np.searchsorted(cumulative, probabilities, side="left")
    return values[order[np.clip(indices, 0, len(values) - 1)]]


def load_training(path: Path) -> list[ActionRecord]:
    """Reconstruct the exact accepted records saved by the benchmark."""
    records = []
    for entry in json.loads(path.read_text()):
        if not entry["accepted_for_fitting"]:
            continue
        record = entry["record"]
        records.append(
            ActionRecord(
                start=tuple(record["start"]),
                action=PushAction(**record["action"]),
                traj=DenseTrajectory(**record["traj"]),
                warmup_steps=record["warmup_steps"],
            )
        )
    return records

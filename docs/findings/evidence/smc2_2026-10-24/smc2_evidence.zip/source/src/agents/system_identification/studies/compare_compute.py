"""Match CMA-ES cumulative fitting replays to a saved known-start SMC² run.

Reuse observations and seeds rather than collecting new target trajectories.
CMA-ES refits each prefix with three independent starts by default. Earlier
fits count against every cumulative allowance. Complete-history evaluations
may leave fewer than one history's worth of replays unused at each update.
"""

import argparse
from contextlib import ExitStack
from dataclasses import replace
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import subprocess
import time

import numpy as np

from src.agents.simulator.internal_sim import InternalSim
from src.agents.system_identification.studies.benchmark_smc2 import (
    evaluate_predictions,
)
from src.agents.system_identification.studies.common import CountingSim, load_training
from src.agents.system_identification.sysid import SysID
from src.simulation.modelling.object import CuboidSpec


def write_report(
    rows: list[dict], output: Path, starts: int = 3, retain_best: bool = False
) -> None:
    lines = [
        "# CMA-ES versus SMC² with matched cumulative replay limits",
        "",
        "CMA-ES fits the saved datasets with the same seeds and scoring stride. "
        "Warmup is replayed but excluded from fitting. Each CMA-ES update refits "
        f"the full history with up to {starts} independent starts; the iteration limit is "
        "replaced by a replay cap. All earlier CMA-ES fits count toward the "
        "cumulative SMC² allowance. A final partial population is evaluated but "
        "not passed to the optimizer's tell step. Incomplete history evaluations "
        "are never performed.",
        "",
        "Position errors use selected point hypotheses on upright development "
        "evaluation pushes, averaged over inference seeds. They are not "
        "posterior predictive mixture errors. Parameter columns are mean "
        "absolute errors. Costs below sum all fitting updates across seeds; "
        "evaluation replays are excluded.",
        "",
        "| Sequence | Method | Position RMSE (mm) | Mass error (kg) | Friction error | COM error (mm) | Topple accuracy | Fitting replays |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    if retain_best:
        lines.insert(
            2,
            "The previous selected physics is rescored on the full current history and retained unless the new search has lower loss. Its replays are deducted before allocating the search budget. No previous loss or optimizer state is reused. This guarantees no worse current training loss than the incumbent, not better held-out predictions.",
        )
    methods = ["smc2", "cma_es_small"]
    if rows and "cma_es_refit" in rows[0]:
        methods.append("cma_es_refit")
    methods.append("cma_es_matched")
    summary = []
    for regime in sorted({row["regime"] for row in rows}):
        selected = [row for row in rows if row["regime"] == regime]
        last_step = max(row["step"] for row in selected)
        final = [row for row in selected if row["step"] == last_step]
        for method in methods:
            trials = [row[method] for row in final]
            error = np.mean([trial["absolute_error"] for trial in trials], axis=0)
            position = float(
                np.mean([trial["held_out"]["upright_rmse_x"] for trial in trials])
            )
            topple = float(
                np.mean([trial["held_out"]["topple_accuracy"] for trial in trials])
            )
            cost = sum(trial["cumulative_fit_replays"] for trial in trials)
            summary.append(
                {
                    "regime": regime,
                    "method": method,
                    "position_rmse_mm": position * 1000,
                    "absolute_error": error.tolist(),
                    "topple_accuracy": topple,
                    "fit_replays": cost,
                }
            )
            lines.append(
                f"| {regime} | {method} | {1000 * position:.3f} | {error[0]:.4f} | {error[1]:.4f} | {1000 * error[2]:.2f} | {topple:.3f} | {cost:,} |"
            )
    lines += [
        "",
        "## Per-seed final errors",
        "",
        "| Sequence | Seed | SMC² position RMSE (mm) | Matched CMA-ES position RMSE (mm) | SMC² / CMA-ES COM error (mm) |",
        "|---|---:|---:|---:|---|",
    ]
    for regime in sorted({row["regime"] for row in rows}):
        selected = [row for row in rows if row["regime"] == regime]
        last_step = max(row["step"] for row in selected)
        for row in selected:
            if row["step"] != last_step:
                continue
            smc, cma = row["smc2"], row["cma_es_matched"]
            lines.append(
                f"| {regime} | {row['seed']} | {1000 * smc['held_out']['upright_rmse_x']:.3f} | {1000 * cma['held_out']['upright_rmse_x']:.3f} | {1000 * smc['absolute_error'][2]:.2f} / {1000 * cma['absolute_error'][2]:.2f} |"
            )
    lines += [
        "",
        "## Limits",
        "",
        "This is one object and two deterministic datasets with three inference seeds. "
        "SMC² is the saved 256-particle gradual-update known-start run. "
        "The small CMA-ES baseline used ten iterations and no restarts per update. "
        "The matched comparison measures these implementations and this restart policy, "
        "not universal algorithm superiority. Replay counts match simulation calls, "
        "not physics timesteps or optimizer CPU work. Previous history fits are charged "
        "to CMA-ES; SMC² updates sequentially. Search initialization differs between "
        "methods as in the existing implementation. No posterior-calibration claims "
        "are made for CMA-ES's retained candidates.",
        "",
        "`metrics.jsonl` records each update's allowance, actual cumulative cost, "
        "selected parameters, and development prediction errors. `config.json` hashes "
        "all reused inputs and the inference/scoring implementation for provenance.",
    ]
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (output / "report.md").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline",
        type=Path,
        default=Path("artifacts/sysid_development_tempered_256"),
    )
    parser.add_argument(
        "--out", type=Path, default=Path("artifacts/sysid_compute_matched")
    )
    parser.add_argument("--restarts", type=int, default=2)
    parser.add_argument(
        "--retain-best",
        action="store_true",
        help="Rescore the previous best physics within each update's replay budget",
    )
    parser.add_argument(
        "--refit-comparison",
        type=Path,
        help="Saved matched-budget fresh-refit run to include in the results",
    )
    args = parser.parse_args()
    config = json.loads((args.baseline / "config.json").read_text())
    if args.restarts < 0:
        parser.error("restarts must be nonnegative")
    if not config["known_start"] or config.get("include_warmup", False):
        parser.error("Baseline must use known starts and exclude warmup")
    previous_refits = {}
    if args.refit_comparison:
        refit_config = json.loads((args.refit_comparison / "config.json").read_text())
        for key in ("object", "seeds", "regimes", "sample_stride"):
            if refit_config[key] != config[key]:
                parser.error(f"Refit comparison differs in {key}")
        if refit_config["restarts"] != args.restarts or refit_config.get(
            "retain_best", False
        ):
            parser.error(
                "Refit comparison must use the same restarts without retention"
            )
        # Confirm the old comparison consumed these exact saved inputs.
        hashes = refit_config["sha256"]
        for name in ("config.json", "metrics.jsonl", "held_out.json"):
            path = args.baseline / name
            if hashes.get(str(path)) != hashlib.sha256(path.read_bytes()).hexdigest():
                parser.error(f"Refit comparison has different baseline {name}")
        previous_refits = {
            (row["regime"], row["seed"], row["step"]): row
            for row in (
                json.loads(line)
                for line in (args.refit_comparison / "metrics.jsonl")
                .read_text()
                .splitlines()
            )
        }
    spec = CuboidSpec(**config["object"])
    saved = [
        json.loads(line)
        for line in (args.baseline / "metrics.jsonl").read_text().splitlines()
    ]
    indexed = {
        (row["regime"], row["seed"], row["step"], row["method"]): row for row in saved
    }
    training = {
        regime: load_training(
            args.baseline / f"dataset_{regime.replace(' ', '_')}.json"
        )
        for regime in config["regimes"]
    }
    # Load all evaluation records, including any rejected for fitting.
    from src.simulation.execution.force_push import DenseTrajectory
    from src.simulation.modelling.actions import PushAction
    from src.simulation.modelling.records import ActionRecord

    held_out = [
        ActionRecord(
            tuple(item["record"]["start"]),
            PushAction(**item["record"]["action"]),
            DenseTrajectory(**item["record"]["traj"]),
            item["record"]["warmup_steps"],
        )
        for item in json.loads((args.baseline / "held_out.json").read_text())
    ]
    inputs = [
        args.baseline / name
        for name in ("config.json", "metrics.jsonl", "held_out.json")
    ]
    inputs += [
        args.baseline / f"dataset_{regime.replace(' ', '_')}.json"
        for regime in config["regimes"]
    ]
    inputs += [
        Path("src/agents/system_identification") / name
        for name in (
            "sysid.py",
            "smc2.py",
            "scoring.py",
            "studies/compare_compute.py",
            "studies/common.py",
        )
    ]
    if args.refit_comparison:
        inputs += [
            args.refit_comparison / "config.json",
            args.refit_comparison / "metrics.jsonl",
        ]
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "config.json").write_text(
        json.dumps(
            {
                "baseline": str(args.baseline),
                "restarts": args.restarts,
                "retain_best": args.retain_best,
                "refit_comparison": str(args.refit_comparison)
                if args.refit_comparison
                else None,
                "iterations": "determined by per-update replay cap",
                "sample_stride": config["sample_stride"],
                "object": config["object"],
                "seeds": config["seeds"],
                "regimes": config["regimes"],
                "git_commit": subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], text=True
                ).strip(),
                "git_dirty": bool(
                    subprocess.check_output(["git", "status", "--porcelain"], text=True)
                ),
                "versions": {
                    name: version(name)
                    for name in ("numpy", "scipy", "pybullet", "cma")
                },
                "sha256": {
                    str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in inputs
                },
            },
            indent=2,
        )
        + "\n"
    )
    rows = []
    with (args.out / "metrics.jsonl").open("w") as stream:
        for regime in config["regimes"]:
            records = training[regime]
            for seed in config["seeds"]:
                with ExitStack() as stack:
                    fit = SysID(
                        (spec.w, spec.L, spec.H),
                        seed=seed,
                        restarts=args.restarts,
                        sample_stride=config["sample_stride"],
                    )
                    stack.callback(fit.close)
                    fit.sim.close()
                    fit.sim = CountingSim()
                    evaluation_sim = InternalSim()
                    stack.callback(evaluation_sim.close)
                    incumbent = None
                    for step in range(1, len(records) + 1):
                        smc = indexed[regime, seed, step, "smc2"]
                        budget = smc["cumulative_fit_replays"] - fit.sim.replay_count
                        before = fit.sim.replay_count
                        start = time.perf_counter()
                        result = fit.update(
                            records[:step], replay_budget=budget, incumbent=incumbent
                        )
                        elapsed = time.perf_counter() - start
                        theta = np.asarray(result.point.theta)
                        assert (
                            0
                            <= smc["cumulative_fit_replays"] - fit.sim.replay_count
                            < step
                        )
                        matched = {
                            "theta": theta.tolist(),
                            "loss": result.point.loss,
                            "absolute_error": np.abs(theta - spec.theta).tolist(),
                            "fit_replays": fit.sim.replay_count - before,
                            "cumulative_fit_replays": fit.sim.replay_count,
                            "fit_seconds": elapsed,
                            "incumbent": incumbent,
                            "incumbent_replays": step if incumbent is not None else 0,
                            "retained_previous_point": bool(
                                incumbent is not None
                                and np.allclose(
                                    theta, incumbent, rtol=1e-12, atol=1e-12
                                )
                            ),
                            "held_out": evaluate_predictions(
                                evaluation_sim,
                                replace(spec, m=theta[0], mu=theta[1], h_c=theta[2]),
                                held_out,
                            ),
                        }
                        row = {
                            "regime": regime,
                            "seed": seed,
                            "step": step,
                            "replay_allowance": budget,
                            "smc2": smc,
                            "cma_es_small": indexed[regime, seed, step, "cma_es"],
                            "cma_es_matched": matched,
                        }
                        if previous_refits:
                            previous = previous_refits[regime, seed, step]
                            assert (
                                previous["smc2"]["cumulative_fit_replays"]
                                == smc["cumulative_fit_replays"]
                            )
                            row["cma_es_refit"] = previous["cma_es_matched"]
                        if args.retain_best:
                            incumbent = result.point.theta
                        rows.append(row)
                        stream.write(json.dumps(row) + "\n")
                        stream.flush()
                        print(
                            f"{regime} seed={seed} step={step}: replays={fit.sim.replay_count}/{smc['cumulative_fit_replays']}, position={1000 * matched['held_out']['upright_rmse_x']:.3f} mm",
                            flush=True,
                        )
    write_report(rows, args.out, starts=args.restarts + 1, retain_best=args.retain_best)
    print(f"Saved comparison to {args.out}")


if __name__ == "__main__":
    main()

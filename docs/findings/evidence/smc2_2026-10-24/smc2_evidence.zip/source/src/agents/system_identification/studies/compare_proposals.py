"""Compare fixed and covariance-shaped SMC² proposals on saved development data.

Use identical random initial populations, known starts and gradual updates.
Capped arms share the saved fixed-kernel cumulative replay ceilings. An
uncapped covariance arm isolates the effect of truncating move stages. No
truth particle is injected and no evaluation data influence proposals.
"""

import argparse
from contextlib import ExitStack
from dataclasses import replace
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import subprocess

import numpy as np
from scipy.stats import wasserstein_distance

from src.agents.simulator.internal_sim import InternalSim
from src.agents.system_identification.smc2 import SMC2SysID
from src.agents.system_identification.studies.benchmark_smc2 import (
    evaluate_predictions,
    summarize_particles,
)
from src.agents.system_identification.studies.common import CountingSim, load_training
from src.agents.system_identification.studies.diagnostics.reference_posterior import (
    Grid,
    marginal_support,
)
from src.agents.system_identification.sysid import Z_HI, Z_LO
from src.simulation.execution.force_push import DenseTrajectory
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord


class MoveBudgetExhausted(RuntimeError):
    """No complete candidate likelihood fits the remaining replay allowance."""


class ReplayCappedSMC(SMC2SysID):
    """Study-only cap: finish evidence assimilation but stop unaffordable moves.

    Candidate likelihoods are never evaluated partially. Budget checks occur
    before their first replay. Caps affect rejuvenation, not the final beta.
    This study is restricted to deterministic one-state likelihoods.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.n_state != 1 or np.any(self.start_std != 0) or not self.temper_updates:
            raise ValueError("Replay cap study requires deterministic gradual updates")
        self.replay_limit: int | None = None
        self.blocked_stages = 0
        self.move_stages: list[dict] = []
        self._inside_move = False

    def _run_filter(self, z, history):
        if self._inside_move and self.replay_limit is not None:
            # A proposal replays all past records plus the current record.
            required = len(self._history) + 1
            if self.sim.replay_count + required > self.replay_limit:
                raise MoveBudgetExhausted
        return super()._run_filter(z, history)

    def _move_tempered_particles(self, record, beta, past, increments):
        before = self.sim.replay_count
        proposals, acceptances = self.proposals, self.acceptances
        blocked = False
        self._inside_move = True
        try:
            super()._move_tempered_particles(record, beta, past, increments)
        except MoveBudgetExhausted:
            self.blocked_stages += 1
            blocked = True
        finally:
            self._inside_move = False
        transform = self._proposal_transform
        self.move_stages.append(
            {
                "step": len(self._history) + 1,
                "beta": beta,
                "replays": self.sim.replay_count - before,
                "proposals": self.proposals - proposals,
                "acceptances": self.acceptances - acceptances,
                "budget_blocked": blocked,
                "transform_scaled": None
                if transform is None
                else (transform / (Z_HI - Z_LO)[:, None]).tolist(),
            }
        )


def plot_comparison(
    rows: list[dict], grid: Grid, spec: CuboidSpec, output: Path
) -> None:
    """Compare empirical COM CDFs without smoothing away particle duplicates."""
    import matplotlib.pyplot as plt

    selected = [row for row in rows if row["regime"] == "varied durations"]
    step = max(row["step"] for row in selected)
    seeds = list(dict.fromkeys(row["seed"] for row in selected))
    x = np.linspace(Z_LO[2], Z_HI[2], 500)
    weights, _ = grid.posterior(step)
    low, high = grid.low[:, 2], grid.high[:, 2]
    cdf = np.array(
        [weights @ np.clip((value - low) / (high - low), 0, 1) for value in x]
    )
    figure, axes = plt.subplots(
        1, len(seeds), figsize=(13, 4), squeeze=False, layout="constrained"
    )
    for axis, seed in zip(axes[0], seeds):
        axis.plot(
            x * spec.H * 1000, cdf, color="black", linewidth=2, label="Grid calculation"
        )
        for color, arm in enumerate(
            ("fixed_capped", "covariance_capped", "covariance_uncapped")
        ):
            saved = np.load(
                output / f"varied_durations_seed{seed}_{arm}_step{step}.npz"
            )
            com, mass = saved["z"][:, 2] * spec.H * 1000, saved["weights"]
            order = np.argsort(com)
            axis.step(
                np.r_[x[0] * spec.H * 1000, com[order], x[-1] * spec.H * 1000],
                np.r_[0, np.cumsum(mass[order]), 1],
                where="post",
                color=f"C{color}",
                label=arm.replace("_", " "),
            )
        axis.axvline(spec.h_c * 1000, color="crimson", linestyle="--", label="True COM")
        axis.set(
            title=f"Seed {seed}",
            xlabel="COM height (mm)",
            ylabel="Cumulative probability",
            ylim=(0, 1),
        )
    axes[0, 0].legend(fontsize=8)
    figure.suptitle("Final COM distribution after varied-duration pushes")
    figure.savefig(output / "com_distribution_comparison.png", dpi=150)
    plt.close(figure)


def write_report(rows: list[dict], output: Path) -> None:
    lines = [
        "# Covariance-shaped proposal experiment",
        "",
        "Same saved data, three seeds, 256 random physics particles, exact starts, gradual updates, at most two proposal attempts per particle per stage, and proposal scale 0.08. No true-physics particle is injected. The new option uses weighted particle covariance in prior-scaled z coordinates, measured before resampling and frozen during each move stage. Its trace is normalized so both kernels have the same expected squared jump length. A small diagonal floor preserves mobility; a collapsed cloud falls back to the fixed shape. There is no acceptance-based scale adaptation.",
        "",
        "Capped arms use the saved fixed-kernel cumulative replay ceilings at every prefix. New-push likelihoods are always fully assimilated (beta reaches one); only proposal moves can be stopped. The check reserves a complete candidate history before its first replay, and never redraws an out-of-bounds proposal. Actual costs can fall below the ceilings. The uncapped covariance arm uses the original two-moves-per-stage schedule to expose effects of the cap. Replay-based stopping is a practical adaptive compute policy, not a proof of exact finite-population sampling.",
        "",
        "Point prediction errors are for upright development evaluation pushes. COM truth inclusion is conditional on this object/dataset, not population calibration. COM grid distances compare full distributions and exist only for varied durations; lower is closer.",
        "",
        "| Sequence | Arm | Position RMSE (mm) | COM intervals include truth | Distinct final particles, seeds 1/2/3 | Move acceptance | Fitting replays | Mean COM distance to grid (mm) |",
        "|---|---|---:|---:|---|---:|---:|---:|",
    ]
    summary = []
    for regime in dict.fromkeys(row["regime"] for row in rows):
        selected = [row for row in rows if row["regime"] == regime]
        last = max(row["step"] for row in selected)
        for arm in dict.fromkeys(row["arm"] for row in selected):
            final = [
                row for row in selected if row["arm"] == arm and row["step"] == last
            ]
            proposals = sum(row["proposals"] for row in final)
            item = {
                "regime": regime,
                "arm": arm,
                "position_rmse_mm": 1000
                * float(np.mean([row["held_out"]["upright_rmse_x"] for row in final])),
                "com_truth_count": sum(
                    row["posterior"]["h_c"]["covers_truth"] for row in final
                ),
                "unique_particles": [row["unique_particles"] for row in final],
                "acceptance_fraction": sum(row["acceptances"] for row in final)
                / proposals
                if proposals
                else None,
                "fit_replays": sum(row["cumulative_fit_replays"] for row in final),
                "blocked_stages": sum(row["blocked_stages"] for row in final),
                "com_distance_to_grid_mm": float(
                    np.mean([row["com_distance_to_grid_mm"] for row in final])
                )
                if "com_distance_to_grid_mm" in final[0]
                else None,
            }
            summary.append(item)
            distance = item["com_distance_to_grid_mm"]
            lines.append(
                f"| {regime} | {arm} | {item['position_rmse_mm']:.3f} | {item['com_truth_count']}/{len(final)} | {item['unique_particles']} | {item['acceptance_fraction']:.1%} | {item['fit_replays']:,} | {'—' if distance is None else f'{distance:.2f}'} |"
            )
    lines += [
        "",
        "## Final COM intervals",
        "",
        "| Sequence | Arm | Seed | 95% COM interval (mm) | Truth included | Budget-blocked stages |",
        "|---|---|---:|---|---|---:|",
    ]
    for row in rows:
        if row["step"] != max(r["step"] for r in rows if r["regime"] == row["regime"]):
            continue
        com = row["posterior"]["h_c"]
        lines.append(
            f"| {row['regime']} | {row['arm']} | {row['seed']} | [{1000 * com['low_95']:.1f}, {1000 * com['high_95']:.1f}] | {com['covers_truth']} | {row['blocked_stages']} |"
        )
    lines += [
        "",
        "## Scope and sources",
        "",
        "One noise-free object and two development sequences; no final-test generalization claim. Covariance adaptation is a standard SMC technique ([Zhou, Johansen & Aston, section 3.3.3](https://arxiv.org/html/1303.3123v2#S3.SS3.SSS3)), but the fixed-trace normalization here is a deliberate experimental choice to isolate shape. This is not a claim to reproduce the paper's complete proposal-adaptation scheme. Narrow or curved regions may still be represented badly by one global covariance. High acceptance alone is not evidence of adequate exploration.",
        "",
        "Per-update costs, proposal counts, posterior intervals and marginal grid distances are in metrics.jsonl. Stage matrices and cap events are in separate move-trace JSON files; NPZ files retain particles and weights. Inputs, source and dependency versions are recorded in config.json. Output directories must be new.",
    ]
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (output / "report.md").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline",
        type=Path,
        default=Path("artifacts/sysid_development_tempered_256"),
    )
    parser.add_argument(
        "--out", type=Path, default=Path("artifacts/sysid_covariance_proposals")
    )
    args = parser.parse_args()
    config = json.loads((args.baseline / "config.json").read_text())
    if (
        not config["known_start"]
        or not config["temper_updates"]
        or config.get("include_warmup", False)
    ):
        parser.error("Baseline must use deterministic gradual updates excluding warmup")
    spec = CuboidSpec(**config["object"])
    geometry = (spec.w, spec.L, spec.H)
    data = {
        regime: load_training(
            args.baseline / f"dataset_{regime.replace(' ', '_')}.json"
        )
        for regime in config["regimes"]
    }
    saved = [
        json.loads(line)
        for line in (args.baseline / "metrics.jsonl").read_text().splitlines()
    ]
    reference = {
        (row["regime"], row["seed"], row["step"]): row
        for row in saved
        if row["method"] == "smc2"
    }
    evaluation = [
        ActionRecord(
            tuple(item["record"]["start"]),
            PushAction(**item["record"]["action"]),
            DenseTrajectory(**item["record"]["traj"]),
            item["record"]["warmup_steps"],
        )
        for item in json.loads((args.baseline / "held_out.json").read_text())
    ]
    args.out.mkdir(parents=True, exist_ok=False)
    paths = [
        args.baseline / name
        for name in ("config.json", "metrics.jsonl", "held_out.json")
    ]
    paths += [
        args.baseline / f"dataset_{regime.replace(' ', '_')}.json" for regime in data
    ]
    paths += [
        Path(__file__),
        Path("src/agents/system_identification/smc2.py"),
        Path("src/agents/system_identification/sysid.py"),
        Path("src/agents/system_identification/scoring.py"),
    ]
    provenance = {
        "baseline": str(args.baseline),
        "object": config["object"],
        "n_theta": config["n_theta"],
        "n_state": 1,
        "start_std": [0] * 4,
        "seeds": config["seeds"],
        "sample_stride": config["sample_stride"],
        "arms": ["fixed_capped", "covariance_capped", "covariance_uncapped"],
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True
        ).strip(),
        "versions": {name: version(name) for name in ("numpy", "scipy", "pybullet")},
        "sha256": {
            str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths
        },
    }
    grid_path = Path("artifacts/sysid_reference_posterior/grid24_level5.npz")
    grid = None
    if grid_path.exists():
        cells = np.load(grid_path)
        grid = Grid(cells["low"], cells["high"], cells["log_likelihood"])
        with SMC2SysID(
            geometry,
            n_theta=1,
            n_state=1,
            start_std=(0, 0, 0, 0),
            sample_stride=config["sample_stride"],
        ) as probe:
            indices = np.linspace(0, len(grid.low) - 1, 32, dtype=int)
            computed = np.array(
                [
                    [
                        probe._evaluate_record(grid.points[i], rec)[1]
                        for rec in data["varied durations"]
                    ]
                    for i in indices
                ]
            )
            difference = float(np.max(abs(computed - grid.log_likelihood[indices])))
            if difference > 1e-8:
                raise ValueError("Cached grid likelihoods differ")
            provenance["grid_max_likelihood_difference"] = difference
            provenance["grid_sha256"] = hashlib.sha256(
                grid_path.read_bytes()
            ).hexdigest()
    (args.out / "config.json").write_text(json.dumps(provenance, indent=2) + "\n")
    rows = []
    with (args.out / "metrics.jsonl").open("w") as stream:
        for regime, records in data.items():
            for seed in config["seeds"]:
                for arm in provenance["arms"]:
                    with ExitStack() as stack:
                        sim = CountingSim()
                        stack.callback(sim.close)
                        evaluation_sim = InternalSim()
                        stack.callback(evaluation_sim.close)
                        fit = ReplayCappedSMC(
                            geometry,
                            n_theta=config["n_theta"],
                            n_state=1,
                            start_std=(0, 0, 0, 0),
                            seed=seed,
                            sample_stride=config["sample_stride"],
                            temper_updates=True,
                            proposal="fixed" if arm == "fixed_capped" else "covariance",
                            sim=sim,
                        )
                        stem = f"{regime.replace(' ', '_')}_seed{seed}_{arm}"
                        for step in range(1, len(records) + 1):
                            baseline = reference[regime, seed, step]
                            cap = baseline["cumulative_fit_replays"]
                            fit.replay_limit = (
                                None if arm == "covariance_uncapped" else cap
                            )
                            before = sim.replay_count
                            result = fit.update(records[:step])
                            if fit.replay_limit is not None:
                                assert sim.replay_count <= cap
                            theta = np.asarray(result.point.theta)
                            row = {
                                "regime": regime,
                                "seed": seed,
                                "arm": arm,
                                "step": step,
                                "theta": theta.tolist(),
                                "replay_ceiling": fit.replay_limit,
                                "fit_replays": sim.replay_count - before,
                                "cumulative_fit_replays": sim.replay_count,
                                "posterior": summarize_particles(fit, spec),
                                "unique_particles": len(
                                    np.unique(fit.particles, axis=0)
                                ),
                                "proposals": fit.proposals,
                                "acceptances": fit.acceptances,
                                "blocked_stages": fit.blocked_stages,
                                "held_out": evaluate_predictions(
                                    evaluation_sim,
                                    replace(
                                        spec, m=theta[0], mu=theta[1], h_c=theta[2]
                                    ),
                                    evaluation,
                                ),
                            }
                            if grid is not None and regime == "varied durations":
                                row["marginal_distances_to_grid"] = []
                                for col in range(len(Z_LO)):
                                    values, weights = marginal_support(
                                        grid, step, col, spec.H
                                    )
                                    particles = fit.particles[:, col]
                                    if col == 0:
                                        particles = np.exp(particles)
                                    if col == 2:
                                        particles = particles * spec.H
                                    row["marginal_distances_to_grid"].append(
                                        float(
                                            wasserstein_distance(
                                                values, particles, weights, fit.weights
                                            )
                                        )
                                    )
                                row["com_distance_to_grid_mm"] = (
                                    1000 * row["marginal_distances_to_grid"][2]
                                )
                            if arm == "fixed_capped":
                                original = np.load(
                                    args.baseline
                                    / f"{regime.replace(' ', '_')}_seed{seed}_step{step}.npz"
                                )
                                np.testing.assert_array_equal(
                                    original["z"], fit.particles
                                )
                                np.testing.assert_array_equal(
                                    original["weights"], fit.weights
                                )
                                assert sim.replay_count == cap
                            np.savez_compressed(
                                args.out / f"{stem}_step{step}.npz",
                                z=fit.particles,
                                weights=fit.weights,
                            )
                            rows.append(row)
                            stream.write(json.dumps(row) + "\n")
                            stream.flush()
                            print(
                                f"{stem} step={step}: replays={sim.replay_count}/{cap}, unique={row['unique_particles']}, blocked={fit.blocked_stages}",
                                flush=True,
                            )
                        (args.out / f"{stem}_moves.json").write_text(
                            json.dumps(fit.move_stages, indent=2) + "\n"
                        )
    write_report(rows, args.out)
    if grid is not None:
        plot_comparison(rows, grid, spec, args.out)
    print(f"Saved comparison to {args.out}")


if __name__ == "__main__":
    main()

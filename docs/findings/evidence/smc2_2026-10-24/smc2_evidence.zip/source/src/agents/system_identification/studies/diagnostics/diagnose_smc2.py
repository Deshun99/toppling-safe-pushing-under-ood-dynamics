"""
Diagnose particle depletion using an existing benchmark training dataset.

No held-out data are used to select settings. Zero start uncertainty is an
ablation appropriate to noise-free simulated state measurements, not a fix
for real sensors. All variants retain the same observation likelihood scales.
Estimator probes and ablations exclude warm-up; they do not reproduce the
historical include-warm-up runs. The COM profile compares both windows locally.
"""

import argparse
from contextlib import ExitStack
from dataclasses import replace
import json
from pathlib import Path
import time

import numpy as np
from scipy.special import logsumexp

from src.agents.system_identification.smc2 import CHANNELS, SMC2SysID
from src.agents.system_identification.studies.benchmark_smc2 import summarize_particles
from src.agents.system_identification.studies.common import CountingSim, load_training
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord


def probe_likelihood(
    spec: CuboidSpec,
    record: ActionRecord,
    sim: CountingSim,
    repeats: int,
) -> list[dict]:
    """Measure stochastic likelihood variation at fixed, true physics.

    Variance here comes from numerical integration over sampled starts, not
    changing the target data or physics. Log of an unbiased likelihood
    estimate is not itself an unbiased log likelihood estimate.
    """
    configurations = [
        ("default_8", {"n_state": 8}),
        ("default_64", {"n_state": 64}),
        ("smaller_start_8", {"n_state": 8, "start_std": (0.001, 0.0002, 0.001, 0.002)}),
        ("exact_start", {"n_state": 1, "start_std": (0, 0, 0, 0)}),
    ]
    z = np.array([np.log(spec.m), spec.mu, spec.h_c / spec.H])
    results = []
    for name, settings in configurations:
        fit = SMC2SysID(
            (spec.w, spec.L, spec.H),
            n_theta=1,
            proposal="fixed",
            sim=sim,
            **settings,
        )
        estimates, inner_ess = [], []
        for seed in range(1, repeats + 1):
            fit.rng = np.random.default_rng(seed)
            inner, increment = fit._evaluate_record(z, record)
            estimates.append(increment)
            inner_ess.append(float(1 / np.sum(inner.weights**2)))
        row = {
            "variant": name,
            "settings": settings,
            "log_likelihood_estimates": estimates,
            "log_likelihood_std": float(np.std(estimates, ddof=1)),
            "mean_inner_ess": float(np.mean(inner_ess)),
        }
        results.append(row)
        print(
            f"Likelihood {name}: std(log L)={row['log_likelihood_std']:.2f}, "
            f"mean inner ESS={row['mean_inner_ess']:.2f}",
            flush=True,
        )
    return results


def measure_initial_collapse(
    fit: SMC2SysID,
    record: ActionRecord,
    true_z: np.ndarray,
) -> dict:
    """Measure first-update ESS before resampling without changing run RNG."""
    from copy import deepcopy

    state = deepcopy(fit.rng.bit_generator.state)
    initial = fit.particles
    increments = [fit._evaluate_record(z, record)[1] for z in initial]
    fit.rng.bit_generator.state = state
    weights = np.exp(increments - logsumexp(increments))
    return {
        "first_update_ess": float(1 / np.sum(weights**2)),
        "max_initial_weight": float(np.max(weights)),
        "first_log_likelihood_range": float(np.ptp(increments)),
        "nearest_prior_scaled_distance": float(
            np.min(
                np.linalg.norm(
                    (initial - true_z) / np.array([np.log(3 / 0.2), 1, 0.6]),
                    axis=1,
                )
            )
        ),
    }


def profile_com_likelihood(
    spec: CuboidSpec,
    records: list[ActionRecord],
    sim: CountingSim,
) -> list[dict]:
    """Isolate warm-up contributions while fixing mass/friction at truth.

    The historical full-window likelihood is calculated locally; estimator
    fitting always excludes warm-up. A COM profile is conditional on fixed m/mu, not a marginal posterior.
    """
    fit = SMC2SysID((spec.w, spec.L, spec.H), n_theta=1, sim=sim, proposal="fixed")
    rows = []
    for height in np.linspace(0.2 * spec.H, 0.8 * spec.H, 25):
        full, pushing = 0.0, 0.0
        errors = {channel: {"warmup": 0.0, "pushing": 0.0} for channel in CHANNELS}
        for record in records:
            predicted = sim.replay(replace(spec, h_c=height), record)
            observed = fit._trajectory_array(record.traj)[:: fit.sample_stride]
            data = fit._trajectory_array(predicted)[:: fit.sample_stride]
            indices = np.arange(len(record.traj.t))[:: fit.sample_stride]
            mask = indices >= record.warmup_steps
            full += fit._compute_log_likelihood(observed, data)
            pushing += fit._compute_log_likelihood(observed[mask], data[mask])
            squared = ((observed - data) / fit.observation_std) ** 2
            for index, channel in enumerate(CHANNELS):
                errors[channel]["warmup"] += float(np.sum(squared[~mask, index]))
                errors[channel]["pushing"] += float(np.sum(squared[mask, index]))
        rows.append(
            {
                "h_c": float(height),
                "full_log_likelihood": full,
                "pushing_log_likelihood": pushing,
                "standardized_squared_errors": errors,
            }
        )
    return rows


def run_ablation(
    name: str,
    settings: dict,
    seed: int,
    spec: CuboidSpec,
    records: list[ActionRecord],
    sim: CountingSim,
) -> list[dict]:
    fit = SMC2SysID(
        (spec.w, spec.L, spec.H), seed=seed, sim=sim, proposal="fixed", **settings
    )
    true_z = np.array([np.log(spec.m), spec.mu, spec.h_c / spec.H])
    initial = measure_initial_collapse(fit, records[0], true_z)
    rows = []
    for step in range(1, len(records) + 1):
        before = sim.replay_count
        start = time.perf_counter()
        result = fit.update(records[:step])
        elapsed = time.perf_counter() - start
        posterior = summarize_particles(fit, spec)
        row = {
            "variant": name,
            "settings": settings,
            "seed": seed,
            "step": step,
            "initial": initial,
            "theta": list(result.point.theta),
            "absolute_error": np.abs(
                np.asarray(result.point.theta) - spec.theta
            ).tolist(),
            "posterior": posterior,
            "pre_resample_ess": fit.last_ess,
            "unique_particles": len(np.unique(fit.particles, axis=0)),
            "acceptance_rate": fit.acceptances / fit.proposals
            if fit.proposals
            else None,
            "fit_replays": sim.replay_count - before,
            "fit_seconds": elapsed,
        }
        rows.append(row)
        acceptance = row["acceptance_rate"]
        acceptance_text = "n/a" if acceptance is None else f"{acceptance:.3f}"
        print(
            f"{name} seed={seed} step={step}: ESS={fit.last_ess:.1f}, "
            f"unique={row['unique_particles']}, accept={acceptance_text}, "
            f"theta={np.asarray(result.point.theta).round(4)}",
            flush=True,
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path(
            "artifacts/sysid_benchmark_initial/dataset_varied_magnitudes.json"
        ),
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("artifacts/sysid_benchmark_initial/config.json"),
    )
    parser.add_argument("--out", type=Path, default=Path("artifacts/smc2_diagnosis"))
    parser.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3])
    parser.add_argument("--repeats", type=int, default=32)
    args = parser.parse_args()
    if args.repeats < 2:
        parser.error("--repeats must be at least 2")
    spec = CuboidSpec(**json.loads(args.config.read_text())["object"])
    records = load_training(args.dataset)
    if not records:
        parser.error("Dataset has no accepted records")
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "config.json").write_text(
        json.dumps(
            {
                "dataset": str(args.dataset),
                "object": json.loads(args.config.read_text())["object"],
                "seeds": args.seeds,
                "repeats": args.repeats,
                "note": __doc__,
            },
            indent=2,
        )
    )
    with ExitStack() as stack:
        sim = CountingSim()
        stack.callback(sim.close)
        probes = probe_likelihood(spec, records[0], sim, args.repeats)
        (args.out / "likelihood_probe.json").write_text(json.dumps(probes, indent=2))
        profiles = profile_com_likelihood(spec, records, sim)
        (args.out / "com_profiles.json").write_text(json.dumps(profiles, indent=2))
        # Inspect per-channel true-physics residuals on training data only.
        residuals = {channel: [] for channel in CHANNELS}
        for record in records:
            prediction = sim.replay(spec, record)
            for channel in CHANNELS:
                residuals[channel].extend(
                    np.asarray(getattr(record.traj, channel))
                    - np.asarray(getattr(prediction, channel))
                )
        (args.out / "oracle_residuals.json").write_text(
            json.dumps(
                {
                    channel: {
                        "rmse": float(np.sqrt(np.mean(np.asarray(values) ** 2))),
                        "mean": float(np.mean(values)),
                    }
                    for channel, values in residuals.items()
                },
                indent=2,
            )
        )
        variants = {
            "baseline": {"n_theta": 64, "n_state": 8},
            "more_inner": {"n_theta": 64, "n_state": 64},
            "exact_start": {"n_theta": 64, "n_state": 1, "start_std": (0, 0, 0, 0)},
            "exact_start_more_outer": {
                "n_theta": 256,
                "n_state": 1,
                "start_std": (0, 0, 0, 0),
            },
            "exact_start_more_moves": {
                "n_theta": 64,
                "n_state": 1,
                "start_std": (0, 0, 0, 0),
                "mcmc_steps": 20,
            },
        }
        with (args.out / "ablations.jsonl").open("w") as stream:
            for name, settings in variants.items():
                for seed in args.seeds:
                    for row in run_ablation(name, settings, seed, spec, records, sim):
                        stream.write(json.dumps(row) + "\n")
                    stream.flush()
    print(f"Saved diagnosis to {args.out}")


if __name__ == "__main__":
    main()

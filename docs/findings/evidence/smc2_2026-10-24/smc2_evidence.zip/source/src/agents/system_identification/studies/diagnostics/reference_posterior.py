"""Volume-weighted grid reference for the known-start replay posterior.

Uniform initial grids cover the full z prior. Adaptive midpoint quadrature
subdivides cells carrying most mass at ANY history prefix, retaining all other
cells. Compare independently initialized grids before treating this as a
reference. Refinement stability is empirical, not a bound on quadrature error.
"""

import argparse
from dataclasses import dataclass
from importlib.metadata import version
import json
import hashlib
from pathlib import Path
import time

import numpy as np
from numpy.typing import NDArray
from scipy.special import logsumexp
from scipy.stats import wasserstein_distance

from src.agents.system_identification.smc2 import SMC2SysID
from src.agents.system_identification.sysid import Z_LO, Z_HI, convert_z_to_cuboid_spec
from src.agents.system_identification.studies.benchmark_smc2 import PARAMETERS
from src.agents.system_identification.studies.common import (
    CountingSim,
    compute_weighted_quantiles,
    load_training,
)
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord

RETAINED_MASS = 0.999
CONVERGENCE_DISTANCE = 0.005  # Wasserstein distance / full parameter prior range.
CONVERGENCE_LOG_EVIDENCE = 0.2
PREDICTIVE_BATCHES = 4
PREDICTIVE_BATCH_SIZE = 256


@dataclass
class Grid:
    """Cells cover the entire prior; likelihood columns are action increments."""

    low: NDArray[np.float64]
    high: NDArray[np.float64]
    log_likelihood: NDArray[np.float64]

    @property
    def points(self) -> NDArray[np.float64]:
        return (self.low + self.high) / 2

    def posterior(self, step: int) -> tuple[NDArray[np.float64], float]:
        log_prior_mass = np.sum(np.log(self.high - self.low), axis=1) - np.sum(
            np.log(Z_HI - Z_LO)
        )
        log_mass = log_prior_mass + self.log_likelihood[:, :step].sum(axis=1)
        evidence = float(logsumexp(log_mass))
        return np.exp(log_mass - evidence), evidence


def create_uniform_cells(size: int) -> tuple[np.ndarray, np.ndarray]:
    axes = [np.arange(size) for _ in range(len(Z_LO))]
    indices = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(
        -1, len(Z_LO)
    )
    widths = (Z_HI - Z_LO) / size
    low = Z_LO + indices * widths
    return low, low + widths


def split_cells(low: np.ndarray, high: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    offsets = np.stack(
        np.meshgrid(*[[0, 1]] * len(Z_LO), indexing="ij"), axis=-1
    ).reshape(-1, len(Z_LO))
    half = (high - low) / 2
    children = low[:, None, :] + offsets[None, :, :] * half[:, None, :]
    return children.reshape(-1, len(Z_LO)), (children + half[:, None, :]).reshape(
        -1, len(Z_LO)
    )


def select_mass(weights: np.ndarray, fraction: float = RETAINED_MASS) -> np.ndarray:
    order = np.argsort(-weights)
    count = min(
        len(order), int(np.searchsorted(np.cumsum(weights[order]), fraction)) + 1
    )
    return order[:count]


def convert_points(points: np.ndarray, height: float) -> np.ndarray:
    theta = points.copy()
    theta[:, 0] = np.exp(theta[:, 0])
    theta[:, 2] *= height
    return theta


def summarize_distribution(
    points: np.ndarray, weights: np.ndarray, spec: CuboidSpec
) -> dict:
    theta = convert_points(points, spec.H)
    mean = weights @ theta
    centered = theta - mean
    covariance = (centered * weights[:, None]).T @ centered
    std = np.sqrt(np.diag(covariance))
    denominator = np.outer(std, std)
    correlation = np.divide(
        covariance, denominator, out=np.zeros_like(covariance), where=denominator > 0
    )
    return {
        "mean": mean.tolist(),
        "std": std.tolist(),
        "correlation": correlation.tolist(),
        "intervals_95": {
            name: compute_weighted_quantiles(
                theta[:, col], weights, (0.025, 0.975)
            ).tolist()
            for col, name in enumerate(PARAMETERS)
        },
        "covers_truth": {
            name: bool(low <= truth <= high)
            for (name, truth), (low, high) in zip(
                zip(PARAMETERS, spec.theta),
                [
                    compute_weighted_quantiles(theta[:, col], weights, (0.025, 0.975))
                    for col in range(len(PARAMETERS))
                ],
            )
        },
    }


def marginal_support(
    grid: Grid, step: int, col: int, height: float
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate cell marginals with eight Gauss-Legendre nodes per interval.

    The midpoint likelihood is constant within each cell. Distributing its mass
    uniformly in z avoids treating broad, well-integrated cells as point masses.
    """
    nodes, quadrature_weights = np.polynomial.legendre.leggauss(8)
    weights, _ = grid.posterior(step)
    low, high = grid.low[:, col, None], grid.high[:, col, None]
    values = (low + high) / 2 + (high - low) / 2 * nodes
    if col == 0:
        values = np.exp(values)
    elif col == 2:
        values *= height
    return values.ravel(), (weights[:, None] * quadrature_weights[None, :] / 2).ravel()


def compute_grid_quantiles(
    grid: Grid, step: int, col: int, height: float
) -> list[float]:
    """Invert the piecewise-uniform marginal CDF, without node quantization."""
    weights, _ = grid.posterior(step)
    low, high = grid.low[:, col], grid.high[:, col]
    result = []
    for probability in (0.025, 0.975):
        left, right = Z_LO[col], Z_HI[col]
        for _ in range(48):
            middle = (left + right) / 2
            cdf = np.sum(weights * np.clip((middle - low) / (high - low), 0, 1))
            if cdf < probability:
                left = middle
            else:
                right = middle
        value = float((left + right) / 2)
        if col == 0:
            value = float(np.exp(value))
        elif col == 2:
            value *= height
        result.append(value)
    return result


def summarize_grid(grid: Grid, step: int, spec: CuboidSpec) -> dict:
    weights, _ = grid.posterior(step)
    result = summarize_distribution(grid.points, weights, spec)
    means, variances, intervals = [], [], {}
    for col, name in enumerate(PARAMETERS):
        values, mass = marginal_support(grid, step, col, spec.H)
        mean = float(mass @ values)
        means.append(mean)
        variances.append(float(mass @ (values - mean) ** 2))
        intervals[name] = compute_grid_quantiles(grid, step, col, spec.H)
    result.update(
        mean=means,
        std=np.sqrt(variances).tolist(),
        intervals_95=intervals,
        covers_truth={
            name: bool(intervals[name][0] <= truth <= intervals[name][1])
            for name, truth in zip(PARAMETERS, spec.theta)
        },
    )
    conditional_means = grid.points.copy()
    width = grid.high[:, 0] - grid.low[:, 0]
    conditional_means[:, 0] = (np.exp(grid.high[:, 0]) - np.exp(grid.low[:, 0])) / width
    conditional_means[:, 2] *= spec.H
    centered = conditional_means - means
    covariance = (centered * weights[:, None]).T @ centered
    np.fill_diagonal(covariance, variances)
    denominator = np.sqrt(np.outer(variances, variances))
    result["correlation"] = np.divide(
        covariance, denominator, out=np.zeros_like(covariance), where=denominator > 0
    ).tolist()
    return result


def compare_grids(previous: Grid, current: Grid, step: int, spec: CuboidSpec) -> dict:
    _, old_evidence = previous.posterior(step)
    _, evidence = current.posterior(step)
    ranges = np.array(
        [
            np.exp(Z_HI[0]) - np.exp(Z_LO[0]),
            Z_HI[1] - Z_LO[1],
            (Z_HI[2] - Z_LO[2]) * spec.H,
        ]
    )
    distances = []
    for col in range(len(PARAMETERS)):
        old_values, old_mass = marginal_support(previous, step, col, spec.H)
        values, mass = marginal_support(current, step, col, spec.H)
        distances.append(
            float(
                wasserstein_distance(old_values, values, old_mass, mass) / ranges[col]
            )
        )
    delta = abs(evidence - old_evidence)
    return {
        "normalized_marginal_wasserstein": distances,
        "log_evidence_change": delta,
        "stable": bool(
            max(distances) < CONVERGENCE_DISTANCE and delta < CONVERGENCE_LOG_EVIDENCE
        ),
    }


def evaluate_cells(
    low: np.ndarray, high: np.ndarray, fit: SMC2SysID, records: list[ActionRecord]
) -> Grid:
    likelihood = np.empty((len(low), len(records)))
    for index, point in enumerate((low + high) / 2):
        for col, record in enumerate(records):
            likelihood[index, col] = fit._evaluate_record(point, record)[1]
        if (index + 1) % 2000 == 0:
            print(f"  evaluated {index + 1}/{len(low)} cells", flush=True)
    return Grid(low, high, likelihood)


def refine_grid(
    grid: Grid, fit: SMC2SysID, records: list[ActionRecord], max_new_cells: int = 20000
) -> Grid:
    selected = np.unique(
        np.concatenate(
            [
                select_mass(grid.posterior(step)[0])
                for step in range(1, len(records) + 1)
            ]
        )
    )
    if len(selected) * 8 > max_new_cells:
        priority = np.max(
            np.stack([grid.posterior(step)[0] for step in range(1, len(records) + 1)]),
            axis=0,
        )
        selected = selected[np.argsort(-priority[selected])[: max_new_cells // 8]]
    keep = np.ones(len(grid.low), dtype=bool)
    keep[selected] = False
    low, high = split_cells(grid.low[selected], grid.high[selected])
    children = evaluate_cells(low, high, fit, records)
    return Grid(
        np.concatenate((grid.low[keep], children.low)),
        np.concatenate((grid.high[keep], children.high)),
        np.concatenate((grid.log_likelihood[keep], children.log_likelihood)),
    )


def evaluate_predictive_distribution(
    points: np.ndarray,
    weights: np.ndarray,
    fit: SMC2SysID,
    records: list[ActionRecord],
    spec: CuboidSpec,
    grid: Grid | None = None,
) -> dict:
    """Approximate the predictive mixture using >=99.9% of posterior mass.

    Scores condition on each measured start and use the same force-only
    likelihood. Truncated mixtures are renormalized; retained mass is reported.
    For a grid, use four independent batches of 256 posterior draws, sampling
    uniformly inside selected cells. Report Monte Carlo errors separately.
    This is development evaluation, not evidence used in grid refinement.
    """
    from src.agents.system_identification.scoring import get_scoring_indices

    if grid is not None:
        rng = np.random.default_rng(729)
        count = PREDICTIVE_BATCHES * PREDICTIVE_BATCH_SIZE
        cells = rng.choice(len(weights), size=count, p=weights / weights.sum())
        points = rng.uniform(grid.low[cells], grid.high[cells])
        selected = np.arange(count)
        retained = 1.0
        mixture_weights = np.full(count, 1 / count)
    else:
        selected = select_mass(weights)
        retained = float(weights[selected].sum())
        mixture_weights = weights[selected] / retained
    rmse, scores, toppling_probabilities = [], [], []
    errors = []
    for record in records:
        indices = get_scoring_indices(
            len(record.traj.t),
            warmup_steps=record.warmup_steps,
            sample_stride=fit.sample_stride,
        )
        observed = fit._trajectory_array(record.traj)[indices]
        predictions, likelihoods, topples = [], [], []
        for point in points[selected]:
            candidate = convert_z_to_cuboid_spec(point, (spec.w, spec.L, spec.H))
            trajectory = fit.sim.replay(candidate, record)
            predicted = fit._trajectory_array(trajectory)[indices]
            predictions.append(predicted)
            likelihoods.append(fit._compute_log_likelihood(observed, predicted))
            topples.append(max(abs(v) for v in trajectory.psi) > candidate.crit_tilt)
        mean = np.tensordot(mixture_weights, np.asarray(predictions), axes=1)
        rmse.append(np.sqrt(np.mean((mean - observed) ** 2, axis=0)).tolist())
        scores.append(float(logsumexp(np.log(mixture_weights) + likelihoods)))
        toppling_probabilities.append(float(mixture_weights @ np.asarray(topples)))
        if grid is not None:
            batches = (
                np.asarray(predictions)
                .reshape(PREDICTIVE_BATCHES, PREDICTIVE_BATCH_SIZE, *observed.shape)
                .mean(axis=1)
            )
            mean_se = np.std(batches, axis=0, ddof=1) / np.sqrt(PREDICTIVE_BATCHES)
            likelihood_batches = np.asarray(likelihoods).reshape(
                PREDICTIVE_BATCHES, PREDICTIVE_BATCH_SIZE
            )
            log_density_batches = logsumexp(likelihood_batches, axis=1) - np.log(
                PREDICTIVE_BATCH_SIZE
            )
            errors.append(
                {
                    "rms_predictive_mean_standard_error": np.sqrt(
                        np.mean(mean_se**2, axis=0)
                    ).tolist(),
                    "log_predictive_density_batch_std": float(
                        np.std(log_density_batches, ddof=1)
                    ),
                }
            )
    return {
        "retained_mass": retained,
        "replayed_hypotheses": len(selected),
        "rmse_by_record_and_channel": rmse,
        "log_predictive_density_by_record": scores,
        "toppling_probability_by_record": toppling_probabilities,
        "integration": "posterior_monte_carlo"
        if grid is not None
        else "weighted_particle_mixture",
        "monte_carlo_errors_by_record": errors,
    }


def get_cache_identity(args: argparse.Namespace) -> dict:
    """Invalidate replay caches when observations or likelihood code change."""
    root = Path(__file__).resolve().parents[5]
    paths = [args.dataset, args.config, args.evaluation] + [
        root / path
        for path in (
            "src/agents/system_identification/smc2.py",
            "src/agents/system_identification/sysid.py",
            "src/agents/system_identification/scoring.py",
            "src/agents/system_identification/studies/common.py",
            "src/agents/simulator/internal_sim.py",
            "src/simulation/execution/force_push.py",
            "src/simulation/modelling/object.py",
            "src/simulation/modelling/constants.py",
        )
    ]
    return {
        "files": {
            str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths
        },
        "sample_stride": args.sample_stride,
        "versions": {name: version(name) for name in ("numpy", "scipy", "pybullet")},
    }


def plot_comparisons(
    reference: Grid, comparisons: list[dict], output: Path, spec: CuboidSpec
) -> None:
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(
        len(comparisons),
        len(PARAMETERS),
        figsize=(12, 3 * len(comparisons)),
        squeeze=False,
        layout="constrained",
    )
    limits = (
        (np.exp(Z_LO[0]), np.exp(Z_HI[0])),
        (Z_LO[1], Z_HI[1]),
        (Z_LO[2] * spec.H, Z_HI[2] * spec.H),
    )
    labels = ("Mass (kg)", "Friction μ", "COM height (m)")
    for row, comparison in enumerate(comparisons):
        step = comparison["step"]
        for col, axis in enumerate(axes[row]):
            bins = np.linspace(*limits[col], 41)
            values, weights = marginal_support(reference, step, col, spec.H)
            axis.hist(
                values,
                bins=bins,
                weights=weights,
                density=True,
                histtype="step",
                color="black",
                linewidth=2,
                label="Grid reference",
            )
            for trial in comparison["smc2"]:
                saved = np.load(output / f"smc_seed{trial['seed']}_step{step}.npz")
                theta = convert_points(saved["z"], spec.H)
                axis.hist(
                    theta[:, col],
                    bins=bins,
                    weights=saved["weights"],
                    density=True,
                    histtype="step",
                    alpha=0.8,
                    label=f"SMC² seed {trial['seed']}",
                )
            axis.axvline(
                spec.theta[col], color="crimson", linestyle="--", label="Ground truth"
            )
            status = (
                "cross-grid stable"
                if comparison["cross_grid"]["stable"]
                else "grid NOT converged"
            )
            axis.set(
                xlabel=labels[col], ylabel="Density", title=f"Push {step} · {status}"
            )
            if row == 0 and col == 0:
                axis.legend(fontsize=8)
    figure.savefig(output / "marginals.png", dpi=130)
    plt.close(figure)


def write_report(comparisons: list[dict], output: Path) -> None:
    lines = [
        "# Known-start posterior reference",
        "",
        "The reference uses the same uniform-in-z prior, observation scales, scoring window, and recorded pushes as SMC². Cells cover the full prior; their volumes enter the quadrature weights. Local refinement changes resolution, not prior probability.",
        "",
        "Convergence checks compare independently initialized grids using normalized marginal Wasserstein distance (<0.005 of the prior range) and log-evidence change (<0.2). These are empirical stability checks, not rigorous integration-error bounds. Broad cells are integrated within each marginal; intervals invert their piecewise-uniform CDF.",
        "",
        "| Push | Cross-grid stable | Reference mass interval (kg) | Friction interval | COM interval (m) |",
        "|---|---|---|---|---|",
    ]
    for comparison in comparisons:
        intervals = comparison["reference"]["intervals_95"]
        formatted = [
            f"[{intervals[name][0]:.4f}, {intervals[name][1]:.4f}]"
            for name in PARAMETERS
        ]
        lines.append(
            f"| {comparison['step']} | {comparison['cross_grid']['stable']} | "
            + " | ".join(formatted)
            + " |"
        )
    lines += [
        "",
        "All intervals are marginal 95% intervals, not joint regions.",
        "",
        "| Push | SMC² seed | Unique particles | COM interval (m) | Covers true COM |",
        "|---|---|---|---|---|",
    ]
    for comparison in comparisons:
        for trial in comparison["smc2"]:
            low, high = trial["distribution"]["intervals_95"]["h_c"]
            covered = trial["distribution"]["covers_truth"]["h_c"]
            lines.append(
                f"| {comparison['step']} | {trial['seed']} | {trial['unique_particles']} | [{low:.4f}, {high:.4f}] | {covered} |"
            )
    lines += [
        "",
        "See marginals.png for the distributions, comparison.json for means, correlations and predictive distributions, and refinements.json for convergence history. Raw grids and SMC² particle snapshots are saved as NPZ files.",
        "",
        "Reference predictive distributions use four independent batches of 256 posterior draws, with locations sampled inside grid cells. Predictive Monte Carlo errors are recorded separately. SMC² predictions use its weighted particle mixture, retaining at least 99.9% of mass. Development predictions do not influence fitting or grid refinement.",
        "",
        "Interpretation: where the reference is stable and broad but SMC² is narrow or misses plausible regions, the difference is a sampling-approximation failure. Where a stable reference also excludes truth, investigate the likelihood model. Unconverged steps cannot adjudicate that distinction.",
        "",
        "This is a single-object development experiment, not population calibration. No production estimator settings were changed by this runner.",
    ]
    if all(
        row["cross_grid"]["stable"] and all(row["reference"]["covers_truth"].values())
        for row in comparisons
    ):
        final = comparisons[-1]
        misses = sum(
            not trial["distribution"]["covers_truth"]["h_c"] for trial in final["smc2"]
        )
        interpretation = (
            "This directly demonstrates loss of plausible posterior mass in the particle approximation for this dataset; the corrected likelihood does not itself require those narrow COM intervals."
            if misses
            else "No final COM intervals exclude truth in these runs. Truth inclusion alone does not establish agreement with the grid distribution; inspect the complete marginals."
        )
        lines += [
            "",
            "## Finding",
            "",
            f"The stable reference intervals contain all three true parameters after every push. At the final push, {misses}/{len(final['smc2'])} SMC² seeds exclude the true COM height. {interpretation}",
            "",
            "The next justified experiment is improved particle exploration (tempering/rejuvenation) against this deterministic reference. This result does not establish that the observation model is correct on other objects or actions.",
        ]
    (output / "report.md").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path(
            "artifacts/sysid_development_known_after/dataset_varied_durations.json"
        ),
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("artifacts/sysid_development_known_after/config.json"),
    )
    parser.add_argument(
        "--evaluation",
        type=Path,
        default=Path("artifacts/sysid_development_known_after/held_out.json"),
    )
    parser.add_argument(
        "--out", type=Path, default=Path("artifacts/sysid_reference_posterior")
    )
    parser.add_argument("--grids", type=int, nargs="+", default=[12, 24])
    parser.add_argument("--refinements", type=int, default=5)
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    parser.add_argument("--sample-stride", type=int, default=12)
    parser.add_argument("--max-new-cells", type=int, default=20000)
    parser.add_argument(
        "--resume", action="store_true", help="Reuse matching saved grids in --out"
    )
    args = parser.parse_args()
    if (
        len(set(args.grids)) < 2
        or min(args.grids) < 2
        or args.refinements < 1
        or args.max_new_cells < 8
        or args.sample_stride < 1
    ):
        parser.error(
            "Use at least two initial grids (size >=2) and at least one refinement"
        )
    spec = CuboidSpec(**json.loads(args.config.read_text())["object"])
    records = load_training(args.dataset)
    if not records:
        parser.error("No accepted training records")
    evaluation = []
    for entry in json.loads(args.evaluation.read_text()):
        value = entry["record"]
        from src.simulation.execution.force_push import DenseTrajectory
        from src.simulation.modelling.actions import PushAction

        evaluation.append(
            ActionRecord(
                tuple(value["start"]),
                PushAction(**value["action"]),
                DenseTrajectory(**value["traj"]),
                value["warmup_steps"],
            )
        )
    identity = get_cache_identity(args)
    if args.resume:
        previous_config = json.loads((args.out / "config.json").read_text())
        if previous_config.get("cache_identity") != identity:
            parser.error(
                "Cached likelihoods do not match the input data, source, or scoring configuration; use a new output directory"
            )
    args.out.mkdir(parents=True, exist_ok=args.resume)
    (args.out / "config.json").write_text(
        json.dumps(
            {
                key: str(value) if isinstance(value, Path) else value
                for key, value in vars(args).items()
            }
            | {
                "object": json.loads(args.config.read_text())["object"],
                "cache_identity": identity,
                "retained_mass": RETAINED_MASS,
                "convergence_distance": CONVERGENCE_DISTANCE,
                "convergence_log_evidence": CONVERGENCE_LOG_EVIDENCE,
                "versions": {
                    name: version(name) for name in ("numpy", "scipy", "pybullet")
                },
            },
            indent=2,
        )
    )
    sim = CountingSim()
    comparisons, refinements, grids = [], [], []
    try:
        fit = SMC2SysID(
            (spec.w, spec.L, spec.H),
            n_theta=1,
            n_state=1,
            start_std=(0, 0, 0, 0),
            sample_stride=args.sample_stride,
            sim=sim,
        )
        for size in args.grids:
            start = time.perf_counter()
            print(f"Initial grid {size}³", flush=True)
            grid: Grid | None = None
            for level in range(args.refinements + 1):
                path = args.out / f"grid{size}_level{level}.npz"
                if args.resume and path.exists():
                    saved = np.load(path)
                    next_grid = Grid(
                        saved["low"], saved["high"], saved["log_likelihood"]
                    )
                elif level:
                    assert grid is not None
                    next_grid = refine_grid(grid, fit, records, args.max_new_cells)
                else:
                    next_grid = evaluate_cells(
                        *create_uniform_cells(size), fit, records
                    )
                if level:
                    assert grid is not None
                    previous, grid = grid, next_grid
                    changes = [
                        compare_grids(previous, grid, step, spec)
                        for step in range(1, len(records) + 1)
                    ]
                else:
                    grid = next_grid
                    changes = None
                print(
                    f"Grid {size}, refinement {level}: {len(grid.low)} cells; "
                    f"stable={None if changes is None else [item['stable'] for item in changes]}",
                    flush=True,
                )
                refinements.append(
                    {
                        "initial_size": size,
                        "level": level,
                        "cells": len(grid.low),
                        "seconds_so_far": time.perf_counter() - start,
                        "changes": changes,
                    }
                )
                np.savez_compressed(
                    args.out / f"grid{size}_level{level}.npz",
                    low=grid.low,
                    high=grid.high,
                    log_likelihood=grid.log_likelihood,
                )
                (args.out / "refinements.json").write_text(
                    json.dumps(refinements, indent=2)
                )
            grids.append(grid)
        reference = grids[-1]
        for step in range(1, len(records) + 1):
            weights, evidence = reference.posterior(step)
            comparison = {
                "step": step,
                "cross_grid": compare_grids(grids[-2], reference, step, spec),
                "reference": summarize_grid(reference, step, spec),
                "log_evidence": evidence,
                "reference_predictive": evaluate_predictive_distribution(
                    reference.points, weights, fit, evaluation, spec, grid=reference
                ),
                "smc2": [],
            }
            comparisons.append(comparison)
        for seed in args.seeds:
            smc = SMC2SysID(
                (spec.w, spec.L, spec.H),
                n_theta=64,
                proposal="fixed",
                n_state=1,
                start_std=(0, 0, 0, 0),
                seed=seed,
                sample_stride=args.sample_stride,
                sim=sim,
            )
            for step, comparison in enumerate(comparisons, 1):
                smc.update(records[:step])
                # Treat the grid only as a numerical integration rule here.
                theta, weights = smc.particles, smc.weights
                np.savez_compressed(
                    args.out / f"smc_seed{seed}_step{step}.npz",
                    z=theta,
                    weights=weights,
                )
                comparison["smc2"].append(
                    {
                        "seed": seed,
                        "distribution": summarize_distribution(theta, weights, spec),
                        "unique_particles": len(np.unique(theta, axis=0)),
                        "ess": smc.last_ess,
                        "predictive": evaluate_predictive_distribution(
                            theta, weights, fit, evaluation, spec
                        ),
                    }
                )
        (args.out / "comparison.json").write_text(json.dumps(comparisons, indent=2))
        plot_comparisons(reference, comparisons, args.out, spec)
        write_report(comparisons, args.out)
    finally:
        sim.close()
    print(f"Saved reference comparison to {args.out}")


if __name__ == "__main__":
    main()

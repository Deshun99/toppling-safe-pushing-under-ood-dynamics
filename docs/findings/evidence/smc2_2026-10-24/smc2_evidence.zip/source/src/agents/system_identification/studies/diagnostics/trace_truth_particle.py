"""Oracle diagnostic: insert exact physics and trace resampling and moves.

This deliberately privileged initialization is not a performance benchmark.
Paired controls retain the original random particle. Diagnostic tracing adds
no inference RNG draws and does not modify the production estimator.
"""

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
from scipy.stats import wasserstein_distance

from src.agents.system_identification.smc2 import SMC2SysID
from src.agents.system_identification.sysid import Z_LO, Z_HI
from src.agents.system_identification.studies.common import CountingSim, load_training
from src.agents.system_identification.studies.diagnostics.reference_posterior import (
    Grid,
    marginal_support,
)
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.records import ActionRecord

PRIOR_SCALED_RADIUS = 0.05
COM_BAND_HALF_WIDTH = 0.005  # Five millimetres on either side of true COM.


class TracedSMC2(SMC2SysID):
    """Observe production resampling/move methods without changing their RNG."""

    def __init__(
        self,
        spec: CuboidSpec,
        truth_scores: np.ndarray,
        *,
        inject_truth: bool,
        **kwargs,
    ):
        super().__init__((spec.w, spec.L, spec.H), **kwargs)
        self.truth = np.array([np.log(spec.m), spec.mu, spec.h_c / spec.H])
        self.truth_scores = truth_scores
        self.height = spec.H
        self.inject_truth = inject_truth
        self.roots = np.arange(self.n_theta)
        if inject_truth:
            self._z[0] = self.truth
        self.step = 0
        self.beta = 1.0
        self.targets = np.zeros(self.n_theta)
        self.events: list[dict] = []

    def summarize(self) -> dict:
        exact = np.all(self._z == self.truth, axis=1)
        lineage = (
            self.roots == 0 if self.inject_truth else np.zeros(self.n_theta, dtype=bool)
        )
        distance = np.linalg.norm((self._z - self.truth) / (Z_HI - Z_LO), axis=1)
        com = self._z[:, 2] * self.height
        near_com = abs(com - self.truth[2] * self.height) <= COM_BAND_HALF_WIDTH
        truth_target = (
            self.truth_scores[: self.step - 1].sum()
            + self.beta * self.truth_scores[self.step - 1]
            if self.step
            else 0.0
        )
        full = np.array([state.log_likelihood for state in self._filters])
        return {
            "step": self.step,
            "beta": self.beta,
            "truth_increment": float(self.truth_scores[self.step - 1])
            if self.step
            else None,
            "truth_cumulative_log_likelihood": float(
                self.truth_scores[: self.step].sum()
            ),
            "truth_target_rank": int(
                1 + np.count_nonzero(self.targets > truth_target + 1e-9)
            ),
            "truth_full_likelihood_rank": int(
                1 + np.count_nonzero(full > self.truth_scores[: self.step].sum() + 1e-9)
            ),
            "best_minus_truth_log_target": float(self.targets.max() - truth_target),
            "exact_truth_count": int(exact.sum()),
            "exact_truth_weight": float(self.weights[exact].sum()),
            "truth_lineage_count": int(lineage.sum()),
            "truth_lineage_weight": float(self.weights[lineage].sum()),
            "near_truth_count": int((distance <= PRIOR_SCALED_RADIUS).sum()),
            "near_truth_weight": float(
                self.weights[distance <= PRIOR_SCALED_RADIUS].sum()
            ),
            "minimum_scaled_distance": float(distance.min()),
            "com_band_weight": float(self.weights[near_com].sum()),
            "unique_particles": len(np.unique(self._z, axis=0)),
            "unique_roots": len(np.unique(self.roots)),
            "ess": float(1 / np.sum(self.weights**2)),
        }

    def _select_tempering_beta(self, beta, increments):
        next_beta = super()._select_tempering_beta(beta, increments)
        self.beta = next_beta
        full = np.array([state.log_likelihood for state in self._filters])
        self.targets = full - increments + next_beta * increments
        return next_beta

    def _resample_particles(self):
        before = self.summarize()
        ancestors = super()._resample_particles()
        self.roots = self.roots[ancestors]
        self.targets = self.targets[ancestors]
        self.events.append(
            {
                "kind": "resample",
                "before": before,
                "after": self.summarize(),
                "ancestors": ancestors.tolist(),
            }
        )
        return ancestors

    def record_moves(self, before, proposals, acceptances):
        moved = np.flatnonzero(np.any(self._z != before, axis=1))
        self.events.append(
            {
                "kind": "move",
                "step": self.step,
                "beta": self.beta,
                "proposals": self.proposals - proposals,
                "accepted": self.acceptances - acceptances,
                "moved_indices": moved.tolist(),
                "after": self.summarize(),
            }
        )

    def _resample_move(self):
        self.beta = 1.0
        self.targets = np.array([state.log_likelihood for state in self._filters])
        proposals, acceptances = self.proposals, self.acceptances
        # The parent resamples before its proposals. The resampling event stores
        # ancestry; reconstruct the copied positions to distinguish moves.
        original = self._z.copy()
        super()._resample_move()
        ancestors = np.asarray(self.events[-1]["ancestors"])
        self.targets = np.array([state.log_likelihood for state in self._filters])
        self.record_moves(original[ancestors], proposals, acceptances)

    def _move_tempered_particles(self, record, beta, past, increments):
        before = self._z.copy()
        proposals, acceptances = self.proposals, self.acceptances
        super()._move_tempered_particles(record, beta, past, increments)
        self.targets = past + beta * increments
        self.record_moves(before, proposals, acceptances)

    def update(self, history):
        self.step = len(history)
        result = super().update(history)
        self.beta = 1.0
        self.targets = np.array([state.log_likelihood for state in self._filters])
        self.events.append({"kind": "update", "after": self.summarize()})
        return result


def evaluate_truth(
    spec: CuboidSpec, records: list[ActionRecord], stride: int
) -> np.ndarray:
    with SMC2SysID(
        (spec.w, spec.L, spec.H),
        n_theta=1,
        n_state=1,
        start_std=(0, 0, 0, 0),
        sample_stride=stride,
    ) as probe:
        truth = np.array([np.log(spec.m), spec.mu, spec.h_c / spec.H])
        return np.array(
            [probe._evaluate_record(truth, record)[1] for record in records]
        )


def plot_traces(rows: list[dict], output: Path) -> None:
    import matplotlib.pyplot as plt

    regimes = list(dict.fromkeys(row["regime"] for row in rows))
    figure, axes = plt.subplots(
        2, len(regimes), figsize=(12, 6), squeeze=False, layout="constrained"
    )
    for col, regime in enumerate(regimes):
        for trial in rows:
            if trial["regime"] != regime or not trial["injected"]:
                continue
            first = next(
                event for event in trial["events"] if event["kind"] == "resample"
            )
            initial_weight = 1 / len(first["ancestors"])
            summaries = [
                {
                    "step": 0,
                    "beta": 1,
                    "exact_truth_weight": initial_weight,
                    "truth_lineage_weight": initial_weight,
                }
            ]
            for event in trial["events"]:
                if "before" in event:
                    summaries.append(event["before"])
                summaries.append(event["after"])
            x = [s["step"] - 1 + s["beta"] for s in summaries]
            for row, key in enumerate(("exact_truth_weight", "truth_lineage_weight")):
                axes[row, col].plot(
                    x,
                    [s[key] for s in summaries],
                    color=f"C{trial['seed'] - 1}",
                    linestyle="-" if trial["mode"] == "full" else "--",
                    drawstyle="steps-post",
                    label=f"{trial['mode']}, seed {trial['seed']}",
                )
        for row, label in enumerate(
            ("Weight on exact truth copies", "Weight on truth descendants")
        ):
            axes[row, col].set(
                title=regime if row == 0 else None,
                xlabel="Push number (fraction = evidence introduced)",
                ylabel=label,
                ylim=(-0.02, 1.02),
            )
            axes[row, col].grid(alpha=0.2)
        axes[0, col].legend(fontsize=8)
    figure.suptitle("Injected ground truth: resampling and accepted moves")
    figure.savefig(output / "truth_survival.png", dpi=150)
    plt.close(figure)


def write_report(rows: list[dict], output: Path) -> None:
    lines = [
        "# Ground-truth-particle diagnostic",
        "",
        "One initial random particle is replaced by the exact known physics, without increasing its weight. Paired controls use the original population and identical RNG seeds. Both use exact starts, one inner state, corrected scoring, and two proposal attempts per particle per resampling stage. Oracle initialization is diagnostic only, not a valid performance baseline.",
        "",
        "Exact copies, descendants, and nearby hypotheses are different: a legitimate accepted move removes an exact copy but retains its ancestry. An extinct lineage does not prove a posterior region was lost. The local ball uses Euclidean distance <=0.05 in prior-scaled z coordinates; the COM band is truth ±5 mm and does not constrain mass/friction.",
        "",
        "Ranks compare the separately evaluated true likelihood with the current population (ties share rank). Rank 1 is best. During tempering, target ranks use full old evidence plus beta times new evidence; full-likelihood ranks are reported separately. Weights before resampling include the population's inherited weights. A good likelihood rank alone does not guarantee dominant weight.",
        "",
        "| Sequence | Mode | Seed | Injected | Final exact copies | Final truth descendants | Distinct particles | Truth full-likelihood rank | COM band weight | COM distance to grid (mm) |",
        "|---|---|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    injected = [row for row in rows if row["injected"]]
    first_resamples = [
        next(event for event in row["events"] if event["kind"] == "resample")
        for row in injected
    ]
    full = [row for row in injected if row["mode"] == "full"]
    gradual = [row for row in injected if row["mode"] == "gradual"]
    full_weights = [row["summary"]["exact_truth_weight"] for row in full]
    findings = [
        "## Main findings",
        "",
        f"At first resampling, truth has the best target likelihood (rank 1, allowing ties) in {sum(event['before']['truth_target_rank'] == 1 for event in first_resamples)}/{len(first_resamples)} injected runs. This is evidence against poor likelihood scoring of truth in the corrected known-start setup; there is no noisy inner likelihood estimation here.",
        "",
        f"Full updates retain exact truth copies in {sum(row['summary']['exact_truth_count'] > 0 for row in full)}/{len(full)} final populations. Final exact-truth weight ranges from {min(full_weights):.1%} to {max(full_weights):.1%}. Once explicitly supplied, truth is strongly rewarded rather than discarded.",
        "",
        f"Gradual updates retain exact truth in {sum(row['summary']['exact_truth_count'] > 0 for row in gradual)}/{len(gradual)} final populations and any truth descendants in {sum(row['summary']['truth_lineage_count'] > 0 for row in gradual)}/{len(gradual)}. The move traces distinguish accepted moves away from the exact point from later removal of descendants by resampling. Moves at weak intermediate likelihoods may legitimately leave a high-likelihood point; a surviving neighborhood matters more than preserving its exact coordinates.",
        "",
        "Injecting truth does not establish correct uncertainty: an artificially inserted high-density point can dominate a poorly explored population, while the integrated posterior remains broad. Inspect the grid distances below rather than interpreting truth-copy survival as sampler correctness. The original control populations can omit highly competitive physics, and their fixed random-walk proposals may fail to discover it. These findings concern the tested dataset, not all observation models.",
        "",
        "![Weight on exact copies and their descendants](truth_survival.png)",
        "",
    ]
    lines[2:2] = findings
    for row in rows:
        s = row["summary"]
        distance = row.get("com_distance_to_grid_mm")
        lines.append(
            f"| {row['regime']} | {row['mode']} | {row['seed']} | {row['injected']} | {s['exact_truth_count']} | {s['truth_lineage_count']} | {s['unique_particles']} | {s['truth_full_likelihood_rank']} | {s['com_band_weight']:.3f} | {'—' if distance is None else f'{distance:.2f}'} |"
        )
    lines += [
        "",
        "## First resampling with injected truth",
        "",
        "| Sequence | Mode | Seed | beta | Truth target rank | Truth weight before | Copies after resampling |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        if not row["injected"]:
            continue
        events = [event for event in row["events"] if event["kind"] == "resample"]
        if events:
            event = events[0]
            s = event["before"]
            lines.append(
                f"| {row['regime']} | {row['mode']} | {row['seed']} | {s['beta']:.4f} | {s['truth_target_rank']} | {s['exact_truth_weight']:.5f} | {event['after']['exact_truth_count']} |"
            )
    lines += [
        "",
        "## Trace files and interpretation",
        "",
        "Each trial JSON records pre/post resampling summaries and ancestry indices, followed by proposal/acceptance counts and indices that moved. Snapshot NPZ files store particles, weights and root ancestry after each push. Accepted descendants are not pinned at truth or protected from resampling. Counterfactual likelihood probes do not enter inference weights or consume inference RNG draws.",
        "",
        "This is one object, two saved datasets and three seeds. Full updates and gradual updates have unequal compute. Controls replace only the injected slot, but later resampling and proposal paths can diverge. Losing an exact atom is not evidence of incorrect inference for a continuous posterior. Grid comparison is available only for varied durations and is an empirical numerical check, not ground truth.",
    ]
    (output / "report.md").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline",
        type=Path,
        default=Path("artifacts/sysid_development_tempered_256"),
    )
    parser.add_argument(
        "--out", type=Path, default=Path("artifacts/sysid_truth_particle_trace")
    )
    args = parser.parse_args()
    config = json.loads((args.baseline / "config.json").read_text())
    spec = CuboidSpec(**config["object"])
    data = {
        regime: load_training(
            args.baseline / f"dataset_{regime.replace(' ', '_')}.json"
        )
        for regime in config["regimes"]
    }
    args.out.mkdir(parents=True, exist_ok=False)
    source = Path(__file__)
    paths = [
        args.baseline / "config.json",
        source,
        Path("src/agents/system_identification/smc2.py"),
        Path("src/agents/system_identification/scoring.py"),
    ]
    paths += [
        args.baseline / f"dataset_{regime.replace(' ', '_')}.json" for regime in data
    ]
    provenance = {
        "object": asdict(spec),
        "n_theta": config["n_theta"],
        "n_state": 1,
        "proposal": "fixed",
        "start_std": [0] * 4,
        "sample_stride": config["sample_stride"],
        "seeds": config["seeds"],
        "modes": ["full", "gradual"],
        "injected_slot": 0,
        "initial_weight": 1 / config["n_theta"],
        "diagnostic_only": True,
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True
        ).strip(),
        "sha256": {
            str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths
        },
    }
    grid_path = Path("artifacts/sysid_reference_posterior/grid24_level5.npz")
    grid = None
    if grid_path.exists():
        saved = np.load(grid_path)
        grid = Grid(saved["low"], saved["high"], saved["log_likelihood"])
        # Verify saved midpoint likelihoods still agree with the current scorer.
        with SMC2SysID(
            (spec.w, spec.L, spec.H),
            n_theta=1,
            n_state=1,
            start_std=(0, 0, 0, 0),
            sample_stride=config["sample_stride"],
        ) as probe:
            indices = np.linspace(0, len(grid.low) - 1, 32, dtype=int)
            replayed = np.array(
                [
                    [
                        probe._evaluate_record(grid.points[i], rec)[1]
                        for rec in data["varied durations"]
                    ]
                    for i in indices
                ]
            )
            difference = float(np.max(abs(replayed - grid.log_likelihood[indices])))
            if difference > 1e-8:
                raise ValueError("Saved grid likelihoods differ from the current model")
            provenance["grid_likelihood_check_max_difference"] = difference
            provenance["grid_sha256"] = hashlib.sha256(
                grid_path.read_bytes()
            ).hexdigest()
    (args.out / "config.json").write_text(json.dumps(provenance, indent=2) + "\n")
    rows = []
    for regime, records in data.items():
        truth_scores = evaluate_truth(spec, records, config["sample_stride"])
        for mode in ("full", "gradual"):
            for seed in config["seeds"]:
                for injected in (False, True):
                    sim = CountingSim()
                    try:
                        fit = TracedSMC2(
                            spec,
                            truth_scores,
                            inject_truth=injected,
                            n_theta=config["n_theta"],
                            proposal="fixed",
                            n_state=1,
                            start_std=(0, 0, 0, 0),
                            sample_stride=config["sample_stride"],
                            seed=seed,
                            sim=sim,
                            temper_updates=mode == "gradual",
                        )
                        stem = f"{regime.replace(' ', '_')}_{mode}_seed{seed}_{'injected' if injected else 'control'}"
                        steps = []
                        for step in range(1, len(records) + 1):
                            fit.update(records[:step])
                            steps.append(fit.summarize())
                            np.savez_compressed(
                                args.out / f"{stem}_step{step}.npz",
                                z=fit.particles,
                                weights=fit.weights,
                                roots=fit.roots,
                            )
                        row = {
                            "regime": regime,
                            "mode": mode,
                            "seed": seed,
                            "injected": injected,
                            "fit_replays": sim.replay_count,
                            "summary": fit.summarize(),
                            "steps": steps,
                            "events": fit.events,
                            "proposals": fit.proposals,
                            "acceptances": fit.acceptances,
                        }
                        if grid is not None and regime == "varied durations":
                            values, weights = marginal_support(
                                grid, len(records), 2, spec.H
                            )
                            row["com_distance_to_grid_mm"] = (
                                1000
                                * wasserstein_distance(
                                    values,
                                    fit.particles[:, 2] * spec.H,
                                    weights,
                                    fit.weights,
                                )
                            )
                        rows.append(row)
                        (args.out / f"{stem}.json").write_text(
                            json.dumps(row, indent=2) + "\n"
                        )
                        print(
                            f"{stem}: exact={row['summary']['exact_truth_count']}, descendants={row['summary']['truth_lineage_count']}, unique={row['summary']['unique_particles']}",
                            flush=True,
                        )
                    finally:
                        sim.close()
    (args.out / "summary.json").write_text(
        json.dumps(
            [
                {key: value for key, value in row.items() if key != "events"}
                for row in rows
            ],
            indent=2,
        )
        + "\n"
    )
    write_report(rows, args.out)
    plot_traces(rows, args.out)
    print(f"Saved diagnostic to {args.out}")


if __name__ == "__main__":
    main()

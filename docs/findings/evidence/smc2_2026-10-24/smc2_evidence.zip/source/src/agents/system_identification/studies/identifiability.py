"""M2/E4 identifiability study (outline §9.5, milestone M2).

Scripted push sequences on a target object with known hidden theta. For each
excitation regime, records the action history, runs CMA-ES system
identification from it, and reports per-parameter estimation error and the
spread of the retained top-K hypothesis set.

Run from the repo root:  .venv/bin/python -m src.agents.system_identification.studies.identifiability
"""

from typing import TypedDict


import numpy as np
import pybullet as p

from src.simulation.modelling.constants import DT
from src.simulation.environment.env import PushEnv
from src.simulation.modelling.object import CuboidSpec
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.records import ActionRecord
from src.agents.system_identification.sysid import SysID, SysIDResult

WARMUP = 8  # free steps before each push so replay contact matches (see
# ForcePushExecutor.execute docstring)

# True (hidden) parameters of the test object. mu = 0.3 leaves room for
# above-COM pushes without toppling (analytic condition, outline §4):
#   (F/mg)(h - h_c) <= w/2 - mu*h_c  ->  F <= 4.9 N at h = 0.6H.
SPEC = CuboidSpec(w=0.08, L=0.08, H=0.20, m=1.0, mu=0.3, h_c=0.10)


def settle(target: PushEnv, max_steps: int = round(1.0 / DT)) -> bool:
    """Step until flat, still, and nearly stationary.

    Near-tipping outcomes are bistable AND depend on the sliding state
    (measured: F=4.0 at 0.7H topples a resting box to 89.6 deg but tilts
    a fast-sliding box only 1.97 deg), so tilt-excitation pushes start
    from rest for reproducible replay."""
    for _ in range(max_steps):
        _, psi, vx, wy = target.cuboid.state()
        if abs(psi) < 1e-3 and abs(wy) < 1e-3 and abs(vx) < 0.02:
            return True
        p.stepSimulation(physicsClientId=target.client)
    return False


def settle_or_reset(target: PushEnv) -> None:
    """Ensure a clean, reproducible start state before tilt-excitation
    pushes. Near-tipping replay is bistable, and mid-motion starts carry
    unrecorded residual velocities (vz/roll/yaw) that the replay zeroes
    out — a fallen object gets replaced by a fresh one at the current x."""
    if not settle(target):
        x, _, _, _ = target.cuboid.state()
        target.replace_object(x=x)
        settle(target)


def regimes() -> dict[str, list[PushAction]]:
    """Excitation regimes (outline §9.5). Heights are fractions of H; passive
    pushes are F = 0 free-motion intervals.

    The "tilt boundary" regime pushes near the analytic tipping edge
    ((F/mg)(h - h_c) <= w/2 - mu*h_c -> boundary at F ~= 2.5 N for h = 0.7H):
    these excite real tilt signal without full topples and are the only
    pushes that identify h_c — the safety-information trade-off of §4.
    """
    H = SPEC.H
    return {
        "near slip threshold": [
            PushAction(h=0.30 * H, F=F, tau=0.30) for F in (3.0, 3.5, 4.0, 5.0)
        ],
        "varied magnitudes": [
            PushAction(h=0.30 * H, F=F, tau=0.25) for F in (3.5, 5.0, 7.0, 9.0)
        ],
        "varied heights": [
            PushAction(h=h * H, F=5.0, tau=0.30) for h in (0.10, 0.30, 0.45)
        ],
        "varied durations": [
            PushAction(h=0.30 * H, F=5.0, tau=tau) for tau in (0.10, 0.25, 0.40)
        ],
        "tilt boundary": [
            PushAction(h=0.60 * H, F=4.0, tau=0.40),
            PushAction(h=0.60 * H, F=4.5, tau=0.40),
            PushAction(h=0.70 * H, F=2.0, tau=0.40),
            PushAction(h=0.70 * H, F=2.3, tau=0.40),
        ],
        # sub-threshold boundary pushes from rest:
        # they stay flat, and a replay tips iff its
        # candidate h_c is too low — constraint-type
        # h_c information. Full topples are excluded
        # from estimation histories: their chaotic
        # post-topple segments dominate the loss.
        "passive mixed": [
            PushAction(h=0.30 * H, F=5.0, tau=0.25),
            PushAction(h=0.30 * H, F=0.0, tau=0.30),
            PushAction(h=0.45 * H, F=5.0, tau=0.25),
            PushAction(h=0.30 * H, F=0.0, tau=0.30),
            PushAction(h=0.60 * H, F=4.5, tau=0.40),
            PushAction(h=0.70 * H, F=2.3, tau=0.40),
        ],
        "full mixed": [
            PushAction(h=0.30 * H, F=3.0, tau=0.30),
            PushAction(h=0.30 * H, F=4.0, tau=0.30),
            PushAction(h=0.30 * H, F=5.0, tau=0.30),
            PushAction(h=0.10 * H, F=5.0, tau=0.30),
            PushAction(h=0.45 * H, F=5.0, tau=0.30),
            PushAction(h=0.30 * H, F=5.0, tau=0.10),
            PushAction(h=0.30 * H, F=5.0, tau=0.40),
            PushAction(h=0.30 * H, F=0.0, tau=0.30),
            PushAction(h=0.60 * H, F=4.5, tau=0.40),
            PushAction(h=0.70 * H, F=2.3, tau=0.40),
            PushAction(h=0.30 * H, F=7.0, tau=0.25),
            PushAction(h=0.30 * H, F=9.0, tau=0.25),
        ],
    }


class EstimationErrors(TypedDict):
    m_err: float
    mu_err: float
    hc_err: float
    spread: tuple[float, float, float]


def errors(res: SysIDResult) -> EstimationErrors:
    m_hat, mu_hat, hc_hat = res.point.theta
    m_err = abs(m_hat - SPEC.m) / SPEC.m
    mu_err = abs(mu_hat - SPEC.mu)
    hc_err = abs(hc_hat - SPEC.h_c) / SPEC.H
    spread = [float(np.std([h.theta[i] for h in res.hypotheses])) for i in range(3)]
    return {
        "m_err": m_err,
        "mu_err": mu_err,
        "hc_err": hc_err,
        "spread": (spread[0], spread[1], spread[2]),
    }


def main() -> None:
    target = PushEnv(fixed_spec=SPEC)
    print(
        f"true theta: m={SPEC.m:.2f} kg, mu={SPEC.mu:.2f}, "
        f"h_c={SPEC.h_c:.3f} m ({SPEC.h_c / SPEC.H:.2f}H)\n"
    )

    results: dict[str, SysIDResult] = {}
    for name, actions in regimes().items():
        target.reset()
        history: list[ActionRecord] = []
        for action in actions:
            if action.h > SPEC.h_c:  # tilt-excitation push: settle for a clean start
                settle_or_reset(target)
            history.append(target.push(action, warmup_steps=WARMUP))
        sysid = SysID(geometry=(SPEC.w, SPEC.L, SPEC.H))
        res = sysid.update(history)
        sysid.close()
        results[name] = res

        m_hat, mu_hat, hc_hat = res.point.theta
        e = errors(res)
        print(
            f"{name:20s} | m_hat={m_hat:5.2f} (err {e['m_err'] * 100:4.0f}%) "
            f"| mu_hat={mu_hat:4.2f} (err {e['mu_err']:4.2f}) "
            f"| hc_hat={hc_hat:4.3f} (err {e['hc_err'] * 100:4.0f}%) "
            f"| top-K std: (m {e['spread'][0]:.2f}, mu {e['spread'][1]:.2f}, hc {e['spread'][2]:.3f})"
        )

    print("\nTop-K hypotheses for 'full mixed':")
    for hyp in results["full mixed"].hypotheses:
        m, mu, hc = hyp.theta
        print(
            f"  m={m:5.2f}  mu={mu:4.2f}  h_c={hc:4.3f}  "
            f"loss={hyp.loss:9.1f}  w={hyp.weight:.2f}"
        )

    print("\nBistable-band check (outline §13 h_c risk): repeat the boundary")
    print("push (0.60H, F=5.0) from rest N times — the outcome flips run to run:")
    topples = 0
    N = 10
    for _ in range(N):
        settle_or_reset(target)
        rec = target.push(
            PushAction(h=0.60 * SPEC.H, F=5.0, tau=0.40), warmup_steps=WARMUP
        )
        tilt = np.degrees(max(abs(t) for t in rec.traj.psi[WARMUP:]))
        topples += tilt > np.degrees(SPEC.crit_tilt)
    print(f"  {topples}/{N} runs toppled at identical commanded push")

    target.close()
    print("\nM2/E4 identifiability study complete.")


if __name__ == "__main__":
    main()

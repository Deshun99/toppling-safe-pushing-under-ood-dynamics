"""Headless SMC² example; reports and plots the posterior after each push.

Run: .venv/bin/python -m src.agents.system_identification.studies.smc2_demo --n-theta 64 --n-state 8
The true physics configures ONLY the target; it is not passed to the estimator.
"""

import argparse

import matplotlib.pyplot as plt
import numpy as np

from src.simulation.modelling.actions import PushAction
from src.simulation.environment.env import PushEnv
from src.simulation.modelling.object import CuboidSpec
from src.agents.system_identification.smc2 import SMC2SysID


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n-theta", type=int, default=128)
    parser.add_argument("--n-state", type=int, default=32)
    parser.add_argument(
        "--proposal", choices=("fixed", "covariance"), default="covariance"
    )
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--m", type=float, default=1.0)
    parser.add_argument("--mu", type=float, default=0.3)
    parser.add_argument("--hc", type=float, default=0.1)
    parser.add_argument(
        "--push-forces",
        type=lambda s: [float(x) for x in s.split(",")],
        default="3.0,4.0,5.0,7.0",
    )
    args = parser.parse_args()
    spec = CuboidSpec(w=0.08, L=0.08, H=0.2, m=args.m, mu=args.mu, h_c=args.hc)
    target = PushEnv(fixed_spec=spec)
    try:
        with SMC2SysID(
            (spec.w, spec.L, spec.H),
            n_theta=args.n_theta,
            n_state=args.n_state,
            seed=args.seed,
            proposal=args.proposal,
        ) as fit:
            history = []
            for push_number, force in enumerate(args.push_forces, start=1):
                # Separate episodes share the same hidden object parameters.
                target.reset(seed=args.seed)
                rec = target.push(PushAction(h=0.02, F=force, tau=0.1), warmup_steps=8)
                # Conservative observable tilt limit, independent of true COM.
                if max(abs(v) for v in rec.traj.psi) > 0.15:
                    print(f"Skipping F={force}: trajectory outside upright regime")
                    continue
                history.append(rec)
                result = fit.update(history)
                theta = fit.particles
                theta[:, 0] = np.exp(theta[:, 0])
                theta[:, 2] *= spec.H
                mean = fit.weights @ theta
                std = np.sqrt(fit.weights @ (theta - mean) ** 2)
                print(
                    f"F={force:.1f}: mean(m, mu, hc)={mean.round(4)}, "
                    f"std={std.round(4)}, pre-resample ESS={fit.last_ess:.1f}, "
                    f"Highest posterior-mass theta(m, mu, hc)="
                    f"{np.asarray(result.point.theta).round(4)}"
                )
                figure = fit.plot_particle_distribution(ground_truth=spec.theta)
                figure.suptitle(
                    f"Physics posterior after push {push_number} · F={force:.1f} N"
                    f" · {fit.n_theta} particles"
                )
                plt.show(block=False)
                plt.pause(0.001)  # Let the GUI draw before the next push.
            print(
                f"Resampling events: {fit.resampling_count}; "
                f"PMMH accepted: {fit.acceptances}/{fit.proposals}"
            )
            if history:
                print("Retained hypotheses:", result.hypotheses)
            print("Evaluation-only true theta:", spec.theta)
    finally:
        target.close()
    plt.show()


if __name__ == "__main__":
    main()

"""
Online system identification (M2).

Outline §6: after each target action, candidates z = (log m, mu, h_c/H) are
scored by replaying the recorded action in the internal (headless) simulator
and comparing dense trajectories. The point estimate is the argmin of the
loss; the top-K low-loss hypotheses are retained with softmax weights
(temperature T). Estimates configure the internal simulator only — never
appended to the policy observation (§3.2).
"""

from dataclasses import dataclass, field
import math
from collections.abc import Mapping, Sequence

import numpy as np
from numpy.typing import NDArray

from src.agents.simulator.internal_sim import InternalSim
from src.agents.system_identification.scoring import get_scoring_indices
from src.simulation.modelling.records import ActionRecord
from src.simulation.modelling.object import CuboidSpec, Geometry, PhysicsParameters
from src.simulation.execution.force_push import DenseTrajectory

# 1/sigma^2 scales for the trajectory-discrepancy loss (outline §6 eq. for
# L(z)). Calibrated from the replay-fidelity noise floor at the true theta
# via src/agents/system_identification/studies/calibrate_scales.py: each quantity is weighted by its own
# reproducibility, so tilt terms (identifying h_c) are not drowned by
# position terms in raw SI units. Recalibrate if the sim changes.
LOSS_SCALES: dict[str, float] = {
    "x": 7.899e04,  # mse 1.266e-05 m^2 per sample
    "psi": 4.534e06,  # mse 2.206e-07 rad^2
    "xdot": 2.402e03,  # mse 4.163e-04 (m/s)^2
    "psidot": 5.240e02,  # mse 1.908e-03 (rad/s)^2
}

# Search bounds for z = (log m, mu, h_c/H): wider than the training
# distribution (m 0.5-1.5, mu 0.3-0.7, h_c/H 0.35-0.60) so OOD parameters
# (m 0.2-3.0, mu 0.1-1.1, h_c/H 0.20-0.80) stay reachable (outline §6/§9.1).
Z_LO = np.array([math.log(0.2), 0.10, 0.20])
Z_HI = np.array([math.log(3.0), 1.10, 0.80])
N_PHYSICS_PARAMETERS = Z_LO.size  # log mass, friction, and relative COM height
Z_PRIOR_MEAN = np.array([math.log(0.866), 0.5, 0.475])  # training prior (§6)
Z_PRIOR_SIGMA = 0.3


def convert_z_to_cuboid_spec(
    z: Sequence[float] | NDArray[np.float64], geometry: Geometry
) -> CuboidSpec:
    """Candidate z = (log m, mu, h_c/H) -> CuboidSpec for the internal sim."""
    w, L, H = geometry
    return CuboidSpec(w=w, L=L, H=H, m=math.exp(z[0]), mu=z[1], h_c=z[2] * H)


def trajectory_loss(
    recorded: DenseTrajectory,
    simulated: DenseTrajectory,
    scales: Mapping[str, float] | None = None,
    *,
    warmup_steps: int = 0,
    sample_stride: int = 1,
) -> float:
    """Squared trajectory discrepancy, summed over aligned samples.

    Both trajectories are sampled at the same dt over the same action, so
    alignment is by index; the shorter one truncates. Warm-up samples are
    always excluded; downsampling retains the recording's original phase.
    """
    scales = scales or LOSS_SCALES
    n = min(len(recorded.x), len(simulated.x))
    if not n:
        return 0.0
    indices = get_scoring_indices(
        n,
        warmup_steps=warmup_steps,
        sample_stride=sample_stride,
    )
    total = 0.0
    for key, w in scales.items():
        a = np.asarray(getattr(recorded, key))[indices[0] : n : sample_stride]
        b = np.asarray(getattr(simulated, key))[indices[0] : n : sample_stride]
        total += w * float(np.sum((a - b) ** 2))
    return total


@dataclass
class Hypothesis:
    theta: PhysicsParameters  # (m, mu, h_c)
    loss: float
    weight: float = 1.0  # softmax over the retained set, w_k ~ exp(-L/T)


@dataclass
class SysIDResult:
    point: Hypothesis  # argmin estimate
    hypotheses: list[Hypothesis] = field(default_factory=list)  # top-K, weighted


class SysID:
    """CMA-ES over z, scoring candidates by replaying the history in an
    internal simulator. One instance per test object; the history persists
    across episodes for that object (outline §8.2)."""

    def __init__(
        self,
        geometry: Geometry,
        K: int = 4,
        temperature: float = 1.0,
        iterations: int = 20,
        restarts: int = 2,
        seed: int = 0,
        *,
        sample_stride: int = 1,
    ) -> None:
        import cma

        if (
            not isinstance(sample_stride, int)
            or isinstance(sample_stride, bool)
            or sample_stride < 1
        ):
            raise ValueError("sample_stride must be a positive integer")
        self._cma = cma
        self.geometry = geometry  # observable (w, L, H)
        self.K = K
        self.temperature = temperature
        self.iterations = iterations
        self.restarts = restarts
        self.seed = seed
        self.sample_stride = sample_stride
        self.sim = InternalSim()

    def loss(
        self, z: Sequence[float] | NDArray[np.float64], history: Sequence[ActionRecord]
    ) -> float:
        spec = convert_z_to_cuboid_spec(z, self.geometry)
        return sum(
            trajectory_loss(
                rec.traj,
                self.sim.replay(spec, rec),
                warmup_steps=rec.warmup_steps,
                sample_stride=self.sample_stride,
            )
            for rec in history
        )

    def _run_es(
        self,
        history: Sequence[ActionRecord],
        seed: int,
        *,
        max_evaluations: int | None = None,
    ) -> list[tuple[NDArray[np.float64], float]]:
        """Run from the training prior, returning evaluated (z, loss) pairs.

        An evaluation cap replaces the iteration limit. A final partial
        population is scored and retained but never passed to CMA's tell().
        """
        es = self._cma.CMAEvolutionStrategy(
            Z_PRIOR_MEAN,
            Z_PRIOR_SIGMA,
            {"bounds": [Z_LO, Z_HI], "seed": seed, "verbose": -9},
        )
        evaluated: list[tuple[NDArray[np.float64], float]] = []
        generations = (
            self.iterations
            if max_evaluations is None
            else math.ceil(max_evaluations / es.popsize)
        )
        for _ in range(generations):
            solutions = es.ask()
            if max_evaluations is not None:
                solutions = solutions[: max_evaluations - len(evaluated)]
            losses = [self.loss(z, history) for z in solutions]
            evaluated.extend(zip(solutions, losses))
            if len(solutions) == es.popsize:
                es.tell(solutions, losses)
        return evaluated

    def update(
        self,
        history: Sequence[ActionRecord],
        *,
        replay_budget: int | None = None,
        incumbent: PhysicsParameters | None = None,
    ) -> SysIDResult:
        """Refit the full history and return point and top-K hypotheses.

        replay_budget caps this call's fitting replays, replacing iterations.
        Complete-history candidate evaluations are shared evenly across starts;
        fewer starts are used if the budget cannot fund all of them. Unspent
        replays are fewer than len(history). Previous calls are not counted
        here; callers matching cumulative budgets must subtract their cost.

        An optional incumbent (m, mu, h_c) is rescored on the full current
        history and competes with the new search. Its evaluation is charged
        to replay_budget. No optimizer state or old loss is reused.
        """
        incumbent_run = []
        if incumbent is not None:
            values = np.asarray(incumbent, dtype=float)
            if (
                values.shape != (3,)
                or not np.all(np.isfinite(values))
                or values[0] <= 0
            ):
                raise ValueError("incumbent must contain finite physical parameters")
            z = np.array([math.log(values[0]), values[1], values[2] / self.geometry[2]])
            if np.any(z < Z_LO) or np.any(z > Z_HI):
                raise ValueError("incumbent must lie inside the physics search bounds")
            if not history:
                raise ValueError("incumbent requires a nonempty history")
        if replay_budget is None:
            runs = [
                self._run_es(history, self.seed + r) for r in range(self.restarts + 1)
            ]
        else:
            if (
                not isinstance(replay_budget, int)
                or isinstance(replay_budget, bool)
                or not history
                or replay_budget < len(history)
            ):
                raise ValueError(
                    "replay_budget must fund at least one complete-history evaluation"
                )
            evaluations = replay_budget // len(history)
            evaluations -= int(incumbent is not None)
            starts = min(self.restarts + 1, evaluations)
            per_start, remainder = divmod(evaluations, starts) if starts else (0, 0)
            runs = [
                self._run_es(
                    history,
                    self.seed + r,
                    max_evaluations=per_start + (r < remainder),
                )
                for r in range(starts)
            ]
        if incumbent is not None:
            incumbent_run = [(z, self.loss(z, history))]
        if not runs:
            runs = [incumbent_run]
        best_run = min(runs, key=lambda ev: min(loss for _, loss in ev))

        evaluated = (
            best_run + incumbent_run if best_run is not incumbent_run else best_run
        )
        evaluated.sort(key=lambda t: t[1])
        z_best, l_best = evaluated[0]

        retained: list[tuple[NDArray[np.float64], float]] = []
        for z, loss in evaluated:
            if all(np.linalg.norm(z - z2) > 1e-3 for z2, _ in retained):
                retained.append((z, loss))
            if len(retained) >= self.K:
                break
        ls = np.array([loss for _, loss in retained])
        t = 0.05 * ls[0] + 1e-12  # temperature scaled to the best loss
        ws = np.exp(-(ls - ls[0]) / t)
        ws = ws / ws.sum()

        point = Hypothesis(
            theta=tuple(convert_z_to_cuboid_spec(z_best, self.geometry).theta),
            loss=l_best,
        )
        hypotheses = [
            Hypothesis(
                theta=tuple(convert_z_to_cuboid_spec(z, self.geometry).theta),
                loss=loss,
                weight=w,
            )
            for (z, loss), w in zip(retained, ws)
        ]
        return SysIDResult(point=point, hypotheses=hypotheses)

    def close(self) -> None:
        self.sim.close()

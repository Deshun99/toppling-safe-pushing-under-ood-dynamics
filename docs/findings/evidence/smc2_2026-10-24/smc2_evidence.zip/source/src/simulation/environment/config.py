"""Action semantics shared by M3 training, calibration, and checkpoint loading."""

import json
from pathlib import Path

from src.simulation.environment.env import ActionRanges

# Historical M3 policies were trained with 15 N, not PushEnv's 50 N default.
M3_ACTION_RANGES = ActionRanges(force=(0.0, 15.0))


def load_action_ranges(model_path: str | Path) -> ActionRanges:
    """Read checkpoint action bounds; support the original M3 f_max metadata.

    Missing metadata is an error because normalized action spaces alone cannot
    detect a physical force mismatch. Keep config.json alongside the model.
    """
    config_path = Path(model_path).parent / "config.json"
    if not config_path.is_file():
        raise FileNotFoundError(
            f"Missing {config_path}: keep checkpoint action metadata beside the model."
        )
    with config_path.open() as stream:
        config = json.load(stream)
    if "action_ranges" in config:
        bounds = config["action_ranges"]
        return ActionRanges(**{key: tuple(value) for key, value in bounds.items()})
    return ActionRanges(force=(0.0, float(config["f_max"])))

"""Gymnasium environment for toppling-safe pushing (M1).

Formulation follows docs/project_outline.md §3:

- observation  o = (d, psi, xdot, psidot, w, L, H); hidden theta never given
- action       a = (h, F, tau), normalized to [-1, 1]^3 for the RL policy and
               denormalized here to h in [0.1H, 0.9H], F in ACTION_RANGES.force,
               tau in [0.05, 0.50] s
- episode      at most T_max = 10 decisions; success and topple terminate early
"""

from dataclasses import dataclass
from typing import Any, Final

import gymnasium as gym
from gymnasium import spaces
import numpy as np
from numpy.typing import ArrayLike, NDArray
import pybullet as p
import pybullet_data

from src.simulation.modelling.records import ActionRecord
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.constants import DT, GRAVITY
from src.simulation.modelling.object import Cuboid, CuboidSpec
from src.simulation.execution.force_push import (
    DenseTrajectory,
    ForcePushExecutor,
    PushExecutor,
)
from src.simulation.environment.reward import RewardModel


@dataclass(frozen=True)
class TrainingRanges:
    """
    Provisional sampling bounds (outline §9.1); finalize after pilot tests.

    Geometry uses metres, mass uses kilograms, and h_c_frac is h_c / H.
    """

    w: tuple[float, float] = (0.05, 0.10)
    L: tuple[float, float] = (0.05, 0.10)
    H: tuple[float, float] = (0.12, 0.25)
    m: tuple[float, float] = (0.5, 1.5)
    mu: tuple[float, float] = (0.3, 0.7)
    h_c_frac: tuple[float, float] = (0.35, 0.60)


@dataclass(frozen=True)
class ActionRanges:
    """
    Physical action bounds (outline §3.3).

    Height is a fraction of object height; force uses newtons and duration
    uses seconds. The force upper bound is provisional pending pilot tests.
    """

    height_fraction: tuple[float, float] = (0.1, 0.9)
    force: tuple[float, float] = (0.0, 50.0)
    duration: tuple[float, float] = (0.05, 0.50)


TRAINING_RANGES: Final = TrainingRanges()
ACTION_RANGES: Final = ActionRanges()


class PushEnv(gym.Env[NDArray[np.float32], NDArray[np.float32]]):
    """Target environment: an upright cuboid pushed toward a target on a plane.

    The push primitive is executed by `executor` (direct force for M1; the
    KUKA executor swaps in at S2 without changing this class). The dense
    trajectory of the last action is kept in `self.last_trajectory` for the
    system-identification stage (M2).

    The default maximum force of 50 N exceeds the approximate sliding threshold at the joint-OOD
    upper bounds (mu * m * g = 1.1 * 3.0 * 9.81 ~= 32.4 N; outline §9.1).
    This leaves headroom for unsafe high-force actions (outline §5.3), but
    does not guarantee safe sliding. PROVISIONAL pending pilot tests.
    """

    def __init__(
        self,
        target_distance: float = 1.0,
        epsilon: float = 0.05,  # target tolerance (m)
        psi_succ_tol: float = 0.02,  # rad
        v_succ_tol: float = 0.05,  # m/s
        T_max: int = 10,
        reward: RewardModel | None = None,
        executor: PushExecutor | None = None,
        fixed_spec: CuboidSpec | None = None,
        near_topple_frac: float = 0.8,  # psi_max / crit_tilt (filter, S5)
        realtime_scale: float = 0.0,  # >0: pace physics at real time (demo)
        gui: bool = False,
        action_ranges: ActionRanges = ACTION_RANGES,
    ) -> None:
        """
        Initialize the PushEnv.

        Args:
            target_distance: The distance to the target.
            epsilon: The tolerance for reaching the target.
            psi_succ_tol: The tolerance for the orientation of the cuboid.
            v_succ_tol: The tolerance for the velocity of the cuboid.
            T_max: The maximum number of actions the agent can take in an episode.
            reward: The reward model and its coefficients.
            executor: The push executor.
            fixed_spec: A fixed cuboid spec.
            near_topple_frac: The fraction of the critical tilt to consider as near-topple.
            realtime_scale: The scale for real-time physics simulation.
            gui: Whether to use the GUI for visualization.
            action_ranges: Physical bounds used to map normalized policy actions.
        """
        super().__init__()
        self.action_ranges = action_ranges
        self.target_distance = target_distance
        self.epsilon = epsilon
        self.psi_succ_tol = psi_succ_tol
        self.v_succ_tol = v_succ_tol
        self.T_max = T_max
        self.reward = reward or RewardModel()
        self.near_topple_frac = near_topple_frac
        self._rng = np.random.default_rng()

        self.client: int | None = p.connect(p.GUI if gui else p.DIRECT)
        p.setGravity(0, 0, GRAVITY, physicsClientId=self.client)
        p.setTimeStep(DT, physicsClientId=self.client)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        # Floor with mu = 1.0 so the cuboid's lateralFriction IS the effective
        # object-floor coefficient (see object.py friction convention).
        self.plane = p.loadURDF("plane.urdf", physicsClientId=self.client)
        p.changeDynamics(
            self.plane, -1, lateralFriction=1.0, physicsClientId=self.client
        )

        self.executor = executor or ForcePushExecutor(
            self.client, realtime_scale=realtime_scale
        )
        self._fixed_spec = fixed_spec
        self.cuboid: Cuboid | None = None
        self.last_trajectory: DenseTrajectory | None = None
        self._d_prev = target_distance
        self.steps = 0
        self.psi_max = 0.0  # near-topple threshold; set per-object in reset()

        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(7,), dtype=np.float32
        )  # (d, psi, xdot, psidot, w, L, H)
        self.action_space = spaces.Box(
            low=-1.0, high=1.0, shape=(3,), dtype=np.float32
        )  # (h, F, tau)

    def _sample_spec(self) -> CuboidSpec:
        """
        Sample a random cuboid spec from the training distribution (outline §9.1).
        """
        ranges = TRAINING_RANGES
        sample_uniform = self._rng.uniform
        H = sample_uniform(*ranges.H)
        return CuboidSpec(
            w=sample_uniform(*ranges.w),
            L=sample_uniform(*ranges.L),
            H=H,
            m=sample_uniform(*ranges.m),
            mu=sample_uniform(*ranges.mu),
            h_c=H * sample_uniform(*ranges.h_c_frac),
        )

    def reset(
        self, seed: int | None = None
    ) -> tuple[NDArray[np.float32], dict[str, Any]]:
        """
        Randomly initialize the environment to a new world state at the start of an episode,
        returning the initial observation and info dict.

        The cuboid is spawned slightly above the floor and allowed to settle for a short
        time before the first decision. The hidden object parameters are returned in the info dict.

        seed: Optional seed for the random number generator. If provided, it will be used to
              initialize the random number generator for reproducibility.
        """
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        spec = self._fixed_spec or self._sample_spec()
        self.replace_object(spec=spec)
        num_seconds_to_settle = 0.5
        for _ in range(round(num_seconds_to_settle / DT)):
            p.stepSimulation(physicsClientId=self.client)
        self._d_prev = self.target_distance
        self.steps = 0
        self.last_trajectory = None
        self.psi_max = self.near_topple_frac * spec.crit_tilt
        info = {"true_theta": (spec.m, spec.mu, spec.h_c)}
        return self._get_observation(), info

    def _get_observation(self) -> NDArray[np.float32]:
        """
        Return the current observation vector (d, psi, xdot, psidot, w, L, H).
        """
        x, psi, xdot, psidot = self.cuboid.state()
        s = self.cuboid.spec
        d = self.target_distance - x
        return np.array([d, psi, xdot, psidot, s.w, s.L, s.H], dtype=np.float32)

    def step(
        self, action: ArrayLike
    ) -> tuple[NDArray[np.float32], float, bool, bool, dict[str, Any]]:
        physical_action = self._denormalize_action(action)
        self.push(physical_action)
        reward, terminated, truncated, info = self._compute_step_result(
            physical_action.h, physical_action.F, physical_action.tau
        )
        return self._get_observation(), reward, terminated, truncated, info

    def _denormalize_action(self, action: ArrayLike) -> PushAction:
        """Clip the normalized action and map it to physical push bounds."""
        normalized_action = np.clip(
            np.asarray(action, dtype=np.float64),
            self.action_space.low,
            self.action_space.high,
        )
        s = self.cuboid.spec
        min_height_fraction, max_height_fraction = self.action_ranges.height_fraction
        min_duration, max_duration = self.action_ranges.duration
        min_force, max_force = self.action_ranges.force
        action_min = np.array([s.H * min_height_fraction, min_force, min_duration])
        action_max = np.array([s.H * max_height_fraction, max_force, max_duration])
        action_fraction = (normalized_action - self.action_space.low) / (
            self.action_space.high - self.action_space.low
        )
        h, F, tau = action_min + action_fraction * (action_max - action_min)
        return PushAction(h=h, F=F, tau=tau)

    def replace_object(self, x: float = 0.0, spec: CuboidSpec | None = None) -> None:
        """
        Spawn an upright, stationary object without settling or resetting an episode.

        Reuse the current spec unless one is supplied. Study protocols can
        replace a fallen object at its current x without resampling physics.

        Args:
            x: The x-coordinate to place the object at.
            spec: The CuboidSpec to use for the object. If None, the current spec will be reused.
        """
        if spec is None:
            if self.cuboid is None:
                raise RuntimeError("Call reset() or supply a spec first.")
            spec = self.cuboid.spec
        if self.cuboid is not None:
            self.cuboid.remove()
        self.cuboid = Cuboid(spec, self.client)
        self.cuboid.spawn(
            position=(x, 0.0, spec.H / 2.0 + 0.005)
        )  # spawn slightly above floor to avoid initial penetration with the plane
        self.last_trajectory = None
        self.psi_max = self.near_topple_frac * spec.crit_tilt

    def push(
        self,
        action: PushAction,
        *,
        warmup_steps: int = 0,
    ) -> ActionRecord:
        """
        Execute a physical action and record its pre-warm-up starting state.

        The action contains h, F, and tau, in metres, newtons, and seconds. Values are
        not normalized or clipped to policy bounds. Warm-up samples are included in the record.
        This advances physics only; use step() for RL rewards and episode
        bookkeeping. Do not mix raw pushes into an ongoing RL episode.
        """
        if self.cuboid is None:
            raise RuntimeError("Call reset() before pushing.")
        if warmup_steps < 0:
            raise ValueError("warmup_steps must be nonnegative.")
        start = self.cuboid.state()
        self.last_trajectory = self.executor.execute(
            self.cuboid,
            h=action.h,
            F=action.F,
            tau=action.tau,
            warmup_steps=warmup_steps,
        )
        return ActionRecord(start, action, self.last_trajectory, warmup_steps)

    def _compute_step_result(
        self, h: float, F: float, tau: float
    ) -> tuple[float, bool, bool, dict[str, Any]]:
        """Evaluate the completed push and advance episode bookkeeping."""
        s = self.cuboid.spec
        x, psi, xdot, psidot = self.cuboid.state()
        d = self.target_distance - x
        crit = s.crit_tilt
        toppled = abs(psi) > crit
        success = (
            abs(d) <= self.epsilon
            and abs(psi) <= self.psi_succ_tol
            and abs(xdot) <= self.v_succ_tol
        )

        r = self.reward.compute_reward(
            previous_distance=self._d_prev,
            distance=d,
            duration=tau,
            success=success,
            toppled=toppled,
        )
        self._d_prev = d
        self.steps += 1

        terminated = bool(success or toppled)
        truncated = bool(self.steps >= self.T_max and not terminated)
        info = {
            "true_theta": (s.m, s.mu, s.h_c),
            "executed": (h, F, tau),
            "toppled": toppled,
            "success": success,
            "trajectory": self.last_trajectory,
            "max_tilt": max(
                (abs(p) for p in self.last_trajectory.psi), default=abs(psi)
            ),
            "TimeLimit.truncated": truncated,
            "is_success": bool(success),
        }
        return r, terminated, truncated, info

    def close(self) -> None:
        if getattr(self, "client", None) is not None:
            p.disconnect(physicsClientId=self.client)
            self.client = None

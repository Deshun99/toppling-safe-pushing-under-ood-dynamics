"""Reward configuration and calculation for toppling-safe pushing."""

from dataclasses import dataclass


@dataclass
class RewardConfig:
    """Reward coefficients (outline §11.1).

    PROVISIONAL values — tune on the training distribution only, then freeze
    (outline §8.1).
    """

    alpha: float = 10.0  # progress gain per metre
    c_time: float = 1.0  # per second of force application
    c_step: float = 0.1  # per decision
    R_succ: float = 100.0  # success bonus
    R_topple: float = 100.0  # toppling penalty (episode ends)


class RewardModel:
    """Calculate pushing rewards using explicit, configurable coefficients."""

    def __init__(self, config: RewardConfig | None = None) -> None:
        self.config = config if config is not None else RewardConfig()

    def compute_reward(
        self,
        *,
        previous_distance: float,
        distance: float,
        duration: float,
        success: bool,
        toppled: bool,
    ) -> float:
        """Calculate one decision's reward without changing environment state.

        Distances are signed target-minus-object x positions in metres; progress
        is the decrease in their absolute values, so moving farther past the
        target is penalized. Duration is
        the commanded force application time in seconds, excluding settling or
        warm-up. Success and toppling are determined by the caller; their bonus
        and penalty apply independently if both are true.
        """
        return (
            self.config.alpha * (abs(previous_distance) - abs(distance))
            - self.config.c_time * duration
            - self.config.c_step
            + (self.config.R_succ if success else 0.0)
            - (self.config.R_topple if toppled else 0.0)
        )

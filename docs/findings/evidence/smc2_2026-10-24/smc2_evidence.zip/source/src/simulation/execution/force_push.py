"""The external-force action primitive and the shared executor interface.

`PushExecutor` is the contract between the environment and *how* a commanded
primitive a = (h, F, tau) becomes object motion. `ForcePushExecutor` applies
the force directly (M1); `robot.RobotPushExecutor` will drive the KUKA IIWA
beneath the same interface (S2 — see .claude/analysis/robot_integration_plan.md
§3, S2/S3). The environment must not care which one executes the push.
"""

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import pybullet as p

from src.simulation.modelling.constants import DT
from src.simulation.modelling.object import Cuboid


@dataclass
class DenseTrajectory:
    """Within-action object trajectory, recorded every physics step (outline
    §3.2/§6). System identification replays the same action in the internal
    simulator and compares against this.

    Attributes:
        t: Sample timestamps in seconds, relative to the start of this
            execution's recording, including any optional warmup. Samples
            are recorded after each physics step, but timestamps are
            zero-based: the first recorded sample is labelled t = 0.
        x: Object position along the world-frame push axis, in metres.
            Positive x points toward the target; values are absolute world
            coordinates, not displacement since the start of the push.
        psi: Object pitch (tilt about the y axis), in radians, extracted
            from its orientation as an Euler angle. Zero means upright.
        xdot: World-frame linear velocity along the x axis, in metres per
            second (dx/dt).
        psidot: World-frame angular velocity about the y axis, in radians
            per second. This represents dpsi/dt for the intended planar
            pitching motion; it is not a finite difference of psi samples.

    All lists have the same length, and entries at the same index describe
    the same physics step. Recording stops when the push ends; subsequent
    settling motion is not included.
    """

    t: list[float] = field(
        default_factory=list
    )  # timestamps in seconds, relative to the start of this execution's recording, including any optional warmup
    x: list[float] = field(default_factory=list)
    psi: list[float] = field(default_factory=list)
    xdot: list[float] = field(default_factory=list)
    psidot: list[float] = field(default_factory=list)

    def append(
        self, t: float, x: float, psi: float, xdot: float, psidot: float
    ) -> None:
        self.t.append(t)
        self.x.append(x)
        self.psi.append(psi)
        self.xdot.append(xdot)
        self.psidot.append(psidot)


class PushExecutor(ABC):
    @abstractmethod
    def execute(
        self, cuboid: Cuboid, h: float, F: float, tau: float, warmup_steps: int = 0
    ) -> DenseTrajectory:
        """Record optional free warm-up steps followed by the commanded push."""


class ForcePushExecutor(PushExecutor):
    """Direct application of the horizontal force (outline §3.3).

    The force acts in the fixed world-frame push direction (+x, toward the
    target) at the rear face, body-relative height h, with the application
    point recomputed from the object's current pose every physics step. It is
    removed after tau seconds; the object is NOT required to settle afterwards.
    """

    def __init__(self, client_id: int, realtime_scale: float = 0.0) -> None:
        """realtime_scale > 0 paces the physics at real time (1.0) or slow
        motion (< 1.0) by sleeping between steps, for GUI viewing. Wall-clock
        only — trajectories are identical. 0.0 runs as fast as possible."""
        self.client = client_id
        p.setTimeStep(DT, physicsClientId=self.client)
        self.realtime_scale = realtime_scale

    def _step(self) -> None:
        """Advance physics independently of wall-clock pacing."""
        p.stepSimulation(physicsClientId=self.client)

    @staticmethod
    def _pace(deadline: float, interval: float) -> float:
        """Include computation time and small sleep overruns in the schedule."""
        deadline += interval
        now = time.perf_counter()
        remaining = deadline - now
        if remaining > 0:
            time.sleep(remaining)
        elif -remaining > max(0.1, 4 * interval):
            # A long interruption should not trigger a burst of catch-up steps.
            # Reset the clock without skipping any physics or recorded samples.
            deadline = now
        return deadline

    def execute(
        self, cuboid: Cuboid, h: float, F: float, tau: float, warmup_steps: int = 0
    ) -> DenseTrajectory:
        """Apply one push primitive and return the recorded dense trajectory.

        warmup_steps: free simulation steps recorded BEFORE the force is
        applied. Used by SysID replay (and the scripted study) so a freshly
        spawned box establishes floor contact before the push — without it,
        fast-sliding near-tipping pushes diverge between target and replay
        (the spawn-time contact transient flips the bistable tipping
        outcome). The gymnasium env uses the default 0.
        """
        traj = DenseTrajectory()
        paced = self.realtime_scale > 0
        interval = DT / self.realtime_scale if paced else 0.0
        # Each action gets its own clock; warmup and pushing share its schedule.
        deadline = time.perf_counter() if paced else 0.0
        # Apply the force for the specified duration.
        for i in range(warmup_steps):
            self._step()
            x, psi, xdot, psidot = cuboid.state()
            traj.append(i * DT, x, psi, xdot, psidot)
            if paced:
                deadline = self._pace(deadline, interval)
        steps = max(1, round(tau / DT))
        for i in range(steps):
            pos, orn = (
                cuboid.pose()
            )  # position and orientation (quaternion) of the cuboid
            contact_point = cuboid.rear_face_point(pos, orn, h)
            p.applyExternalForce(
                cuboid.body,
                -1,
                forceObj=[F, 0.0, 0.0],
                posObj=contact_point,
                flags=p.WORLD_FRAME,
                physicsClientId=self.client,
            )
            self._step()
            x, psi, xdot, psidot = cuboid.state()
            traj.append((warmup_steps + i) * DT, x, psi, xdot, psidot)
            if paced:
                deadline = self._pace(deadline, interval)
        return traj

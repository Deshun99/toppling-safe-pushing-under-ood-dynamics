"""KUKA IIWA push executor — S2 stage (future).

Implements the same `PushExecutor` interface as `force_push.ForcePushExecutor`
so the environment can swap execution modes without any change to `env.py`
(robot_integration_plan.md §3, S2/S3). Design summary (plan §2):

- IK to a pre-push pose at the commanded rear-face height h
  (`p.calculateInverseKinematics`).
- Approach slowly; the push timer starts at contact detection
  (`p.getContactPoints`), not at command issue — tau can be as short as
  0.05 s = 12 physics steps.
- Execute as impedance-style position tracking
  (`p.setJointMotorControl2`, POSITION_CONTROL, 240 Hz) of a virtual setpoint
  moving along the push axis, with speed derived from F.
- Retract after tau. Log realized (h, F, tau) via wrist joint reaction forces
  (`p.getJointState`) — executed force will differ from commanded; that
  difference is the measured G1 noise.
"""

from src.simulation.modelling.object import Cuboid
from src.simulation.execution.force_push import DenseTrajectory, PushExecutor


class RobotPushExecutor(PushExecutor):
    def __init__(self, client_id: int, urdf: str = "kuka_iiwa/model.urdf") -> None:
        raise NotImplementedError(
            "S2 stage — see .claude/analysis/robot_integration_plan.md §2-3"
        )

    def execute(
        self, cuboid: Cuboid, h: float, F: float, tau: float, warmup_steps: int = 0
    ) -> DenseTrajectory:
        raise NotImplementedError("S2 stage")

"""Recorded physical actions shared by target environments and replay."""

from dataclasses import dataclass

from src.simulation.execution.force_push import DenseTrajectory
from src.simulation.modelling.actions import PushAction
from src.simulation.modelling.object import ObjectState


@dataclass
class ActionRecord:
    """Start state before warm-up, commanded action, and all recorded samples."""

    start: ObjectState
    action: PushAction
    traj: DenseTrajectory
    warmup_steps: int = 0

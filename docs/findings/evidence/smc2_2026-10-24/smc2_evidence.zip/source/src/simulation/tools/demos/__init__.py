"""Interactive simulation demos."""

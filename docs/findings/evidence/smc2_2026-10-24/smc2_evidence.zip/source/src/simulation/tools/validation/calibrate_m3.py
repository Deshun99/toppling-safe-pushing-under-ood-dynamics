"""Calibrate F_max and reward scales before M3 training (M3).

Checks the two quantities the outline marks PROVISIONAL before SAC training:
  1. F_max (outline section 5.3): the heaviest, highest-friction object in
     TRAINING_RANGES must still be movable within an episode, while unsafe
     high-force/high-height actions must exist (they can topple).
  2. Reward coefficients (outline section 11.1): the success/topple bonuses
     must dominate per-action terms, and pushing must be net-positive on
     average so the policy has gradient signal toward progress.

Prints two diagnostic tables and a rule-based keep/tune recommendation.
No files are written and no values are auto-tuned; freezing the values is a
manual step (outline section 11.1: tune on the training distribution, then
freeze for all evaluation conditions).

Run from the repo root:  python -m src.simulation.tools.validation.calibrate_m3 [--fmax-list 10,15,20,25]
                          [--episodes 200] [--seed 0]
"""

import argparse


import numpy as np

from src.simulation.modelling.object import CuboidSpec
from src.simulation.environment import ActionRanges, PushEnv, RewardConfig
from src.simulation.environment.config import M3_ACTION_RANGES

# Specs that stress the corners of TRAINING_RANGES (outline section 9.1).
EXTREME_SPECS: dict[str, CuboidSpec] = {
    "heaviest_high_mu": CuboidSpec(
        w=0.10, L=0.10, H=0.25, m=1.5, mu=0.70, h_c=0.15
    ),  # hardest to move
    "light_tall_high_com": CuboidSpec(
        w=0.05, L=0.05, H=0.25, m=0.5, mu=0.30, h_c=0.15
    ),  # easiest to topple
    "mid_a": CuboidSpec(w=0.075, L=0.075, H=0.18, m=1.0, mu=0.50, h_c=0.09),
    "mid_b": CuboidSpec(w=0.09, L=0.06, H=0.15, m=1.25, mu=0.40, h_c=0.075),
}

# Max-push action: lowest height (0.1H), max force, max duration (0.5 s).
MAX_PUSH = (-1.0, 1.0, 1.0)
# Deliberately unsafe action: highest height (0.9H), max force, max duration.
UNSAFE_PUSH = (1.0, 1.0, 1.0)


def sweep_fmax(fmax_values: list[float], seed: int) -> list[dict]:
    """Push every extreme spec with the max action at each candidate F_max."""
    rows = []
    for fmax in fmax_values:
        for name, spec in EXTREME_SPECS.items():
            env = PushEnv(
                action_ranges=ActionRanges(force=(0.0, fmax)), fixed_spec=spec
            )
            try:
                # Episode of max pushes: can it reach the target?
                _, info = env.reset(seed=seed)
                dxs = []
                for _ in range(env.T_max):
                    obs, _, terminated, truncated, info = env.step(MAX_PUSH)
                    d = obs[0]
                    dxs.append(env.target_distance - d)
                    if terminated or truncated:
                        break
                rows.append(
                    {
                        "fmax": fmax,
                        "spec": name,
                        "m": spec.m,
                        "mu": spec.mu,
                        "reached": bool(info["success"]),
                        "toppled": bool(info["toppled"]),
                        "actions": len(dxs),
                        "dx_first": float(dxs[0]),  # can it move at all?
                        "dx_total": float(dxs[-1]),  # cumulative (may overshoot)
                    }
                )
                # One deliberately unsafe push: does the danger exist?
                _, unsafe_info = env.reset(seed=seed)
                _, _, _, _, unsafe_info = env.step(UNSAFE_PUSH)
                rows[-1]["unsafe_toppled"] = bool(unsafe_info["toppled"])
                rows[-1]["unsafe_max_tilt"] = float(unsafe_info["max_tilt"])
            finally:
                env.close()
    return rows


def reward_diagnostics(episodes: int, seed: int) -> dict:
    """Random episodes over TRAINING_RANGES; decompose the reward into terms."""
    reward = RewardConfig()
    env = PushEnv(action_ranges=M3_ACTION_RANGES)
    env.action_space.seed(seed)
    try:
        term_r = []  # per-action |r| with terminal bonuses removed
        ep_return = []
        ep_success = []
        ep_topple = []
        for i in range(episodes):
            obs, info = env.reset(seed=seed + i)
            ret = 0.0
            done = False
            while not done:
                obs, r, terminated, truncated, info = env.step(
                    env.action_space.sample()
                )
                terminal = (reward.R_succ if info["success"] else 0.0) - (
                    reward.R_topple if info["toppled"] else 0.0
                )
                term_r.append(abs(r - terminal))
                ret += r
                done = terminated or truncated
            ep_return.append(ret)
            ep_success.append(bool(info["success"]))
            ep_topple.append(bool(info["toppled"]))
    finally:
        env.close()
    return {
        "mean_episode_return": float(np.mean(ep_return)),
        "success_rate": float(np.mean(ep_success)),
        "topple_rate": float(np.mean(ep_topple)),
        "mean_per_action_term": float(np.mean(term_r)),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--fmax-list",
        type=str,
        default="10,15,20,25",
        help="comma-separated F_max candidates in N (default: 10,15,20,25)",
    )
    parser.add_argument(
        "--episodes",
        type=int,
        default=200,
        help="random episodes for the reward diagnostics (default: 200)",
    )
    parser.add_argument(
        "--seed", type=int, default=0, help="seed for all episodes (default: 0)"
    )
    args = parser.parse_args()

    fmax_values = [float(x) for x in args.fmax_list.split(",")]
    if M3_ACTION_RANGES.force[1] not in fmax_values:
        fmax_values.append(M3_ACTION_RANGES.force[1])
    reward = RewardConfig()

    print("=== F_max sweep: max push (h=0.1H, F=F_max, tau=0.5 s) ===")
    print(
        f"{'F_max':>5} {'spec':<20} {'m':>5} {'mu':>4} "
        f"{'reached':>8} {'toppled':>8} {'actions':>8} "
        f"{'dx_first':>9} {'dx_total':>9} {'unsafe_toppled':>15}"
    )
    rows = sweep_fmax(fmax_values, args.seed)
    for r in rows:
        print(
            f"{r['fmax']:>5.0f} {r['spec']:<20} {r['m']:>5.2f} {r['mu']:>4.2f} "
            f"{str(r['reached']):>8} {str(r['toppled']):>8} "
            f"{r['actions']:>8} {r['dx_first']:>9.3f} "
            f"{r['dx_total']:>9.2f} {str(r['unsafe_toppled']):>15}"
        )

    diag = reward_diagnostics(args.episodes, args.seed)
    print(
        "\n=== Reward diagnostics over "
        f"{args.episodes} random episodes (TRAINING_RANGES) ==="
    )
    print(f"success rate:            {diag['success_rate']:.2f}")
    print(f"topple rate:             {diag['topple_rate']:.2f}")
    print(f"mean episode return:     {diag['mean_episode_return']:+.2f}")
    print(
        f"mean per-action |term|:  {diag['mean_per_action_term']:.3f} "
        f"(R_succ={reward.R_succ}, R_topple={reward.R_topple})"
    )

    # Rule-based recommendation (kept as code, not config). Movability is the
    # section 5.3 requirement: the extreme object must respond to SOME action
    # in the space (F_max just above its static friction mu*m*g ~ 10.3 N).
    # "Reaching the target" is the wrong check here — a full episode of max
    # pushes massively overshoots, and pass-through at speed is not success.
    current_fmax = M3_ACTION_RANGES.force[1]
    heaviest = next(
        r for r in rows if r["spec"] == "heaviest_high_mu" and r["fmax"] == current_fmax
    )
    light_tall = next(
        r
        for r in rows
        if r["spec"] == "light_tall_high_com" and r["fmax"] == current_fmax
    )
    fmax_ok = heaviest["dx_first"] > 0.0 and not heaviest["toppled"]
    unsafe_ok = light_tall["unsafe_toppled"]
    reward_ok = (
        min(reward.R_succ, reward.R_topple) >= 5.0 * diag["mean_per_action_term"]
    )
    print("\n=== Recommendation ===")
    print(
        f"F_max={current_fmax} can move the heaviest/highest-mu spec: "
        f"{fmax_ok} (dx_first={heaviest['dx_first']:.3f} m)"
    )
    print(f"unsafe actions exist (topple the light-tall spec): {unsafe_ok}")
    print(f"terminal bonuses >= 5x per-action |term|:      {reward_ok}")
    if fmax_ok and unsafe_ok and reward_ok:
        print(
            "KEEP current F_max and RewardConfig; freeze as-is (outline section 11.1)."
        )
    else:
        print(
            "TUNE: adjust F_max and/or RewardConfig per the failing rule, "
            "rerun, then freeze."
        )


if __name__ == "__main__":
    main()
